const fs=require('fs');
const marked=require('/Users/aresx/Ares-X.github.io/node_modules/marked');
marked.setOptions({mangle:false});
const audit='/tmp/vulwiki-pr11-20261004.yf3o4k';
const manifest=JSON.parse(fs.readFileSync(audit+'/article-manifest-enriched.json')).articles;
const root='/Users/aresx/.codex/worktrees/vulwiki-pr11-review-20261004/VulWiki';
function body(s){return s.startsWith('---\n')?s.slice(s.indexOf('\n---',4)+4):s;}
function values(s){const out={code:[],codespan:[],link:[],image:[],html:[]};const tokens=marked.lexer(body(s));marked.walkTokens(tokens,t=>{if(t.type==='code'||t.type==='codespan')out[t.type].push(t.text);else if(t.type==='link'||t.type==='image')out[t.type].push(JSON.stringify({href:t.href,title:t.title,text:t.text}));else if(t.type==='html')out.html.push(t.raw);});return out;}
let rows=[];
for(const x of manifest.filter(x=>x.status==='M')){
 const base=values(fs.readFileSync(x.base_file,'utf8')),head=values(fs.readFileSync(root+'/'+x.path,'utf8')),missing={};
 for(const key of Object.keys(base)){
   let remaining=[...head[key]],lost=[];
   for(const value of base[key]){const i=remaining.indexOf(value);if(i>=0)remaining.splice(i,1);else lost.push(value);}
   if(lost.length)missing[key]=lost;
 }
 rows.push({number:x.number,path:x.path,base_counts:Object.fromEntries(Object.entries(base).map(([k,v])=>[k,v.length])),head_counts:Object.fromEntries(Object.entries(head).map(([k,v])=>[k,v.length])),missing});
}
const report={marked_version:marked.version||require('/Users/aresx/Ares-X.github.io/node_modules/marked/package.json').version,scope:'All 95 modified existing articles; code text and link/image values are compared as multisets; HTML raw tokens separately',rows,documents_with_missing:rows.filter(x=>Object.keys(x.missing).length).length};
fs.writeFileSync(audit+'/'+(process.argv[2]||'ast-fidelity.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({files:rows.length,documents_with_missing:report.documents_with_missing,missing:rows.filter(x=>Object.keys(x.missing).length).map(x=>({number:x.number,path:x.path,missing_types:Object.keys(x.missing)}))}));
