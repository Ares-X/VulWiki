import json, collections, hashlib, os
from pathlib import Path
root=Path('/Users/aresx/.codex/worktrees/vulwiki-pr11-review-20261004/VulWiki')
audit=Path('/tmp/vulwiki-pr11-20261004.yf3o4k')
c=json.loads((root/'docs/KEV-CANDIDATES-20261003.json').read_text())
g=json.loads((root/'docs/KEV-MATERIAL-GATE-20261003.json').read_text())
p=json.loads((root/'docs/KEV-REVIEW-PROGRESS-20261003.json').read_text())
manifest=json.loads((audit/'diff-manifest.json').read_text())
checks=[]; diffs=[]
def check(name, expected, actual, ok, basis):
 checks.append({'name':name,'expected':expected,'actual':actual,'pass':bool(ok),'basis':basis})
# scope identity, uniqueness and set alignment
cids=[r['cve'] for r in c['rows']]; pids=[r['cve'] for r in p['rows']]
check('candidate row count',1727,len(cids),len(cids)==1727,'Count each row in KEV-CANDIDATES.rows.')
check('candidate unique IDs',1727,len(set(cids)),len(set(cids))==1727,'Unique CVE values across candidate rows.')
check('progress unique IDs',1727,len(set(pids)),len(set(pids))==1727,'Unique CVE values across progress rows.')
check('candidate/progress ID set equality',True,set(cids)==set(pids),set(cids)==set(pids),'Compare exact row-key sets.')
# reconciled classifications
for label,field in [('candidate disposition','audited_disposition'),('progress disposition','disposition')]:
 actual=dict(collections.Counter(r[field] for r in (c['rows'] if label.startswith('candidate') else p['rows'])))
 declared=c['audited_disposition_counts'] if label.startswith('candidate') else p['disposition_counts']
 check(label+' row tally',declared,actual,declared==actual,'Recount each row classification; compare declared tally.')
check('disposition total',1727,sum(c['audited_disposition_counts'].values()),sum(c['audited_disposition_counts'].values())==1727,'Sum five mutually exclusive row dispositions.')
for label,field,declared in [('candidate audited reading depth','audited_reading_depth',c['reading_depth_counts']),('progress reading depth','reading_depth',p['reading_depth_fact_counts'])]:
 rows=c['rows'] if label.startswith('candidate') else p['rows']; actual=dict(collections.Counter(r[field] for r in rows))
 check(label+' row tally',declared,actual,declared==actual,'Recount one depth fact per unique ID.')
check('reading depth total',1727,sum(c['reading_depth_counts'].values()),sum(c['reading_depth_counts'].values())==1727,'Sum seven mutually exclusive depth facts.')
# candidate article mapping vs progress mapping
cand_by={r['cve']:r for r in c['rows']}; prog_by={r['cve']:r for r in p['rows']}
article_map_match=[]
for cv in set(cand_by)&set(prog_by):
 ca=cand_by[cv]['review'].get('articles',[]); pa=prog_by[cv].get('articles_in_current_batch',[])
 if ca!=pa: article_map_match.append({'cve':cv,'candidate_articles':ca,'progress_articles':pa})
check('candidate/progress per-ID article mapping',0,len(article_map_match),not article_map_match,'Compare article path/mode/hash arrays for each CVE; no legacy snapshots used.')
pubrows=[r for r in c['rows'] if r['review']['disposition']=='published']
pub_ids={r['cve'] for r in pubrows}
per_cve=[a for r in pubrows for a in r['review'].get('articles',[])]
by_path=collections.defaultdict(list)
for r in pubrows:
 for a in r['review'].get('articles',[]): by_path[a['article']].append((r['cve'],a))
unique_modes={path:vals[0][1]['mode'] for path,vals in by_path.items()}
mode_counts=dict(collections.Counter(unique_modes.values()))
check('published unique candidate IDs',243,len(pub_ids),len(pub_ids)==243,'Unique CVE rows classified published.')
check('article association edges',243,len(per_cve),len(per_cve)==243,'Count each published CVE-to-article association.')
check('unique published article paths',230,len(by_path),len(by_path)==230,'Deduplicate paths; one article may cover multiple CVEs.')
check('unique article mode tally',{'new':135,'supplement':95},mode_counts,mode_counts=={'new':135,'supplement':95},'Count each unique article path once using its recorded mode.')
# manifest and current bytes
mf={x['path']:x for x in manifest['files'] if 'sha256' in x}
missing=[]; hashdiff=[]; unlisted=[]; inconsistent=[]
for path, vals in by_path.items():
 modes={(a['mode'],a['sha256']) for _,a in vals}
 if len(modes)!=1: inconsistent.append({'path':path,'mappings':[{'cve':cv,'mode':a['mode'],'sha256':a['sha256']} for cv,a in vals]})
 f=root/path
 if not f.is_file(): missing.append(path); continue
 actual=hashlib.sha256(f.read_bytes()).hexdigest()
 if not any(h==actual for _,h in modes): hashdiff.append({'path':path,'ledger':sorted(modes),'actual_sha256':actual})
 if path not in mf: unlisted.append(path)
check('published path/hash mode consistency',0,len(inconsistent),not inconsistent,'Each repeated article path has a single (mode, SHA-256) mapping.')
check('published mapped files exist',0,len(missing),not missing,'Check only current published article paths in the worktree.')
check('published mapped file SHA-256 mismatches',0,len(hashdiff),not hashdiff,'Hash current bytes and compare with per-CVE ledger values.')
check('published mapped files absent from diff manifest',0,len(unlisted),not unlisted,'Require every mapped article path in manifest file entries carrying SHA-256.')
# prior material gate ledger, count independently from its rows and bridge retained qualified IDs
ret=[r for r in g['rows'] if r['decision']=='retain']
holds=[r for r in g['rows'] if r['decision']=='hold']
removes=[r for r in g['rows'] if r['decision']=='remove']
qualified={cv for r in ret for cv in r.get('qualified_cves',[])}
check('material-gate reviewed row count',93,len(g['rows']),len(g['rows'])==93,'Count all individual article gate rows.')
check('material-gate decision tally',{'retain':53,'hold':12,'remove':28},{'retain':len(ret),'hold':len(holds),'remove':len(removes)},(len(ret),len(holds),len(removes))==(53,12,28),'Recount row decisions.')
check('retained qualified IDs',58,len(qualified),len(qualified)==58,'Unique IDs in qualified_cves on retain rows; multiple IDs may share one article.')
check('retained qualified IDs found in current published scope',0,len(qualified-pub_ids),not (qualified-pub_ids),'Compare exact IDs to current candidate published rows.')
# blocked/published intersection and article coverage
blocked_pub=[r for r in p['rows'] if r['current_blocked_scope'] and r['publication_status']=='published']
blocked_ids={r['cve'] for r in blocked_pub}
blocked_articles={a['article'] for r in blocked_pub for a in r.get('articles_in_current_batch',[])}
check('current blocked-scope/published ID intersection',49,len(blocked_ids),len(blocked_ids)==49,'Recount per-ID intersection from current row booleans/status.')
check('articles represented by blocked published intersection',48,len(blocked_articles),len(blocked_articles)==48,'Deduplicate article paths associated with those 49 IDs.')
# public prose cross-check: fixed latest-status statements only, no treating prior historical snapshots as present facts
text=(root/'docs/KEV-COLLECTION-20261003.md').read_text(); readme=(root/'README.md').read_text()
prose={'collection_latest_batch_line_346_has_230_243_135_95':'最终文稿批次为230篇/243个材料编号，135新增及95既有补证。' in text,
       'collection_latest_state_line_362_has_243_17_325_1133_9':'最新互斥处置为243纳入Draft分支、17充分重复、325有界暂缓、1133未发表直接暂停、9个具体来源/访问/核心输入/暂停依赖缺口，共1727。' in text,
       'readme_overall_counts_are_separately_labeled':'这些是全库文档计数' in text and '当前统计（2026-10-03）' in readme}
check('current prose statements',{'collection latest batch':True,'collection latest disposition':True,'README distinguishes overall counts':True},prose,all(prose.values()),'Search latest collection paragraphs and README; disregard explicitly historical snapshots.')
if article_map_match:
 diffs.append({'name':'candidate/progress article mapping mismatch','original_values':article_map_match})
if missing: diffs.append({'name':'missing mapped files','original_values':missing})
if hashdiff: diffs.append({'name':'mapped hash mismatch','original_values':hashdiff})
if unlisted: diffs.append({'name':'manifest omission','original_values':unlisted})
if inconsistent: diffs.append({'name':'conflicting path metadata','original_values':inconsistent})
report={'review':'PR11 KEV public ledger independent reconciliation','inputs':{'worktree':str(root),'audit_dir':str(audit),'files':['docs/KEV-CANDIDATES-20261003.json','docs/KEV-MATERIAL-GATE-20261003.json','docs/KEV-REVIEW-PROGRESS-20261003.json','docs/KEV-COLLECTION-20261003.md','README.md','diff-manifest.json']},'method':'Independent row-level recount and exact path/hash comparison. Current state is sourced from 20261003 row ledgers; historical narrative snapshots are not promoted to current facts. No exploit material or target was opened or executed.','checks':checks,'differences':diffs,'conclusion':{'all_assertions_pass':all(x['pass'] for x in checks),'difference_count':len(diffs),'minimum_recommendation':'No count or mapping correction indicated by this bounded ledger audit.' if all(x['pass'] for x in checks) else 'Correct only the field or path identified by failed assertions, preserving original values in this report.'},'coverage_limits':['Reconciles ledger arithmetic, row-key uniqueness, cross-ledger article maps, unique current published files, manifest presence and SHA-256 only.','Does not semantically review article bodies, upstream source provenance, technical accuracy, scope suitability, rendered presentation, generated search indexes, or runtime behavior.','Does not re-open sources associated with paused scope; no exploit article, PoC, scanner, payload, or external target was accessed.','Diff manifest and worktree are treated as supplied inputs; no upstream/current KEV catalog validation performed.']}
(audit/'ledger-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'file':str(audit/'ledger-review.json'),'checks':len(checks),'failed':[x['name'] for x in checks if not x['pass']],'differences':len(diffs)},ensure_ascii=False))
