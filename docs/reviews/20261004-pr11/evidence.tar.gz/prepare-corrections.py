import json, pathlib, hashlib, difflib, re, subprocess

A = pathlib.Path('/tmp/vulwiki-pr11-20261004.yf3o4k')
R = pathlib.Path('/Users/aresx/.codex/worktrees/vulwiki-pr11-review-20261004/VulWiki')
manifest = json.loads((A/'article-manifest-enriched.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == manifest['head']
articles = {x['number']: x for x in manifest['articles']}
pending = {}

def operation(n, old, new, reason):
    x = articles[n]
    assert not x['scope_paused'], (n, 'paused')
    s = (R/x['path']).read_text()
    assert hashlib.sha256(s.encode()).hexdigest() == x['sha256']
    assert s.count(old) == 1, (n, old, s.count(old))
    start = s.index(old)
    pending.setdefault(n, []).append(dict(start_char=start, end_char=start+len(old), old=old, new=new, reason=reason))

def scalar(n, key, new, reason):
    s = (R/articles[n]['path']).read_text()
    front = s[:s.index('\n---',4)]
    match = re.search(r'^'+re.escape(key)+r': (.+)$', front, re.M)
    assert match, (n,key)
    old = json.loads(match[1])
    previous = 'previous_'+key
    assert not re.search(r'^'+re.escape(previous)+r':', front, re.M)
    operation(n, match[0]+'\n', key+': '+json.dumps(new,ensure_ascii=False)+'\n'+previous+': '+json.dumps(old,ensure_ascii=False)+'\n', reason)

def add_scalar(n, key, value, reason):
    s = (R/articles[n]['path']).read_text(); front = s[:s.index('\n---',4)]
    assert not re.search(r'^'+re.escape(key)+r':', front, re.M)
    marker = '\nschema_version: "1"\n'
    operation(n, marker, '\n'+key+': '+json.dumps(value,ensure_ascii=False)+marker, reason)

scalar(13, 'affected_versions', 'LiteLLM >=1.81.16 且 <1.83.7；1.83.7为修复版本（GHSA-r75f-5x8p-qvmc）', '官方GHSA与新增正文均排除修复版本1.83.7；保留旧字段原值。')
add_scalar(13, 'fixed_version', '1.83.7（GHSA-r75f-5x8p-qvmc）', '记录同一GHSA的修复边界。')
scalar(27, 'fixed_version', 'Adobe Commerce与Magento Open Source按对应维护线：2.4.7-p1；2.4.6-p6；2.4.5-p8；2.4.4-p9；仅Adobe Commerce扩展支持计划客户另有2.4.3-ext-8/2.4.2-ext-8；ACSD-60241是2.4.4–2.4.7的独立补丁', '将厂商公告表中的产品和扩展支持适用条件写入可检索字段，原字段原值保留。')
operation(27, '具体而言，HTTP400中的随机fieldName只支持请求触及相应错误路径', '上述四个常规维护线修复版本分别适用于Adobe Commerce与Magento Open Source的对应分支；2.4.3-ext-8与2.4.2-ext-8仅适用于Adobe Commerce扩展支持计划客户。ACSD-60241单独适用于公告所列2.4.4–2.4.7范围，不能当作所有旧分支均适用的补丁。\n\n具体而言，HTTP400中的随机fieldName只支持请求触及相应错误路径', '补充产品/维护线归属，不删除原校订、源码或历史新闻。')
scalar(38, 'version', 'Apache Struts 2.0.0–2.2.3（S2-007官方公告）', '旧字段误抽入代码；原字符串保留在previous_version，正文代码不动。')
scalar(38, 'affected_versions', 'Apache Struts 2.0.0–2.2.3；CVE-2012-0391类型转换子问题为早于2.2.3.1', '区分S2公告范围和CVE子问题；不修改编号角色。')
add_scalar(38, 'fixed_version', '2.2.3.1（S2-007/CVE-2012-0391类型转换子问题）', 'Apache公告及CNA支持该修复边界。')
scalar(179, 'product', 'Palo Alto Networks PAN-OS GlobalProtect', '新增补证及厂商公告已确认产品；旧标题限定原值保留。')
scalar(179, 'identifier_status', 'active', '厂商公告直接对应CVE-2026-0257；不改变原主编号。')
scalar(179, 'prerequisites', 'GlobalProtect门户或网关启用authentication override cookies，且Cookie证书被复用于可从外部取得公钥的功能；需按厂商公告核对具体证书配置', '旧无前提与新增正文及厂商公告冲突；保留旧字段原值。')
operation(179, '## 技术校订与证据边界（2026-10-02）\n', '## 技术校订与证据边界（2026-10-02）\n\n> 以下记录的是补证前的原归档快照：当时只有导航，缺少技术正文。“正文无漏洞资料”“前提：无”等描述仅适用于该历史快照；本次新增材料、配置条件和修复范围见上方“公开 Cookie 验证代码与配置条件”。保留这些旧记录用于追溯，不将其作为整篇当前结论。\n', '限定整个旧校订块的历史时点，不删除任何原记录。')
for n in (58,61,62,67,68,70,74,217):
    note = 'source_url与verification_source记录本次公开补证来源；原归档转载的原始出处仍待补，补证来源不替代归档全篇的原始披露出处。'
    if n == 62:
        note += '该补证只支持正文区分出的第三种rsh路径，不替代其余两种方法的来源。'
    if n == 217:
        note += '该补证只支持CVE-2024-57727的文件读取材料，不替代CVE-2024-57726和CVE-2024-57728原新闻的出处。'
    scalar(n, 'source_note', note, '补证URL已有，但旧出处待补说明未限定到归档来源；保留原说明并写明支持范围。')

# Only newly inserted supplement sections with a level-one Markdown heading.
# Lexed headings below are generated separately; code/HTML lines are never selected.
lexed = json.loads((A/'heading-tokens.json').read_text())
for h in json.loads((A/'new-supplement-h1.json').read_text()):
    n = h['number']; x = articles[n]
    old_lines = pathlib.Path(x['base_file']).read_text().splitlines(keepends=True)
    lines = (R/x['path']).read_text().splitlines(keepends=True)
    index = next(i for i,l in enumerate(lines) if l.rstrip('\n\r') == h['heading'])
    block = next((bi,bz) for tag,ai,az,bi,bz in difflib.SequenceMatcher(None,old_lines,lines,autojunk=False).get_opcodes() if tag=='insert' and bi<=index<bz)
    for token in lexed[str(n)]:
        start = token['start_char']; line_index = sum(len(l) for l in lines[:block[0]])
        end = sum(len(l) for l in lines[:block[1]])
        if line_index <= start < end:
            raw = token['raw']; assert raw.startswith('#') and token['depth'] < 6
            operation(n, raw, '#'+raw, '仅将本PR新增补充节及其子标题降一级；原归档标题和代码保持原值。')

preview = A/'correction-preview'; preview.mkdir(exist_ok=True)
rows = []
for n, ops in sorted(pending.items()):
    x = articles[n]; before = (R/x['path']).read_text(); result = before
    ordered = sorted(ops,key=lambda t:t['start_char'])
    assert all(a['end_char']<=b['start_char'] for a,b in zip(ordered,ordered[1:])), n
    for op in reversed(ordered):
        assert result[op['start_char']:op['end_char']] == op['old']
        result = result[:op['start_char']]+op['new']+result[op['end_char']:]
    delta = 0
    for op in ordered:
        op['after_start_char'] = op['start_char']+delta
        op['after_end_char'] = op['after_start_char']+len(op['new'])
        delta += len(op['new'])-len(op['old'])
    restored = result
    for op in reversed(ordered):
        assert restored[op['after_start_char']:op['after_end_char']] == op['new']
        restored = restored[:op['after_start_char']]+op['old']+restored[op['after_end_char']:]
    assert restored == before
    (preview/f'{n:03}-before.md').write_text(before)
    (preview/f'{n:03}-after.md').write_text(result)
    rows.append(dict(number=n,path=x['path'],before_sha256=x['sha256'],after_sha256=hashlib.sha256(result.encode()).hexdigest(),before_file=str(preview/f'{n:03}-before.md'),after_file=str(preview/f'{n:03}-after.md'),operations=ordered,exact_reverse=True))
(A/'correction-operations.json').write_text(json.dumps(dict(offset_unit='Python Unicode code points',frozen_head=manifest['head'],files=rows),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(files=len(rows),operations=sum(len(x['operations']) for x in rows),paths=[x['path'] for x in rows]),ensure_ascii=False,indent=2))
