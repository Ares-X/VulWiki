import json, hashlib, difflib, os, re, subprocess
from pathlib import Path

audit=Path('/tmp/vulwiki-pr11-20261004.yf3o4k')
root=Path('/Users/aresx/.codex/worktrees/vulwiki-pr11-review-20261004/VulWiki')
m=json.loads((audit/'article-manifest-enriched.json').read_text())

def split_doc(s):
    # Preserve exact text; recognize conventional frontmatter only at byte-zero.
    lines=s.splitlines(keepends=True)
    if lines and lines[0].rstrip('\r\n')=='---':
        for i in range(1,len(lines)):
            if lines[i].rstrip('\r\n') in ('---','...'):
                return ''.join(lines[:i+1]), ''.join(lines[i+1:])
    return '',s

records=[]; diffs=[]
for a in m['articles']:
    p=a['path']; new=(root/p).read_bytes()
    rec={'path':p,'status':a['status'],'head_sha256':hashlib.sha256(new).hexdigest(),'head_bytes':len(new),
         'manifest_head_sha_matches':hashlib.sha256(new).hexdigest()==a['sha256']}
    if a.get('base_file'):
        old=Path(a['base_file']).read_bytes(); old_s=old.decode('utf-8'); new_s=new.decode('utf-8')
        of,ob=split_doc(old_s); nf,nb=split_doc(new_s)
        def line_delta(x,y):
            xlines=x.splitlines(); ylines=y.splitlines()
            sm=difflib.SequenceMatcher(a=xlines,b=ylines,autojunk=False)
            deleted=[]; added=[]; changed=[]
            for tag,i1,i2,j1,j2 in sm.get_opcodes():
                if tag in ('delete','replace'):
                    deleted.extend({'base_line':i+1,'text':xlines[i]} for i in range(i1,i2))
                if tag in ('insert','replace'):
                    added.extend({'head_line':j+1,'text':ylines[j]} for j in range(j1,j2))
                if tag=='replace': changed.append({'base':[i1+1,i2], 'head':[j1+1,j2]})
            return deleted,added,changed
        fd,fa,fc=line_delta(of,nf); bd,ba,bc=line_delta(ob,nb)
        # SequenceMatcher may align duplicates; exact old line multiset containment is independent evidence.
        oldlines=old_s.splitlines(keepends=True); newlines=new_s.splitlines(keepends=True)
        counts={}
        for l in newlines: counts[l]=counts.get(l,0)+1
        missing=[]
        for i,l in enumerate(oldlines,1):
            if counts.get(l,0): counts[l]-=1
            else: missing.append({'base_line':i,'text':l.rstrip('\r\n')})
        missing_unique_text=[x for x in missing if x['text'] not in new_s]
        redactions=[]
        pats=[r'\[REDACTED\]',r'\[redacted\]',r'\*{3,}',r'<REDACTED>',r'REDACTED',r'\b(?:REDACTED|MASKED|HIDDEN)\b']
        for line in fa+ba:
            if any(re.search(q,line['text'],re.I) for q in pats): redactions.append(line)
        rec.update({'base_file':a['base_file'],'base_sha256':hashlib.sha256(old).hexdigest(),'base_bytes':len(old),
          'exact_file_match':old==new,'old_exact_line_occurrence_shortfall':len(missing),
          'old_exact_line_occurrence_shortfall_evidence':missing[:200],
          'old_exact_text_absent_from_head':len(missing_unique_text),'old_exact_text_absent_evidence':missing_unique_text[:200],
          'frontmatter':{'base_lines':len(of.splitlines()),'head_lines':len(nf.splitlines()),'deleted':fd,'added':fa,'replaced_ranges':fc},
          'body':{'base_lines':len(ob.splitlines()),'head_lines':len(nb.splitlines()),'deleted':bd,'added':ba,'replaced_ranges':bc},
          'redaction_marker_candidates':redactions,'pure_append_by_line_multiset':not missing})
        # Stronger body-preservation proof: old frontmatter-free body must occur byte-for-byte in the new body.
        rec['old_body_lines_preserved_in_order'] = len(bd)==0
        # Values on replaced frontmatter lines are tracked as exact text, including whether they remain in body.
        rec['replaced_frontmatter_value_retention'] = []
        for d in fd:
            if ':' in d['text']:
                key,val=d['text'].split(':',1)
                rec['replaced_frontmatter_value_retention'].append({'key':key.strip(),'old_line':d['text'],
                    'old_line_occurs_in_new_document':d['text'] in new_s,
                    'old_value_occurs_in_body':val.strip().strip('"') in nb if val.strip().strip('"') else True})
        ud=''.join(difflib.unified_diff(old_s.splitlines(keepends=True),new_s.splitlines(keepends=True),fromfile='BASE/'+p,tofile='HEAD/'+p))
        if ud: diffs.append(ud)
    records.append(rec)

report={'worktree':m['worktree'],'base':m['base'],'head':m['head'],'marked_version':'4.3.0','manifest_total':len(records),
 'coverage':{'total':len(records),'base_files':sum(bool(x.get('base_file')) for x in records),'added':sum(x['status']=='A' for x in records),'paths':len(set(x['path'] for x in records))},
 'summary':{'modified':sum(x['status']=='M' for x in records),'unchanged_modified':sum(x.get('exact_file_match',False) for x in records),'with_old_exact_text_absent':sum(bool(x.get('old_exact_text_absent_from_head')) for x in records),'body_deletion_documents':sum(bool(x.get('body',{}).get('deleted')) for x in records),'manifest_head_sha_mismatches':sum(not x['manifest_head_sha_matches'] for x in records),'redaction_marker_candidates':sum(bool(x.get('redaction_marker_candidates')) for x in records)},
 'articles':records}
(audit/'fidelity-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(audit/'fidelity-diffs.patch').write_text(''.join(diffs))
print(json.dumps(report['coverage']|report['summary'],ensure_ascii=False))
print('missing examples',[(x['path'],x['old_exact_lines_missing'],x['redaction_marker_candidates'][:1]) for x in records if x.get('old_exact_lines_missing')][:30])
