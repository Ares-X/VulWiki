import pathlib, json, hashlib, subprocess
A=pathlib.Path('/tmp/vulwiki-pr11-20261004.yf3o4k')
R=pathlib.Path('/Users/aresx/.codex/worktrees/vulwiki-pr11-review-20261004/VulWiki')
M=json.loads((A/'correction-operations.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==M['frozen_head']
assert json.loads((A/'correction-acceptance.json').read_text())['result']=='PASS'
supp=json.loads((A/'supplemental-correction-acceptance.json').read_text())
assert supp.get('result')=='PASS',supp
for x in M['files']:
    assert hashlib.sha256((R/x['path']).read_bytes()).hexdigest()==x['before_sha256']
    assert hashlib.sha256(pathlib.Path(x['after_file']).read_bytes()).hexdigest()==x['after_sha256']
for x in M['files']:
    (R/x['path']).write_bytes(pathlib.Path(x['after_file']).read_bytes())

overlay=[dict(path=x['path'],before_sha256=x['before_sha256'],after_sha256=x['after_sha256'],operations=len(x['operations'])) for x in M['files']]
by_path={x['path']:x for x in overlay}
report='docs/reviews/20261004-pr11/REVIEW.md'
counts={}
for file,projection in [('KEV-CANDIDATES-20261003.json','candidate'),('KEV-REVIEW-PROGRESS-20261003.json','progress')]:
    p=R/'docs'/file;d=json.loads(p.read_text());updated=0
    for row in d['rows']:
        entries=row['review'].get('articles',[]) if projection=='candidate' else row.get('articles_in_current_batch',[])
        for entry in entries:
            change=by_path.get(entry['article'])
            if change:
                assert entry['sha256']==change['before_sha256']
                assert 'previous_sha256' not in entry
                entry['previous_sha256']=entry['sha256']
                entry['sha256']=change['after_sha256']
                entry['correction_review']=report
                updated+=1
    d['publication_editorial_correction_overlay']=dict(date='2026-10-04',reviewed_head=M['frozen_head'],review=report,reading_checkpoint_unchanged=True,article_count_unchanged=True,files=overlay)
    p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
    counts[projection]=updated
p=R/'docs/KEV-MATERIAL-GATE-20261003.json';d=json.loads(p.read_text())
assert 'publication_editorial_correction_overlay' not in d
d['publication_editorial_correction_overlay']=dict(date='2026-10-04',reviewed_head=M['frozen_head'],review=report,previous_gate_receipts_unchanged=True,reading_checkpoint_unchanged=True,files=overlay)
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(articles=len(M['files']),operations=sum(len(x['operations']) for x in M['files']),current_projection_edges_updated=counts,historical_gate_receipts_unchanged=True),ensure_ascii=False))
