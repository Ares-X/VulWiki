---
verification_source: "https://github.com/rapid7/metasploit-framework/blob/5e598d5233bebecef2a44904a286769d83d31d12/modules/exploits/linux/misc/fortimanager_rce_cve_2024_47575.rb"
source_url: "https://github.com/rapid7/metasploit-framework/blob/5e598d5233bebecef2a44904a286769d83d31d12/modules/exploits/linux/misc/fortimanager_rce_cve_2024_47575.rb"
source: "gelusus/wxvl 公众号漏洞文库"
cve: "CVE-2024-47575"
identifier_role: "primary"
primary_identifiers: "CVE-2024-47575"
referenced_identifiers: ""
identifier_status: "unknown"
title: "CVE-2024-47575 漏洞分析及三种利用方式"
product: "Fortinet FortiManager FGFM"
record_type: "analysis"
document_type: "FortiManager三条利用路径逆向分析"
review_status: "text-reviewed"
verification_status: "not-reproduced"
content_status: "needs-review"
prerequisites: "FGFM TCP541可达，TLS接受设备证书/私钥且serial/platform匹配；无需预先管理授权不等于无需设备信任；本次补证仅第三种rsh通道"
side_effects: "登记设备、建立shell通道、执行命令，fetch载荷可写/tmp；公开试用证书/私钥仅保留在来源，未配置或发送"
archive_url: "https://github.com/Ares-X/VulWiki/blob/41940cb0038d09ca5aaddbe5bffb923e423d210f/Web%E5%AE%89%E5%85%A8/%E5%85%B6%E4%BB%96%E8%BD%AF%E4%BB%B6/%E6%9D%82%E9%A1%B9/CVE-2024-47575%20%E6%BC%8F%E6%B4%9E%E5%88%86%E6%9E%90%E5%8F%8A%E4%B8%89%E7%A7%8D%E5%88%A9%E7%94%A8%E6%96%B9%E5%BC%8F.md"
archive_commit: "41940cb0038d09ca5aaddbe5bffb923e423d210f"
source_status: "recorded"
source_note: "source_url与verification_source记录本次公开补证来源；原归档转载的原始出处仍待补，补证来源不替代归档全篇的原始披露出处。该补证只支持正文区分出的第三种rsh路径，不替代其余两种方法的来源。"
previous_source_note: "原始出处待补；仓库归档不等同原始披露"
id: "vw-fa3d9e223e5d4fb64b6a28c9"
entity_id: "ve-fa3d9e223e5d4fb64b6a28c9"
schema_version: "1"
---

# CVE-2024-47575 漏洞分析及三种利用方式

<!-- vulwiki-editorial-rebuild:system-misc -->
## 条目范围与校订

- 本文对象：Fortinet FortiManager FGFM
- 文献类型：FortiManager三条利用路径逆向分析
- 版本、权限及部署边界：FGFM TCP541可达且可建立带FortiGate设备证书的TLS连接；主要分析7.4.1，对照7.6.0
- 核验状态：仅重建文本校订；未执行文中代码、PoC 或扫描，未把截图或转载声明记为本站复现

### 具体结论与待核项

以下为原归档的逐项勘误与证据缺口；可由文本确定的问题已在下文订正，仍缺来源的事实保持待核。

1. 未授权指未被FortiManager授权管理的设备，不代表完全无需设备证书/私钥；认证/设备信任层次需明确
2. 三方式分别connect_tcp到HTTP/jsonrpc的rcs/checkout、file_exchange put_json_cmd到som/export、7.6 connect_tcp shell，独立互补应保留而非三篇同文去重
3. FortiGate为接入设备，漏洞主产品FortiManager；fgfmd/fgfmsd名称需统一到对应build
4. 所有抓包和关键反汇编在图片，正文协议轮廓并非完整可复现报文，缺样例证书获取限制/私钥条件与实验输出文本
5. watchtowrLabs与attackerkb链接为空，厂商公告被引用却无URL；无完整受影响/修复矩阵
6. 固定偏移适用7.4.1，7.6版本差异作者已说明，应保留；版权来源追溯和重复声明需清理

### 操作风险

原文技术操作的实际副作用未复现核验；按其请求/代码评估状态变更、凭据暴露和业务影响

技术请求、代码与实验方法按原文保留；其中的破坏性动作仅限授权、可恢复的隔离环境。缺失代码、参数或版本事实不猜补。

### 来源追溯

- 原文参考链接（未重新核验）：<https://mp.weixin.qq.com/s?__biz=Mzk0OTU2ODQ4Mw==&mid=2247487321&idx=1&sn=64e8755abab262aca1104de5f3cceef3&scene=21#wechat_redirect>
- 原文参考链接（未重新核验）：<https://mp.weixin.qq.com/s?__biz=Mzk0OTU2ODQ4Mw==&mid=2247487296&idx=1&sn=4a1242ec620fb15daa80efad6cf99ae6&scene=21#wechat_redirect>
- 原文参考链接（未重新核验）：<https://mp.weixin.qq.com/s?__biz=Mzk0OTU2ODQ4Mw==&mid=2247487216&idx=1&sn=8b6fdfec8b4754eda7cfdbd4e8ab6a13&scene=21#wechat_redirect>
- 原文参考链接（未重新核验）：<https://mp.weixin.qq.com/s?__biz=Mzk0OTU2ODQ4Mw==&mid=2247487174&idx=1&sn=ba663a6a00d68f59a4ef637d6233d7b6&scene=21#wechat_redirect>
- 原始披露 URL 未确认；既有归档来源标签保留，不能替代原始公告

### 归档技术正文

原创 p1Kk  奇安信天工实验室   2025-06-04 03:30  
  
**目**  
  
**录**  
  
一、前  言  
  
二、FGFM  
  
三、漏洞利用方式一  
  
四、漏洞利用方式二  
  
五、漏洞利用方式三  
  
六、总  结  
  
  
**一**  
  
  
**前  言**  
  
2024年10月23日，Fortinet官方发布了针对CVE-2024-47575的安全公告：  
  
> A missing authentication for critical function vulnerability [CWE-306] in FortiManager fgfmd daemon may allow a remote unauthenticated attacker to execute arbitrary code or commands via specially crafted requests.  
  
  
  
表明该漏洞存在于fgfmd服务中，可能允许远程未经身份验证的攻击者通过特制的请求执行任意代码。本文主要分享之前对CVE-2024-47575的1day分析过程和其他利用方式的学习  
  
**二**  
  
  
**FGFM**  
  
FortiManager的FGFM功能允许管理员对FortiGate设备进行集中管理和配置。管理员可以通过FortiManager来查看和配置托管设备的接口、HA、DNS等设置，并进行路由管理。此外，FGFM还支持通过修订历史记录进行故障排除，帮助管理员识别和解决配置相关的问题‌。  
  
在FortiManager中处理FGFM请求的是fgfmsd进程，通过TCP端口541建立的SSL连接运行。  
  
**01**  
  
**FGFM协议结构**  
  
  
在之前对FortiGate-FGFM协议的分析中，我们用一种比较粗略的方式生成了合法的FGFM请求头，满足请求头第三字节低位等于1，第四字节小于等于2，以及长度检查；然后导出合法的Fortigate证书建立连接。  
  
![screenshot (1).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaA5ia3gdUcgp0LAibIBmu6lp2AUxg9oAOUvxOicSWoED6ibLYDhHMiaw7jnxQ/640?wx_fmt=png&from=appmsg "")  
  
![1.png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAApr5DRpQ03Um5AzzcYgcxkZaicvlpAs0f3SOZVedW2e9O3icSIACXvNQ/640?wx_fmt=png&from=appmsg "")  
  
  
但这次分析  
重新抓取fgfm请求可以得到原始请求格式。  
  
![screenshot (2).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAnTichzhMPNnmBuKJP7nsgXZTIHsa6Ymxv10iaLwxRvia2cslSPZ7wMJuQ/640?wx_fmt=png&from=appmsg "")  
  
![screenshot (3).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAUJHBKB3yAdEzmfuVWn0E8baE0450ZXn0eELRsGd2vFrQRJBa01kA5g/640?wx_fmt=png&from=appmsg "")  
  
分为几个部分：  
- magic_number == b'\x36\xe0\x11'  
  
- msg_type*   eg b'\x00'  
  
- len  
  
- command     eg ‘put script’  
  
- key-value      eg 'devid=0'  
  
- param_end == '\r\n'  
  
- end == '\r\n\r\n'  
  
*请求头第四字节决定了不同的分支  
  
  
![2.png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAYwtGeaVUicaXJqXdibkC7pPnJAjFfFLw0gAiaTEBhiboiaCqfEpj0N7vMfg/640?wx_fmt=png&from=appmsg "")  
  
**三**  
  
  
**漏洞利用方式一**  
  
  
以7.4.1版本为分析目标。  
  
请求  
类  
型  
为type 0  
时  
，根据不同的command 返回的  
request_type  
调用函数表  
0x42EB77  
中对应的处理函数：  
  
  
![3.png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaABKppbsHfceNibCAfOianvNP1tqkSsTSsSdKuicl1C1b9ZsG47aRKq3qRQ/640?wx_fmt=png&from=appmsg "")  
  
![4.png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAHwE1xDISica1HKML0AN1gCiaUpGic1FrRQhBQseBynvGMoK2YbYDVyo5Q/640?wx_fmt=png&from=appmsg "")  
  
当客户端C请求  
get connect_tcp  
时：  
  
![screenshot (4).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAib8HZ7tRricccYiara1ad0urn4icwkBXibYJ3D1sn7ct5ZFzHSUmjNEWBVg/640?wx_fmt=png&from=appmsg "")  
  
服务器S响应：  
  
![screenshot (5).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAHOYaJH9F7Giato2dMGcrKnXc5Uf3iac3U0RT35MKJc0ear5mKDPG9wUg/640?wx_fmt=png&from=appmsg "")  
  
客户端C请求  
localid  
 = 服务器S返回  
remoteid  
。  
  
服务器S同时也会返回一个  
localid  
用于对应  
C-localid  
和  
S-remoteid  
，标识信道。  
  
负责处理  
get connect_tcp  
请求的是  
connect_tcp  
函数：  
  
![screenshot (6).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaA2RaibnUym3fnXqhRZrxmYrM0LUhYTremjpJeqhagSXVUALrFr70Mmlw/640?wx_fmt=png&from=appmsg "")  
  
![5.png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAXhUs2hb2IlsXxbMLEaYq6xMHibSjFAY06Xdv7vDAIjicUGqfPjAvTExw/640?wx_fmt=png&from=appmsg "")  
  
  
svc http监听该套接字，并在  
libfmgsvrd.so  
中可以找到定义和回调函数：  
  
![screenshot (7).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAOzSfulDcIS6ErwicicMBuARpUbNlxwVbw3MfJTOicoLwqqsGWcCIT5RqQ/640?wx_fmt=png&from=appmsg "")  
  
![screenshot (8).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAdzUFbCpuf1EsevkbYkVeC508uCe50tR6YULnO80awVto3sd03NQ52g/640?wx_fmt=png&from=appmsg "")  
  
dmworker  
让我联想到之前的分析中，在  
libdmserver.so  
中  
off_FE84C0  
路由表注册了多个函数，最终在  
rcs/checkout  
对应函数  
dmworker_rcs_checkout  
中发现命令注入：  
  
![screenshot (9).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAYXGcyj792BUQ7lIWFbxRtZIOPlcAJUrT60wCZYVw9HPQiapVKSALpKg/640?wx_fmt=png&from=appmsg "")  
  
![screenshot (10).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAQORjjTicsicq7fx8DG6sJAg9suHp2y9ovdyVLGjg4QwW8QPrq6zlE1tw/640?wx_fmt=png&from=appmsg "")  
  
![screenshot (11).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAq6XbgKs7kFKiaMEfcWB1hUSnHxy2iaXmGcTIMBja9GvPibuX5rlAdF2UA/640?wx_fmt=png&from=appmsg "")  
  
查看使用  
libdmserver.so  
的进程，可以锁定  
dmworker  
：  
  
![screenshot (12).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaA3tQVLTVUaia355LxIxibbia13MyFfWKyWIuRXe4x1JS1Acd3ialeh4iavfQ/640?wx_fmt=png&from=appmsg "")  
  
启动  
dmworker  
调试可以捕获json请求格式：  
  
![screenshot (13).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaA1V1XjdXZbsDM577sDt9ZCpjqqQsa3tzUBVsVQT2sQNX7cjFiaiawKibcw/640?wx_fmt=png&from=appmsg "")  
  
该注入可通过认证后HTTP请求触发，但如何通过fgfm请求触发？  
  
继续分析fgfmsd，如果请求  
type 2  
会进入  
fgfm_chan_handler  
函数，通过  
localid  
标识 发送请求数据：  
  
![screenshot (14).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAClW1b5Qu9jrUo3oicapEARqeRgLftDkEY4YKoO8icG4t4xXqicoOOs4yg/640?wx_fmt=png&from=appmsg "")  
  
![screenshot (15).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaA9iaEicBfIWwKjib9qAKKJlZ3cqrOVmNNq5hibAA65RricaCmXtEbIJAATgw/640?wx_fmt=png&from=appmsg "")  
  
那么请求格式为：  
  
![screenshot (16).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAJyWhbK5nopwXqdRecnH3hJzacxy0KYWPpTM6jCX2jcHic5xfbYZRTicA/640?wx_fmt=png&from=appmsg "")  
  
发送该请求测试，并调试svc httpd进程发现会对  
(un)compressed_data  
检查是否为合法的HTTP请求格式，合法才会转发，将  
(un)compressed_data  
设置为合法的  
POST /jsonrpc  
请求头  
+dmworker  
请求体即可触发漏洞。  
  
**四**  
  
  
**漏洞利用方式二**  
  
  
第二种利用方法来自[watchtowrLabs]()  
。  
  
在分析get请求时发现一条命令  
put_json_cmd  
，当参数  
file_exch_cmd=put_json_cmd  
时进入下面的处理逻辑，解析json对象并将其传递给  
svc_rpc_uclient  
：  
  
![screenshot (17).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAaVcHTicJYjYFyCt5dvvq4ticWeuKNPTuMuuPicXKic4LsAJhJ3YeW8JBnA/640?wx_fmt=png&from=appmsg "")  
  
svc_rpc_uclient  
在  
libsvcclt.so  
中定义，通过对RPC调用终止位置进一步逆向分析，发现它通过  
Unix  
套接字进入了  
fdssrvd  
。  
  
在该文件中发现可以通过  
put_json_cmd  
接口访问的函数表，其中  
som/export  
对应的函数中存在命令注入：  
  
![screenshot (18).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAJVoHYT6NTa4GD10esr691vgFlfutH8hia0w6Uo4Ppkjwnd7drVZZ01A/640?wx_fmt=png&from=appmsg "")  
  
要触发  
som/export  
需要请求  
get file_exchange  
命令分配文件传输句柄。  
  
客户端请求：  
  
![screenshot (19).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAIM4BaN2f7Y5jm4HGs6wddCYOBCUoLHsnoLFGeZrwV7qGb1eN4nB0Bw/640?wx_fmt=png&from=appmsg "")  
  
服务器响应：  
  
![screenshot (20).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAtAEdWHWB9icQKdWvickeEsOZ4BxjdiahiayUnThhglKFgB4u28t7xUK1Uw/640?wx_fmt=png&from=appmsg "")  
  
同上面的分析，不通过  
type 2  
而是通过  
channel  
命令指明  
localid  
同样可以达到  
sub_40BB6D  
发送请求。  
  
watchtowrLabs在文末也分析了漏洞  
patch  
并发现了利用方式一的命令注入  
patch  
点但不知如何触发，相比该利用过程，第一种利用方法有点复杂走远了。  
  
**五**  
  
  
**漏洞利用方式三**  
  
  
在学习[attackerkb]()  
这篇文章对7.6.0版本的分析时，可以发现一些与7.4版本的不同之处。  
  
同样请求  
get connect_tcp  
，对应函数  
sub_1B978  
：  
  
![screenshot (21).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAzjqIscR40fJR1cY0DBZdqcovC3ibNHcQ8ry4Y09ZRWCuyVtwJaicFicJQ/640?wx_fmt=png&from=appmsg "")  
  
![screenshot (22).png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaAzQrWibVK1nYffoOibYrRAhicDibvoWfku0kBXkxJXV769xiaAN0JeladDNQ/640?wx_fmt=png&from=appmsg "")  
  
此时只是生成了一个   
shell  
，可通过  
channel  
请求 -> 调用  
fgfm_sock_write  
将输入和输出传输到服务器创建的新 FGFM通道（和前面原理一样通过  
localid  
匹配）。  
  
**六**  
  
  
**总  结**  
  
  
本文分享了三种针对CVE-2024-47575的利用方式，该漏洞成因是与未授权的设备建立不安全通信，结合（认证后）命令注入点实现远程代码执行。同时在漏洞刚披露时，我选择7.4大版本进行漏洞分析，随着网上漏洞分析文章的公开，对比7.4版本，7.6版本中的漏洞点非常明显利用也较简单，因此大家在以后做漏洞挖掘时可以多个大版本对比分析。  
  
  
【版权说明】  
  
【版权说明】  
  
本作品著作权归**p1Kk**  
所有  
  
未经作者同意，不得转载  
  
![头像.png](https://mmbiz.qpic.cn/mmbiz_png/9EP6QFMcTmQlkV6JSyH5qH9X5kVhGBiaA8YOmZ22Lica9r3cnsk2UbS3fGd7UZDTGZwN9b8bPIibxRknE1W3XGSOQ/640?wx_fmt=png&from=appmsg "")  
  
**p1Kk**  
  
  
天工实验室安全研究员  
  
专注于iot漏洞挖掘与利用  
  
  
**往期回顾**  
  
  
**0****1**  
  
[通用Linux x64内核态shellcode编写技巧](https://mp.weixin.qq.com/s?__biz=Mzk0OTU2ODQ4Mw==&mid=2247487321&idx=1&sn=64e8755abab262aca1104de5f3cceef3&scene=21#wechat_redirect)  
  
  
**0****2**  
  
[基于路由转发导致的权限认证绕过漏洞分析](https://mp.weixin.qq.com/s?__biz=Mzk0OTU2ODQ4Mw==&mid=2247487296&idx=1&sn=4a1242ec620fb15daa80efad6cf99ae6&scene=21#wechat_redirect)  
  
  
**0****3**  
  
[隐匿与追踪：Rootkit检测与绕过技术分析](https://mp.weixin.qq.com/s?__biz=Mzk0OTU2ODQ4Mw==&mid=2247487216&idx=1&sn=8b6fdfec8b4754eda7cfdbd4e8ab6a13&scene=21#wechat_redirect)  
  
  
**0****4**  
  
[二进制混淆对抗技术研究](https://mp.weixin.qq.com/s?__biz=Mzk0OTU2ODQ4Mw==&mid=2247487174&idx=1&sn=ba663a6a00d68f59a4ef637d6233d7b6&scene=21#wechat_redirect)  
  
  
  
![](https://mmbiz.qpic.cn/mmbiz_png/oJZWTpJpiae90UpibicIKeZgQTNjebiaOwStfe6MJ5J6RC7F9JDFdX2kaEwibFz7GewNtNyDek6SdENJrXjf0KXA2kg/640?wx_fmt=png "")  
  
**每周三更新一篇技术文章  点击关注我们吧！**  
  
  


---

> 来源：gelusus/wxvl（微信公众号漏洞文章自动归档，原始披露 URL 尚未确认，现有链接按来源追溯区分别标注）


## 2026-10-03 公开验证资料补充

[固定模块](https://github.com/rapid7/metasploit-framework/blob/5e598d5233bebecef2a44904a286769d83d31d12/modules/exploits/linux/misc/fortimanager_rce_cve_2024_47575.rb) 提供可逐字追溯的三阶段FGFM输入：设备登记、建立rsh通道、按返回localid发送命令数据。`send_packet` 明确协议标记与长度编码，弥补本页抓包全在未视检图片中的缺口。该模块走本页第三类通道路径，不代表另两种命令注入方法也逐一经过本次核验。

TLS连接仍要求目标接受设备证书及私钥，serial/platform需匹配。源码自带公开试用VM证书/私钥，可替换为操作者已有材料；这些原值保留在固定源文件，本次没有创建、配置或发送凭据。`check` 仅查看对端证书以识别FortiManager，不能证明其未打补丁；实际exploit会登记设备、建立shell通道并执行命令，fetch载荷还可能写/tmp。

[CNA](https://cveawg.mitre.org/api/cve/CVE-2024-47575) 分开列出FortiManager与FortiManager Cloud，不能把模块对Cloud6.4“全部版本”的概括当作精确矩阵。原文7.4.1、7.6.0研究环境与不同路径差异继续保留。修复按[FG-IR-24-423](https://fortiguard.fortinet.com/psirt/FG-IR-24-423)逐分支核对。本次全文读了模块和归档正文，未执行协议、未查看截图，未审阅框架及所选载荷的全部依赖。

“无需管理授权”仍以目标接受设备身份为前提，不能概括成无需任何证书、私钥或serial/platform条件。前两种图片路径未视检，其完成状态不由第三种rsh源码继承；FortiManager Cloud须按CNA/FG-IR-24-423逐分支核对，不能把Cloud6.4的概括扩展到其他分支。
