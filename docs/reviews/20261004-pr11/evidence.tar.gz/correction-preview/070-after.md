---
verification_source: "https://www.assetnote.io/resources/research/chaining-three-bugs-to-access-all-your-servicenow-data"
fixed_version: "CVE-2024-5217的独立CNA分支矩阵见补充正文；4879单列，不套用同一联合列表"
source_url: "https://www.assetnote.io/resources/research/chaining-three-bugs-to-access-all-your-servicenow-data"
cve: "CVE-2024-4879"
source: "gelusus/wxvl 公众号漏洞文库"
identifier_role: "primary"
primary_identifiers: "CVE-2024-4879;CVE-2024-5217"
referenced_identifiers: "CVE-2024-5178"
identifier_status: "active"
title: "【原作者复现通告】ServiceNow 存在代码注入漏洞（CVE-2024-4879、CVE-2024-5217）"
product: "ServiceNow Now Platform Jelly/Glide"
record_type: "analysis"
document_type: "技术文章（细分类待核）"
review_status: "text-reviewed"
verification_status: "not-reproduced"
content_status: "needs-review"
prerequisites: "受影响Now Platform的login.do模板链可达；GlideExpression Script为5217组件；5178文件限制绕过为独立链条条件，非单独匿名原语"
side_effects: "链条模板执行及数据库配置/账号资料读取；操作系统命令需额外MID等条件；不保证只读"
archive_url: "https://github.com/Ares-X/VulWiki/blob/41940cb0038d09ca5aaddbe5bffb923e423d210f/Web%E5%AE%89%E5%85%A8/%E5%85%B6%E4%BB%96%E8%BD%AF%E4%BB%B6/%E6%9D%82%E9%A1%B9/%E3%80%90%E5%B7%B2%E5%A4%8D%E7%8E%B0%E3%80%91ServiceNow%20%E5%AD%98%E5%9C%A8%E4%BB%A3%E7%A0%81%E6%B3%A8%E5%85%A5%E6%BC%8F%E6%B4%9E%EF%BC%88CVE-2024-4879%E3%80%81CVE-2024-5217%EF%BC%89.md"
archive_commit: "41940cb0038d09ca5aaddbe5bffb923e423d210f"
source_status: "recorded"
source_note: "source_url与verification_source记录本次公开补证来源；原归档转载的原始出处仍待补，补证来源不替代归档全篇的原始披露出处。"
previous_source_note: "原始出处待补；仓库归档不等同原始披露"
id: "vw-ca42bbdf4e03a1362efb04a7"
entity_id: "ve-ca42bbdf4e03a1362efb04a7"
schema_version: "1"
---

# 【原作者复现通告】ServiceNow 存在代码注入漏洞（CVE-2024-4879、CVE-2024-5217）

<!-- vulwiki-editorial-rebuild:system-misc -->
## 条目范围与校订

- 本文对象：ServiceNow Jelly/Glide
- 文献类型：技术文章（细分类待核）
- 版本、权限及部署边界：原文未给出可确认的版本、认证及部署边界；保留待核
- 核验状态：仅重建文本校订；未执行文中代码、PoC 或扫描，未把截图或转载声明记为本站复现

### 具体结论与待核项

以下为原归档的逐项勘误与证据缺口；可由文本确定的问题已在下文订正，仍缺来源的事实保持待核。

1. 元数据漏5217
2. 两漏洞影响矩阵混一起且各分支粘行
3. 三参考URL因序号连写成为错误地址
4. 复现仅作者声称和图片，不是可用PoC
5. 需按各官方KB核修复与CVSS，保留两独立类型不误删5217
6. 清营销

### 操作风险

原文技术操作的实际副作用未复现核验；按其请求/代码评估状态变更、凭据暴露和业务影响

技术请求、代码与实验方法按原文保留；其中的破坏性动作仅限授权、可恢复的隔离环境。缺失代码、参数或版本事实不猜补。

### 来源追溯

- 原始披露 URL 未确认；既有归档来源标签保留，不能替代原始公告

### 归档技术正文

原创 聚焦网络安全情报  安全聚   2024-07-12 19:00  
  
预警公告 **严重**  
  
近日，安全聚实验室监测到 ServiceNow 中存在代码注入漏洞 ，编号为：CVE-2024-4879、CVE-2024-5217，CVSS:9.8  该漏洞由于输入验证不严格允许未经身份验证的远程攻击者执行任意代码。  
  
  
**01**  
  
**漏洞描述**  
  
ServiceNow是一家提供企业级云计算服务的公司，其产品是一种基于云的服务管理解决方案，旨在帮助组织简化和自动化业务流程。ServiceNow的平台提供了各种功能，包括IT服务管理、IT运营管理、IT业务管理、客户服务管理、人力资源服务管理等，帮助企业提高效率、降低成本并提升服务质量。由于输入验证不严格，ServiceNow中的Jelly模板和Glide表达式存在注入漏洞，未经身份验证的攻击者可以通过构造恶意请求来利用这些漏洞，从而实现远程代码执行。  
  
**02**  
  
**影响范围**  
  
  
Utah < Patch 10 Hot Fix 3Utah < Patch 10a Hot Fix 2Utah < Patch 10b Hot Fix 1Vancouver < Patch 6 Hot Fix 2Vancouver < Patch 7 Hot Fix 3bVancouver < Patch 8 Hot Fix 4Vancouver < Patch 9 Hot Fix 1Vancouver < Patch 10Washington DC < Patch 1 Hot Fix 3bWashington DC < Patch 2 Hot Fix 2Washington DC < Patch 3 Hot Fix 2Washington DC < Patch 4Washington DC < Patch 5  
  
**03**  
  
**漏洞复现**  
  
目前，安全聚实验室已成功复现ServiceNow UI Jelly模板注入漏洞（CVE-2024-4879）和 ServiceNow Glide表达式注入漏洞（CVE-2024-5217）  
  
如需技术讨论请关注  
“**安全聚**  
”公众号  
  
![](https://mmbiz.qpic.cn/sz_mmbiz_png/Icw1mW4eH3fP7L0en60SF1ibBI2zSesHicwRseoUP2CzB4ibcBXomzXrX7xTu4lzulEibdysC6GghibpxjRF4ic82V4Q/640?wx_fmt=png&from=appmsg "")  
  
  
**04**  
  
**安全措施**  
  
  
目前厂商已发布可更新版本，建议用户尽快更新更高的版本或更新热补丁  
  
Utah >= Patch 10 Hot Fix 3Utah >= Patch 10a Hot Fix 2Utah >= Patch 10b Hot Fix 1Vancouver >= Patch 6 Hot Fix 2Vancouver >= Patch 7 Hot Fix 3bVancouver >= Patch 8 Hot Fix 4Vancouver >= Patch 9 Hot Fix 1Vancouver >= Patch 10Washington DC >= Patch 1 Hot Fix 3bWashington DC >= Patch 2 Hot Fix 2Washington DC >= Patch 3 Hot Fix 2Washington DC >= Patch 4Washington DC >= Patch 5  
  
下载链接：https://support.servicenow.com/kb?id=kb_article_view&sysparm_article=KB1648313  
  
**05**  
  
**参考链接**  
  
  
1.https://support.servicenow.com/kb?id=kb_article_view&sysparm_article=KB16442932.https://support.servicenow.com/kb?id=kb_article_view&sysparm_article=KB16451543.https://support.servicenow.com/kb?id=kb_article_view&sysparm_article=KB1648313  
  
**06**  
  
**技术支持**  
  
  
长按识别二维码，关注“**安全聚**”公众号，联系我们的团队技术支持。  
  
![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/Icw1mW4eH3f0EPFicEDoJgTxOg248sjyFribLQXHTQsQCnIpRGg4OgIoF6MxfibpiaOK7aZXgNejnNKMlWSg9pecaw/640?wx_fmt=jpeg&from=appmsg "")  
  
  
  
  
  


---

> 来源：gelusus/wxvl（微信公众号漏洞文章自动归档，原始披露 URL 尚未确认，现有链接按来源追溯区分别标注）


## CVE-2024-5217：GlideExpression Script与链条边界补充

2026-10-03静态审阅；保留原归档正文、请求和示例，不执行漏洞步骤。

[ServiceNow官方KB1648313](https://support.servicenow.com/kb?id=kb_article_view&sysparm_article=KB1648313)可读取的标题把CVE-2024-5217绑定到GlideExpression Script的输入验证问题；KB正文未取得，不宣称已阅读其登录后说明。[Adam Kues / Assetnote研究](https://www.assetnote.io/resources/research/chaining-three-bugs-to-access-all-your-servicenow-data)于2024-07-11公开，说明GlideExpressionScript的双引号命名空间检查可被单引号形式绕过，该步骤处于Jelly模板链中。

固定[4879算术模板](https://github.com/projectdiscovery/nuclei-templates/blob/9e93c63782dbb2b6160e068710d6240f418a3ed6/http/cves/2024/CVE-2024-4879.yaml)与[5217文件模板](https://github.com/projectdiscovery/nuclei-templates/blob/9e93c63782dbb2b6160e068710d6240f418a3ed6/http/cves/2024/CVE-2024-5217.yaml)共享该研究链，分别观察算术输出和glide.db.user等文件特征。两份模板不是隔离验证4879、5217、5178各缺陷的独立实验。co..nf经过路径清理成为conf的文件限制绕过属于额外步骤，不能直接算作5217单独文件读取能力；5178的CNA本身要求管理员权限，只作为链条相关编号。

第一编码变体中的%2B维持原值，额外解码条件仍未知。文件模板会读取数据库配置/账号资料；平台脚本执行、文件权限绕过及另需配置MID服务器的操作系统命令是不同层级，不以200或配置关键字宣称整机接管。更完整的共同Jelly根因由原研究和4879补充定位，本节不重复其所有通用段落。

CVE-2024-5217的CNA独立修复分支为：Utah Patch 10 Hot Fix 3；Utah Patch 10a Hot Fix 2；Utah Patch 10b Hot Fix 1；Vancouver Patch 6 Hot Fix 2；Vancouver Patch 7 Hot Fix 3b；Vancouver Patch 8 Hot Fix 4；Vancouver Patch 9 Hot Fix 1；Vancouver Patch 10；Washington DC Patch 1 Hot Fix 3b；Washington DC Patch 2 Hot Fix 2；Washington DC Patch 3 Hot Fix 2；Washington DC Patch 4；Washington DC Patch 5。4879矩阵单列，例如其Vancouver Patch9与本编号Patch9 Hot Fix1不同，不能套用粘连联合列表。
