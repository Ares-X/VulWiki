---
cve: "CVE-2026-9198"
source: "hatch 补库批 20260928"
title: "（CVE-2026-9198）IBM Langflow未认证RCE漏洞"
product: "Langflow"
record_type: "vulnerability"
review_status: "text-reviewed"
verification_status: "not-reproduced"
content_status: "needs-review"
identifier_status: "active"
primary_identifiers: "CVE-2026-9198"
referenced_identifiers: ""
identifier_role: "primary"
source_status: "unknown"
prerequisites: "原文未完整说明身份权限、部署配置和可达性；不能假定匿名、默认开启或所有版本适用。"
side_effects: "原文未完整记录副作用、清理步骤或运行验证；阅读样例不等于获准在真实系统执行。"
id: "vw-1642c1f6111bc35845d8c8c1"
entity_id: "ve-1642c1f6111bc35845d8c8c1"
schema_version: "1"
---

# （CVE-2026-9198）IBM Langflow未认证RCE漏洞

<!-- vulwiki-editorial:start -->
## 校订与适用边界


### 尚未解决的证据缺口

以下限制仍适用于后文历史材料；相关版本、结果或修复结论不能据此视为已验证：

- source只是补库批次
- 正文有PoC与NVD可保留为references
- 所谓FOFA/ZoomEye指纹实际是主动接口响应，不能当测绘查询
- AUTO_LOGIN<1.5默认与后续显式开启需分范围
- Bearer redacted占位泛化不影响理解但文档说明应一致
- PoC工具用法不等于完整可运行环境
- KEV加入/利用时间和root常见说法需证据

本页为文本校订，未执行代码、PoC 或目标请求；原图仅保留引用，未据此确认复现成功。
<!-- vulwiki-editorial:end -->

## 技术正文与历史材料

一、漏洞简介
------------

IBM Langflow OSS 默认部署下的未认证远程代码执行漏洞（CVE-2026-9198），CVSS 3.1 评分 9.8（Critical），CWE-94。漏洞由两个缺陷串联而成：`GET /api/v1/auto_login` 在 `AUTO_LOGIN` 开启（Langflow < 1.5 的默认值）时向任何无凭证调用者签发 **SUPERUSER** JWT（CVE-2026-9103）；`POST /api/v1/validate/code` 把用户提交的 Python 代码不经任何沙箱直接送进 `exec()`（CVE-2026-8481）。两者串联后，未认证攻击者以 Langflow 服务用户（常常是 root）的身份获得代码执行。传感器遥测显示利用尝试始于 2026 年 7 月 6 日——比 IBM 正式发布 CVE 早了 11 天；CISA 于 8 月 5 日将其列入 KEV。

二、漏洞影响
------------

-   产品：IBM Langflow OSS
-   版本：**1.0.0 – 1.10.0**（受影响）；修复版：**1.10.1**（IBM 官方建议升级）
-   组件/攻击向量：`/api/v1/auto_login` + `/api/v1/validate/code`，未认证远程
-   前提条件：`AUTO_LOGIN` 处于开启状态（< 1.5 版本默认开启；新版本需显式开启）
-   影响：以 Langflow 后端进程权限执行任意 Python 代码（常为 root）；Metasploit 已有对应利用模块（`exploit/multi/http/langflow_unauth_rce_cve_2026_9198`，PR #21753）

三、复现过程
------------

### 漏洞分析

以下为 0xdak/cve-2026-9198_exploit 的原理原文（忠实翻译）：

> 默认部署下 IBM Langflow OSS（1.0.0 – 1.10.0）的未认证远程代码执行。串联两个缺陷：
>
> - **CVE-2026-9103**——只要启用了 `AUTO_LOGIN`（Langflow `< 1.5` 中的默认值），`GET /api/v1/auto_login` 就向任何无凭证的调用者签发 **SUPERUSER** JWT。
> - **CVE-2026-8481**——`POST /api/v1/validate/code` 把用户提供的 Python 代码不经沙箱直接送进 `exec()`。
>
> 两者合在一起（**CVE-2026-9198**），未认证攻击者以 Langflow 服务用户的身份获得代码执行——而该用户常常是 `root`。
>
> **利用过程：**
> 1. 向 `/api/v1/auto_login` 请求一个 superuser Bearer `<redacted>`（无需认证）。
> 2. 向 `/api/v1/validate/code` 提交 payload。该端点为了"校验"代码而 `exec()` 执行它；Python 在**函数定义时**就会求值默认参数值，因此 payload 被包在函数默认参数里：
>
> ```python
> def _v(a=exec('<payload>')): pass
> ```
>
> 做命令执行时，payload 抛出一个异常，其消息即命令输出，端点会把该输出反射回响应（`function.errors[]`）。

### PoC（来源：https://github.com/0xdak/cve-2026-9198_exploit，仅限授权测试）

原仓库用法原文：

```
./exploit.py -t <target> [options]

  -t, --target     target host/IP (or full URL)          (required)
  -p, --port       Langflow port                          (default 7860)
  -c, --cmd        run a single shell command, print output
      --shell      interactive pseudo-shell (each line runs via the RCE)
      --lhost      reverse-shell listener IP
      --lport      reverse-shell listener port            (default 4444)
  -k, --token      use this Bearer <redacted> (skip auto_login)
      --timeout    HTTP timeout in seconds                (default 20)
      --no-banner  suppress the banner
  -h, --help       show help
```

另可交叉参考 ark0-nights/cve_exps（langflow-cve-2026-9198）的用法原文：

```bash
# 非破坏性检查：auto_login 是否会签发 superuser token？
python3 exp.py check http://127.0.0.1:7860

# RCE（默认执行 id）
python3 exp.py exploit http://127.0.0.1:7860
python3 exp.py exploit http://127.0.0.1:7860 -c 'cat /etc/passwd'

# 批量
python3 exp.py check targets.csv -o out.json
```

FOFA / ZoomEye 指纹（来源同上，脚本实际探测特征）：`GET/POST /api/v1/auto_login`（200 + `access_token`）、`POST /api/v1/validate/code`（200 + `function.errors`）；默认端口 7860。

*图片说明：PoC 仓库与公开分析中未提供可下载的复现截图，本条目无配图。*

四、修复建议
------------

1.  立即升级到 **Langflow OSS 1.10.1** 或更高版本；
2.  如暂不能升级：关闭 `AUTO_LOGIN`，或将其绑定到 loopback，仅允许本地访问 7860 端口；
3.  排查是否已被利用：检查 `/api/v1/auto_login` 的异常外部调用记录与 `/api/v1/validate/code` 的可疑 Python 提交。

### 附录

参考链接：

-   公开 PoC：https://github.com/0xdak/cve-2026-9198_exploit
-   交叉参考 PoC：https://github.com/k3ystr0k3r/cve-2026-9198
-   Metasploit 模块 PR：https://github.com/rapid7/metasploit-framework/pull/21753
-   NVD：https://nvd.nist.gov/vuln/detail/CVE-2026-9198
-   CISA KEV：https://www.cisa.gov/known-exploited-vulnerabilities-catalog

## KEV 公开验证材料补核（CVE-2026-9198，2026-10-03）

本节补充公开源代码和原作者测试记录，保留上文历史正文、引文、示例和既有占位符。收录依据是明确的两阶段输入及会话结果记录；本库没有执行 PoC、访问示例目标或验证会话。

### 实际前提与默认配置

[IBM CNA 记录](https://github.com/CVEProject/cvelistV5/blob/54d12b277c27b642b6dd41df67fb1244110610f4/cves/2026/9xxx/CVE-2026-9198.json)将 1.0.0 至 1.10.0 列为受影响范围，建议升级至 1.10.1。源码核对范围是 v1.8.4、v1.10.0、v1.10.1 三个标签，并非逐个版本运行测试。

上文“1.5 起必须显式开启 AUTO_LOGIN”的说法不成立：[v1.8.4 配置](https://github.com/langflow-ai/langflow/blob/6cb87cca4c868cad096fc14139e73157740b7419/src/lfx/src/lfx/services/settings/auth.py#L71-L82)、[v1.10.0 配置](https://github.com/langflow-ai/langflow/blob/9690e69e86954ba9856c6ef06db7721d5ffa4bab/src/lfx/src/lfx/services/settings/auth.py#L71-L82)及 [v1.10.1 配置](https://github.com/langflow-ai/langflow/blob/a66b75ac2603b26988fb6be95303fdc61f807190/src/lfx/src/lfx/services/settings/auth.py#L71-L82)均明确将 AUTO_LOGIN 默认设为 True。具体部署仍可通过 LANGFLOW_AUTO_LOGIN 覆盖；不能从版本号推定现场配置。

[v1.8.4 登录处理](https://github.com/langflow-ai/langflow/blob/6cb87cca4c868cad096fc14139e73157740b7419/src/backend/base/langflow/api/v1/login.py#L96-L142)在 AUTO_LOGIN 关闭时返回 403，开启时调用长期令牌函数。[该函数](https://github.com/langflow-ai/langflow/blob/6cb87cca4c868cad096fc14139e73157740b7419/src/backend/base/langflow/services/auth/service.py#L505-L534)取配置的超级用户或既有超级用户，签发令牌并更新 last_login；若数据库没有可用超级用户，则返回 400。验证接口本身依赖当前活动用户，因此这里要求令牌所对应的用户能够通过活动用户校验，是先取得令牌再提交代码的链条。

### 具体输入与结果证据

Richard Howe 的 [Metasploit 模块固定版本](https://github.com/rapid7/metasploit-framework/blob/1db4e20d0bbf660e862bd760ba23bf9a9b1cf071/modules/exploits/multi/http/langflow_unauth_rce_cve_2026_9198.rb#L70-L149)公开了完整请求构造：先 GET /api/v1/auto_login 读取 access_token，再以 Bearer 令牌向 /api/v1/validate/code POST JSON code。code 使用带 exec 装饰器的函数定义，装饰器在定义求值时执行框架生成的 Python payload，无须调用函数体。输入原文及全部异常分支见链接，未在本节替换或修补。

[同提交的模块文档](https://github.com/rapid7/metasploit-framework/blob/1db4e20d0bbf660e862bd760ba23bf9a9b1cf071/documentation/modules/exploit/multi/http/langflow_unauth_rce_cve_2026_9198.md#L1-L63)记录 Ubuntu Docker 中 Langflow 1.8.4 的安装方式、验证步骤和 Meterpreter session opened 输出。该输出是来源记录。版本接口命中、成功取得令牌或 validate/code 返回 HTTP 200，各自都不足以单独证明代码执行。

文档另称 authentication is enabled，但给出的 Docker 启动命令没有设置 LANGFLOW_AUTO_LOGIN=false；结合源码的 403 分支，这句话不能扩展为“关闭 AUTO_LOGIN 仍可通过此匿名链利用”。执行权限是后端进程权限，也不能普遍等同宿主机 root。

0xdak 的[原脚本固定版本](https://github.com/0xdak/CVE-2026-9198_exploit/blob/9160e17bdc5d93844390af1532c703258f5ff0df/exploit.py)已全文静态审阅：其函数默认参数、异常消息回传和反向连接代码可读，但 main 内先使用 TIMEOUT，后在第 129 行声明 global TIMEOUT。仅编译、不执行的语法检查报 name 'TIMEOUT' is used prior to global declaration。因此不能把该原文件称作开箱可运行 PoC；没有修改原脚本或据此否定另行提供完整输入及结果的 Metasploit 材料。

### 根因、修复与实体关系

[v1.8.4 validate_code](https://github.com/langflow-ai/langflow/blob/6cb87cca4c868cad096fc14139e73157740b7419/src/lfx/src/lfx/custom/validate.py#L31-L72)及 [v1.10.0 相同路径](https://github.com/langflow-ai/langflow/blob/9690e69e86954ba9856c6ef06db7721d5ffa4bab/src/lfx/src/lfx/custom/validate.py#L32-L73)会编译并 exec 函数定义。[v1.10.1](https://github.com/langflow-ai/langflow/blob/a66b75ac2603b26988fb6be95303fdc61f807190/src/lfx/src/lfx/custom/validate.py#L32-L79)将该段改为只编译，不再执行函数定义。这里只确认该调用路径的修复，不据此宣称整个产品没有其他可执行功能。

IBM 的 [CVE-2026-9103](https://github.com/CVEProject/cvelistV5/blob/54d12b277c27b642b6dd41df67fb1244110610f4/cves/2026/9xxx/CVE-2026-9103.json)和 [CVE-2026-8481](https://github.com/CVEProject/cvelistV5/blob/54d12b277c27b642b6dd41df67fb1244110610f4/cves/2026/8xxx/CVE-2026-8481.json)分别支持令牌签发及已认证代码验证执行的组成关系；9103 描述的路径多了一层 /login，而本次读取的路由和利用模块均为 /api/v1/auto_login，这个来源差异不能隐藏。现有 9198 条目保留主入口；CVE-2025-3248 的旧版直接匿名验证接口和 CVE-2025-34291 的浏览器跨域刷新链前提不同，不因共用 validate/code 合并实体。

### 历史时间线校正

上文写 CISA 于 8 月 5 日加入 KEV；同一[固定 CVE 记录的 CISA ADP 段](https://github.com/CVEProject/cvelistV5/blob/54d12b277c27b642b6dd41df67fb1244110610f4/cves/2026/9xxx/CVE-2026-9198.json#L151-L180)中，dateAdded 与时间线均为 2026-08-04。保留上文原值，在此按 CISA ADP 更正目录加入日期；不能把 ADP 的次日更新时间当作加入日期。7 月 6 日遥测主张本轮仍未获得独立原始证据。

### 副作用与阅读边界

取得令牌会更新用户登录记录；利用阶段真正执行 Python，默认 Metasploit payload 建立反向 TCP 会话，并将得到的令牌保存到操作者 loot 文件。不能称为只读探测。后续命令、文件操作或其他载荷的影响取决于输入，来源未给统一清理流程。

已读完整模块及配套文档、0xdak 脚本与 README、相关 CNA 字段，以及上述默认配置、路由、令牌函数和验证函数。未运行任何代码、安装利用依赖或审计整个 Metasploit/Langflow 依赖树；其他交叉引用脚本不因链接存在而视作已审。IBM 支持网页本轮只返回 Site Unavailable，版本与修复结论由 CNA 和对应标签源码交叉支持。
