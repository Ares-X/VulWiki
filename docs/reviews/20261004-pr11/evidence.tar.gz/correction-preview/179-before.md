---
cve: "CVE-2026-0257"
date: "2026-06-05"
ref: "https://horizon3.ai/attack-research/vulnerabilities/cve-2026-0257/"
source: "gelusus/wxvl 公众号漏洞文库"
id: "vw-114665a8f6312a37e66e5fe1"
entity_id: "ve-114665a8f6312a37e66e5fe1"
schema_version: "1"
title: "CVE-2026-0257 | Palo Alto Networks PAN-OS GlobalProtect Authentication Bypass Vulnerability | Active Exploitation"
product: "标题声称PAN-OS GlobalProtect"
record_type: "vulnerability"
review_status: "text-reviewed"
verification_status: "not-reproduced"
content_status: "needs-review"
identifier_status: "unknown"
identifier_role: "primary"
primary_identifiers: "CVE-2026-0257"
referenced_identifiers: ""
prerequisites: "无"
archive_url: "https://github.com/Ares-X/VulWiki/blob/41940cb0038d09ca5aaddbe5bffb923e423d210f/Web%E5%AE%89%E5%85%A8/%E7%BD%91%E7%BB%9C%E8%AE%BE%E5%A4%87/Palo%20Alto/CVE-2026-0257%20_%20Palo%20Alto%20Networks%20PAN-OS%20GlobalProtect%20Authentication.md"
review_date: "2026-10-02"
side_effects: "本篇未提供足以确认无副作用的完整验证流程；应依正文所述配置、权限与交互前提评估，不能把通告或截图当成可直接运行的检测脚本"
source_status: "unknown"
---

# CVE-2026-0257 | Palo Alto Networks PAN-OS GlobalProtect Authentication Bypass Vulnerability | Active Exploitation

## 公开 Cookie 验证代码与配置条件（2026-10-03）

原归档只有导航。本次完整静态读取 Rapid7 研究者 sfewer-r7 仓库提交 `35ca8900bbca460cc3a1de08fe2bf95e3a9d6004` 的 [forge_cookie.py](https://github.com/sfewer-r7/CVE-2026-0257/blob/35ca8900bbca460cc3a1de08fe2bf95e3a9d6004/forge_cookie.py) 与 [Readme.md](https://github.com/sfewer-r7/CVE-2026-0257/blob/35ca8900bbca460cc3a1de08fe2bf95e3a9d6004/Readme.md)，并对照厂商配置说明。这是公开的具体验证输入，不是仅依据 KEV 或产品版本推测。

脚本从指定主机的 TLS 证书链提取公钥，构造含用户名、域、客户端信息及时间戳的 Cookie，再在 `test_cookie()` 中以完整表单 POST 至 `/ssl-vpn/login.esp`。缺陷在于解密后的身份信息被信任而缺少相应完整性验证。它逐个尝试证书链公钥，不是任何一张门户证书都必然能成功。[Rapid7 原始分析](https://www.rapid7.com/blog/post/etr-rapid7-observed-exploitation-of-pan-os-globalprotect-authentication-bypass-vulnerability-cve-2026-0257/)

### 可用条件

需启用 GlobalProtect 门户或网关的 authentication override cookies，且用于 Cookie 的证书被复用于外部可取得公钥的功能；不能把所有启用 GlobalProtect 的设备视为同等可利用。研究者使用 PAN-OS 10.2.8 的特定配置。厂商按维护线给出修复，如 10.2.10-h36、11.1.10-h25、11.2.10-h7、12.1.4-h6，完整范围以[官方表](https://security.paloaltonetworks.com/CVE-2026-0257)及实际维护线为准；不要按跨分支数字大小比较。Prisma Access 使用其对应更新，Panorama 与 Cloud NGFW 被公告排除。

厂商建议专用的新 Cookie 证书；仅从其他服务撤下曾公开使用的旧证书不足以撤销已经取得的公钥。修补后 Cookie 会更新并要求用户重新认证。厂商提供的混合版本兼容开关会暂时恢复旧校验行为，不能把“安装补丁”和“已经启用新校验”合并成一个判断。本次没有改变任何配置。

### 完整文件的静态审计

- 代码会发起真实认证尝试、取回连接信息并打印 Cookie / token；它并没有建立完整 VPN 数据隧道。出现认证响应不等于已经完成内网访问。
- 成功判据是响应包含 Success，或 argument 与指定用户名等文本，没有严格解析完整认证状态。不能把匹配文本直接升级为获得任意权限。
- 代码关闭 TLS 校验；证书提取存在不同 Python API 路径与 TLS 1.2 回退。依赖 `cryptography` 的实际版本、证书类型兼容性、网络异常及完整运行时未验证。
- 未见固定第三方回连、下载执行、写入目标配置或持久账号创建；目的主机由参数指定。HTTP 使用标准库默认重定向行为，操作者仍需确认响应归属。没有自动注销/撤销令牌步骤。

代码、README 和研究中的公开测试值均未修改。本库未导入或运行脚本，未安装依赖，未向任何目标发送请求。SHA-256 与固定 URL 记录在本轮资料凭据中；这些静态观察不构成全供应链无后门保证。


<!-- article-review:devices:begin -->
## 技术校订与证据边界（2026-10-02）

- 产品/组件：标题声称PAN-OS GlobalProtect
- 本文讨论：标题CVE-2026-0257；正文无漏洞资料
- 版本、权限与配置前提：无
- 资料类型：抓取失败导航残片；本次仅核对归档正文，未执行 PoC、未请求目标，未把原作者的“复现成功”继承为本库验证结果

### 逐项校订

- 正文全部为两轮站点导航，末尾截断在US Pu，无技术正文

### 操作风险与恢复

- 本篇未提供足以确认无副作用的完整验证流程；应依正文所述配置、权限与交互前提评估，不能把通告或截图当成可直接运行的检测脚本

### 待核与来源

- 标题身份验证绕过/在野利用主张及版本无法由本文验证
- 引用图片未查看，截图内容及有效性待核验
- 文内原始链接和图片引用继续保留；未检查图片像素、未下载或执行外部附件。版本边界、修复/在野状态及厂商归属若缺一手依据，均不能视为本次已确认
- 下方保留原技术正文与载荷；其中历史时间表述和成功主张应按本节限定阅读
<!-- article-review:devices:end -->


[Skip to main content](#brx-content)
[Skip to footer](#brx-footer)

New at Horizon3.ai

[Mythos has collapsed the attack path. | **Learn how to prove your defenses now. →**](https://horizon3.ai/mythos-exposed-cybersecurity-gap/)

[![Renmoe Library](https://horizon3.ai/wp-content/uploads/2026/04/horizon-logo-2026.svg)](https://horizon3.ai)

* Solutions

  + Autonomous Pentesting
  + [Internal Pentesting](https://horizon3.ai/nodezero/internal-pentesting/)
  + [External Pentesting](https://horizon3.ai/nodezero/external-pentesting/)
  + [Kubernetes Pentesting](https://horizon3.ai/nodezero/kubernetes-pentesting/)
  + [Cloud Pentesting](https://horizon3.ai/nodezero/cloud-pentesting/)
  + [Active Directory](https://horizon3.ai/nodezero/ad-password-audit/)
  + [Vulnerability Management Hub](https://horizon3.ai/vulnerability-management-hub/)
  + [Threat Informed Perspectives](https://horizon3.ai/threat-informed-perspectives/)

  + [Risk Based Vulnerability Management](https://horizon3.ai/risk-based-vulnerability-management/)
  + [High-Value Targeting](https://horizon3.ai/high-value-targeting/)
  + [Advanced Data Pilfering](https://horizon3.ai/advanced-data-pilfering/)
  + [Threat Actor Intelligence](https://horizon3.ai/threat-actor-intelligence/)
  + [Vulnerability Risk Intelligence](https://horizon3.ai/vulnerability-risk-intelligence/)

  + Security Control Validation
  + [Endpoint Security Effectiveness](https://horizon3.ai/endpoint-security-effectiveness/)
  + [Identity Security Validation](https://horizon3.ai/identity-security-validation/)
  + [Data Security Effectiveness](https://horizon3.ai/use-case/data-security-effectiveness/)

  + [Threat Detection & Response](https://horizon3.ai/use-case/threat-detection-response/)
  + [Tripwires](https://horizon3.ai/use-case/threat-detection-response/)
  + [AD Tripwires](https://horizon3.ai/ad-tripwires/)

  [Third-Party Risk Management](https://horizon3.ai/use-case/third-party-risk-management/)

  + CISA KEV Exploitation
  + [Rapid Response](https://horizon3.ai/nodezero/rapid-response/)
* Platform

  + [The NodeZero Platform](https://horizon3.ai/nodezero/)
  + [AI in Horizon3.ai](https://horizon3.ai/ai-in-horizon3-ai/)
  + [MCP Server](https://horizon3.ai/mcp-server/)

  + [NodeZero for Compliance](https://horizon3.ai/compliance/)
  + [PCI Compliance](https://horizon3.ai/compliance/pci-pentesting/)
  + [NIS 2 Compliance](https://horizon3.ai/compliance/nis-2-compliance/)

  [Why Our Platform Wins](https://horizon3.ai/why-our-platform-wins/)

  + [Who Uses NodeZero?](https://horizon3.ai/who-uses-nodezero/)
  + [ITOps and SecOps](/who-uses-nodezero#itops)
  + [Security Teams](/who-uses-nodezero#security-teams)
  + [Pentesters](/who-uses-nodezero#pentesters)

  + Autonomously Solving Cyber Ranges
  + [NodeZero vs. GOAD](https://horizon3.ai/nodezero-vs-goad/)
  + [Hack The Box (HTB) Attack Stories](https://horizon3.ai/use-case/hack-the-box-htb-attack-stories/)

  + Industries
  + [NodeZero Federal™](https://horizon3.ai/vertical/federal/)
  + [Financial Services](https://horizon3.ai/use-case/nodezero-for-financial-services/)
  + [Healthcare](https://horizon3.ai/use-case/for-healthcare/)
  + [US Public Sector](https://horizon3.ai/use-case/us-public-sector/)

  + [NodeZero Packages](https://horizon3.ai/use-case/packaging/)
* Resources

  + [Attack Research](https://horizon3.ai/category/attack-research/)
  + [Resource Center](https://horizon3.ai/resource-center/)
  + [Events](https://horizon3.ai/events/)

  + [The Exploit Window Is Shrinking. Most Security Workflows Are Not.](https://horizon3.ai/intelligence/blogs/exploit-window-shrinking-rapid-response/)

    June 1, 2026  |  [Blogs](https://horizon3.ai/category/intelligence/blogs/)
  + [AI Has Ideas. sqlmap Has Receipts.](https://horizon3.ai/intelligence/blogs/ai-has-ideas-sqlmap-has-receipts/)

    May 29, 2026  |  [Blogs](https://horizon3.ai/category/intelligence/blogs/)
  + [You’re Only as Secure as Your Last Evaluation](https://horizon3.ai/intelligence/blogs/cmmc-supply-chain-risk-validation/)

    May 18, 2026  |  [Blogs](https://horizon3.ai/category/intelligence/blogs/)
  + [From Patch Tuesday to Pentest Wednesday®: How a Software Provider Closed Unknown Paths to Cloud Compromise](https://horizon3.ai/intelligence/blogs/patch-tuesday-to-pentest-wednesday-cloud-compromise/)

    May 13, 2026  |  [Blogs](https://horizon3.ai/category/intelligence/blogs/)

  + Use Cases
  + [Education](https://horizon3.ai/use-case/nodezero-in-education/)
  + [Manufacturing](https://horizon3.ai/use-case/nodezero-in-manufacturing/)
  + [Supply Chain](https://horizon3.ai/use-case/nodezero-for-supply-chain/)
  + [MSSP and MSP](https://horizon3.ai/partners/mssp-msp/)
* Company

  + [About Us](https://horizon3.ai/horizon3-security-vision/)
  + [Leadership](https://horizon3.ai/about-us/)
  + [Careers](https://horizon3.ai/join-our-team/)
  + [In the News](https://horizon3.ai/category/news/press-release/)
  + [Contact Us](https://horizon3.ai/contact-us/)
* [Partners](https://horizon3.ai/partners/)
* [Login](https://portal.horizon3ai.com/)
* [Schedule a demo](https://horizon3.ai/contact-us/schedule-demo/)

* Solutions

  + Autonomous Pentesting
  + [Internal Pentesting](https://horizon3.ai/nodezero/internal-pentesting/)
  + [External Pentesting](https://horizon3.ai/nodezero/external-pentesting/)
  + [Kubernetes Pentesting](https://horizon3.ai/nodezero/kubernetes-pentesting/)
  + [Cloud Pentesting](https://horizon3.ai/nodezero/cloud-pentesting/)
  + [Active Directory](https://horizon3.ai/nodezero/ad-password-audit/)
  + [Vulnerability Management Hub](https://horizon3.ai/vulnerability-management-hub/)
  + [Threat Informed Perspectives](https://horizon3.ai/threat-informed-perspectives/)

  + [Risk Based Vulnerability Management](https://horizon3.ai/risk-based-vulnerability-management/)
  + [High-Value Targeting](https://horizon3.ai/high-value-targeting/)
  + [Advanced Data Pilfering](https://horizon3.ai/advanced-data-pilfering/)
  + [Threat Actor Intelligence](https://horizon3.ai/threat-actor-intelligence/)
  + [Vulnerability Risk Intelligence](https://horizon3.ai/vulnerability-risk-intelligence/)

  + Security Control Validation
  + [Endpoint Security Effectiveness](https://horizon3.ai/endpoint-security-effectiveness/)
  + [Identity Security Validation](https://horizon3.ai/identity-security-validation/)
  + [Data Security Effectiveness](https://horizon3.ai/use-case/data-security-effectiveness/)

  + [Threat Detection & Response](https://horizon3.ai/use-case/threat-detection-response/)
  + [Tripwires](https://horizon3.ai/use-case/threat-detection-response/)
  + [AD Tripwires](https://horizon3.ai/ad-tripwires/)

  [Third-Party Risk Management](https://horizon3.ai/use-case/third-party-risk-management/)

  + CISA KEV Exploitation
  + [Rapid Response](https://horizon3.ai/nodezero/rapid-response/)
* Platform

  + [The NodeZero Platform](https://horizon3.ai/nodezero/)
  + [AI in Horizon3.ai](https://horizon3.ai/ai-in-horizon3-ai/)
  + [MCP Server](https://horizon3.ai/mcp-server/)

  + [NodeZero for Compliance](https://horizon3.ai/compliance/)
  + [PCI Compliance](https://horizon3.ai/compliance/pci-pentesting/)
  + [NIS 2 Compliance](https://horizon3.ai/compliance/nis-2-compliance/)

  [Why Our Platform Wins](https://horizon3.ai/why-our-platform-wins/)

  + [Who Uses NodeZero?](https://horizon3.ai/who-uses-nodezero/)
  + [ITOps and SecOps](/who-uses-nodezero#itops)
  + [Security Teams](/who-uses-nodezero#security-teams)
  + [Pentesters](/who-uses-nodezero#pentesters)

  + Autonomously Solving Cyber Ranges
  + [NodeZero vs. GOAD](https://horizon3.ai/nodezero-vs-goad/)
  + [Hack The Box (HTB) Attack Stories](https://horizon3.ai/use-case/hack-the-box-htb-attack-stories/)

  + Industries
  + [NodeZero Federal™](https://horizon3.ai/vertical/federal/)
  + [Financial Services](https://horizon3.ai/use-case/nodezero-for-financial-services/)
  + [Healthcare](https://horizon3.ai/use-case/for-healthcare/)
  + [US Pu...

---

> 来源：gelusus/wxvl（微信公众号漏洞文章自动归档，原文见文首链接）
