---
cve: "CVE-2024-28987"
source: "gelusus/wxvl 公众号漏洞文库"
identifier_role: "primary"
primary_identifiers: "CVE-2024-28987"
referenced_identifiers: ""
identifier_status: "active"
title: "【PoC】SolarWinds Web Help Desk (CVE-2024-28987)严重漏洞的 PoC 已发布"
product: "SolarWinds Web Help Desk28987"
record_type: "unknown"
document_type: "技术文章（细分类待核）"
review_status: "text-reviewed"
verification_status: "not-reproduced"
content_status: "needs-review"
prerequisites: "缺受影响build和hotfix编号"
side_effects: "原文技术操作的实际副作用未复现核验；按其请求/代码评估状态变更、凭据暴露和业务影响"
archive_url: "https://github.com/Ares-X/VulWiki/blob/41940cb0038d09ca5aaddbe5bffb923e423d210f/Web%E5%AE%89%E5%85%A8/%E5%85%B6%E4%BB%96%E8%BD%AF%E4%BB%B6/%E6%9D%82%E9%A1%B9/%E3%80%90PoC%E3%80%91SolarWinds%20Web%20Help%20Desk%20%28CVE-2024-28987%29%E4%B8%A5%E9%87%8D%E6%BC%8F%E6%B4%9E%E7%9A%84%20PoC%20%E5%B7%B2%E5%8F%91%E5%B8%83.md"
archive_commit: "41940cb0038d09ca5aaddbe5bffb923e423d210f"
source_status: "recorded"
source_note: "source_url与verification_source记录本次公开补证来源；原归档转载的原始出处仍待补，补证来源不替代归档全篇的原始披露出处。"
previous_source_note: "原始出处待补；仓库归档不等同原始披露"
id: "vw-3e69b5c73e1c0458bd628ca6"
entity_id: "ve-3e69b5c73e1c0458bd628ca6"
schema_version: "1"
verification_source: "https://www.horizon3.ai/attack-research/cve-2024-28987-solarwinds-web-help-desk-hardcoded-credential-vulnerability-deep-dive/"
source_url: "https://www.horizon3.ai/attack-research/cve-2024-28987-solarwinds-web-help-desk-hardcoded-credential-vulnerability-deep-dive/"
---

# 【PoC】SolarWinds Web Help Desk (CVE-2024-28987)严重漏洞的 PoC 已发布

## CVE-2024-28987 技术补充

2026-10-03静态核对；未执行代码或请求目标。保留现有原文、示例和图片，本补充独立记录。

[Horizon3原始研究](https://www.horizon3.ai/attack-research/cve-2024-28987-solarwinds-web-help-desk-hardcoded-credential-vulnerability-deep-dive/)于2024-09-25说明OrionTicketController继承BasicAuthRouteController，后者直接内嵌helpdeskIntegrationUser / dev-C4F8025E7。2021年对AppProperties集中凭据的随机化未覆盖这组直接字符串。它与28986反序列化不是同一实体。

固定Metasploit模块5e598d5233bebecef2a44904a286769d83d31d12已全文读，向helpdesk/WebObjects/Helpdesk.woa/ra/OrionTickets发带Basic认证的GET。check只按状态码判断，run进一步要求JSON含shortSubject，再将响应存为本地loot。TICKET_COUNT限制显示条数，不限制服务器返回或本地保存全部结果，不能称只取十张工单。

[CNA](https://cveawg.mitre.org/api/cve/CVE-2024-28987)列12.8.3 Hotfix1及更早受影响，并指向12.8.3 Hotfix2修复；不应简写成所有12.8.3都受影响。原报告展示凭据能够支持CRUD，但所审模块只做读取，不能把一般CRUD影响说成这份模块主动修改工单。副作用含工单/可能敏感内容访问、服务器日志与本地文件写入。未安装框架或执行源码；依赖框架不在审计范围。


<!-- vulwiki-editorial-rebuild:system-misc -->
## 条目范围与校订

- 本文对象：SolarWinds Web Help Desk28987
- 文献类型：技术文章（细分类待核）
- 版本、权限及部署边界：缺受影响build和hotfix编号
- 核验状态：仅重建文本校订；未执行文中代码、PoC 或扫描，未把截图或转载声明记为本站复现

### 具体结论与待核项

以下为原归档的逐项勘误与证据缺口；可由文本确定的问题已在下文订正，仍缺来源的事实保持待核。

1. 硬编码凭据绕过与28986独立漏洞不可合并
2. 827公开实例不等于确认易受攻击
3. 缺受影响build和hotfix编号
4. 远程读改工单不等于主机RCE，本文已明确边界需保留
5. Horizon3一手研究与PoC链接齐全，需提最小请求和结果而非仅工具指向

### 操作风险

原文技术操作的实际副作用未复现核验；按其请求/代码评估状态变更、凭据暴露和业务影响

技术请求、代码与实验方法按原文保留；其中的破坏性动作仅限授权、可恢复的隔离环境。缺失代码、参数或版本事实不猜补。

### 来源追溯

- 原始披露 URL 未确认；既有归档来源标签保留，不能替代原始公告

### 归档技术正文

 独眼情报   2024-09-26 10:14  
  
有关 CVE-2024-28987 的详细信息和概念验证 (PoC) 漏洞代码现已公开，该漏洞是最近修补的 SolarWinds Web 帮助台 (WHD) 漏洞，未经身份验证的攻击者可以利用该漏洞远程读取和修改所有帮助台票证详细信息。  
  
![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/KgxDGkACWnQrXPKWkjOVJJknFWor04jjbEibRbticKWOYuWBpC9OlDbrGVAhHCvEwfuvXiblVY0gUqMGic6bC0g4uw/640?wx_fmt=other&from=appmsg "")  
  
Horizon3.ai 的 Zach Hanley 发现并向 SolarWinds 报告了此漏洞，他指出：“在评估我们自己客户的暴露情况时，我们发现组织通常会泄露 IT 流程的敏感流程信息，例如用户入职、密码重置和访问共享资源。虽然此漏洞不会导致 WHD 服务器本身完全被攻陷，但我们发现通过凭证进行横向移动的风险很高。”  
### CVE-2024-28987 被利用的风险  
  
CVE-2024-28987 源自硬编码的开发人员登录凭据，可用于在特定 WHD 端点上执行创建、读取、更新和删除操作。  
  
这个用于转储易受攻击的服务器上的最新票证详细信息的 PoC 现在可以可  
在 GitHub 上  
获取。  
  
针对 CVE-2024-28987 的修补程序已于  
一个月前  
发布。  
  
Hanley 表示，他们发现互联网上大约有 827 个 SolarWinds Web Help Desk 实例。虽然有些实例可能已经更新，不再容易受到此漏洞的攻击，但肯定还有一些实例仍可能被成功攻击。  
  
他指出：“根据对那些在互联网上和我们自己的客户群中接触过 WHD 应用程序的人的简单调查，WHD 应用程序似乎在州、地方和教育 (SLED) 市场领域很受欢迎。”  
  
这可能是管理员最后一次更新其安装的呼吁，否则攻击者就会采取行动并开始翻找他们的帮助台票据 - 尤其是因为另一个最近修补的 SolarWinds WHD 漏洞 CVE-2024-28986 正被  
攻击者  
积极利用。  
  
  
**免责申明：**  
  
**信息整理于网络，风险与后果自行判断，一切后果与本公众号无关！**  
> PoC:  
  
https://github.com/horizon3ai/CVE-2024-28987  
  
  
  
> 具体分析：https://www.horizon3.ai/attack-research/cve-2024-28987-solarwinds-web-help-desk-hardcoded-credential-vulnerability-deep-dive/  
  
  
  
  
  


---

> 来源：gelusus/wxvl（微信公众号漏洞文章自动归档，原始披露 URL 尚未确认，现有链接按来源追溯区分别标注）
