---
source: "gelusus/wxvl 公众号漏洞文库"
cve: "CVE-2025-39682"
identifier_role: "primary"
primary_identifiers: "CVE-2025-39682"
referenced_identifiers: ""
identifier_status: "unknown"
title: "(7.1分) CVE-2025-39682：Linux内核TLS UAF本地提权"
product: "Linux内核net/tls"
record_type: "analysis"
document_type: "漏洞分析摘要"
review_status: "text-reviewed"
verification_status: "not-reproduced"
content_status: "needs-review"
prerequisites: "本地低权限、kTLS接收路径；6.12.41崩溃实验；列分支修复6.1.149/6.6.103/6.12.44/6.16.4/6.17-rc3"
side_effects: "正文仅公开崩溃PoC，开头直接root与红队一步到位说法超出所呈证据；末尾承认可用完整LPE仍待出现"
archive_url: "https://github.com/Ares-X/VulWiki/blob/41940cb0038d09ca5aaddbe5bffb923e423d210f/%E7%B3%BB%E7%BB%9F%E5%AE%89%E5%85%A8/Linux/%287.1%E5%88%86%29%20CVE-2025-39682%EF%BC%9ALinux%E5%86%85%E6%A0%B8TLS%20UAF%E6%9C%AC%E5%9C%B0%E6%8F%90%E6%9D%83.md"
archive_commit: "41940cb0038d09ca5aaddbe5bffb923e423d210f"
source_status: "missing"
source_note: "原始出处待补；仓库归档不等同原始披露"
id: "vw-82fd4c703617dfab23bb5b56"
entity_id: "ve-82fd4c703617dfab23bb5b56"
schema_version: "1"
---

# (7.1分) CVE-2025-39682：Linux内核TLS UAF本地提权

<!-- vulwiki-editorial-rebuild:system-misc -->
## 条目范围与校订

- 本文对象：Linux内核net/tls
- 文献类型：漏洞分析摘要
- 版本、权限及部署边界：本地低权限、kTLS接收路径；6.12.41崩溃实验；列分支修复6.1.149/6.6.103/6.12.44/6.16.4/6.17-rc3
- 核验状态：仅重建文本校订；未执行文中代码、PoC 或扫描，未把截图或转载声明记为本站复现

### 具体结论与待核项

以下为原归档的逐项勘误与证据缺口；可由文本确定的问题已在下文订正，仍缺来源的事实保持待核。

1. 正文仅公开崩溃PoC，开头直接root与红队一步到位说法超出所呈证据；末尾承认可用完整LPE仍待出现
2. 影响范围6.0–6.1.148、6.2–6.6.102等跨分支区间容易误解，应表达每条维护分支边界与引入commit
3. lsmod/ss只能辅助，模块未加载不能证明低权限攻击者无法启用kTLS；应区别服务当前使用与攻击者可达配置
4. STAR Labs/CISA链接较好，但KEV确认/CVSS与修复版本仍需外部核验；容器逃逸仅推测
5. 关联另一篇三个Linux KEV新闻，后者为事件状态补充而非同文删除

### 操作风险

正文仅公开崩溃PoC，开头直接root与红队一步到位说法超出所呈证据；末尾承认可用完整LPE仍待出现

技术请求、代码与实验方法按原文保留；其中的破坏性动作仅限授权、可恢复的隔离环境。缺失代码、参数或版本事实不猜补。

### 来源追溯

- 原文参考链接（未重新核验）：<https://starlabs.sg/advisories/25/25-39682/>
- 原文参考链接（未重新核验）：<https://www.cisa.gov/known-exploited-vulnerabilities-catalog#CVE-2025-39682>
- 原始披露 URL 未确认；既有归档来源标签保留，不能替代原始公告

### 归档技术正文

红队安全圈
                    红队安全圈  红队安全圈   2026-09-19 00:06  
  
已确认在野利用的 Linux 内核本地提权洞：net/tls 一条零长度记录就能打碎引用计数，低权限直接够到 root。  
  
## 01  漏洞速览  
  
Linux 内核 net/tls 子系统存在一个 Use-After-Free 漏洞（CVE-2025-39682），CVSS 3.1 评分 **7.1**  
，本地低权限攻击者可以借此把权限提到 root。最要命的信号是：CISA KEV 已确认在野利用，说明有真实攻击者在用，不只是实验室玩具。跑着内核 6.0 到 6.16 的机器，尤其是多用户服务器和云主机，都需要立刻排查。  
  
漏洞编号  
CVE-2025-39682  
  
影响产品  
Linux Kernel（net/tls）  
  
影响版本  
6.0 - 6.16.3 及 6.17-rc1/rc2（详见下文）  
  
漏洞类型  
CWE-416 Use After Free  
  
危害等级  
CVSS 3.1 7.1 High（本地提权）  
  
是否在野  
是，已进 CISA KEV  
  
公开 PoC  
有，崩溃 PoC + 完整分析已公开  
  
攻击前提  
本地低权限账号 + 启用 kTLS 接收路径  
  
影响面  
多用户 Linux 服务器本地提权到 root  
  
## 02  漏洞成因  
  
根因在   
tls_sw_recvmsg  
 对零长度 TLS 记录的处理。正常约定是：每次   
recvmsg()  
 要么只处理连续的 DATA 记录，要么处理一条非 DATA 记录。但当一条零长度记录从   
rx_list  
 取出时，这个约定被打破——后续 TLS 记录会按错误的 zero-copy 和排队假设继续处理。  
  
具体链条：  
  
1. copied == 0 时函数继续循环收包。一条零长度解密记录正好触发这个条件。  
  
2. 下一轮迭代中，如果新记录的 content type 与先前建立的 control 不一致，tls_record_content_type() 返回 0。  
  
3. 返回值小于等于 0 走错误路径，把 darg.skb（其实就是 strp 的 anchor）挂进 ctx 的 rx_list。  
  
4. 问题在这：当 darg.zc == 1（zero-copy 模式激活）时，把 anchor 挂进 rx_list 是禁止的。这会破坏 anchor 的 frag_list 和引用计数。  
  
后果是：socket 关闭时，tls_sw_release_resources_rx 遍历已释放的内存，UAF 在 kfree_skb_list_reason 处被 KASAN 确认。这块 SKB 最早由 tcp_sendmsg_locked 分配，在错误重新入队之前已经被 tls_strp_msg_done 释放。  
  
一句话总结：错误路径把一个 zero-copy 模式下的 anchor SKB 二次入队，引用计数被打乱，释放后还在用。  
  
## 03  影响范围  
  
受影响版本（升级到以下版本之上即安全）：  
  
6.0      - 6.1.148  
  
6.2      - 6.6.102  
  
6.7      - 6.12.43  
  
6.13     - 6.16.3  
  
6.17-rc1 / 6.17-rc2  
  
补丁已随主线发布。KEV 条目提到部分受影响产品可能已 EoL/EoS——这类机器打不了补丁，只能换版本或做缓解。  
  
## 04  利用分析：触发序列已公开  
  
研究者已发布完整触发序列，六步复现（在 Linux 6.12.41 上实测触发 KASAN UAF）：  
  
**步骤 1**  
：发送一条 TLS Application Data 记录（type 0x17，内容 Hello world）。  
  
**步骤 2**  
：发送一条零长度 TLS Handshake 记录（type 0x16，空明文）。  
  
**步骤 3**  
：用 read(conn, buf, 0x100) 部分消费第一条记录，让下一次调用时 copied == 0。  
  
**步骤 4**  
：再发送一条 Application Data 记录（type 0x17）。  
  
**步骤 5**  
：调用 recvmsg——handshake 记录与后续 data 记录的 content type 不匹配，触发漏洞路径：darg.zc == 1 时错误地把 anchor SKB 入队 rx_list。  
  
**步骤 6**  
：关闭 socket——UAF 在 tls_sw_release_resources_rx 中触发。  
  
公开的崩溃 PoC 本身只让内核崩溃（KASAN 报 slab-use-after-free）。但从崩溃到提权是经典路径：UAF 意味着可以堆喷射占位被释放的 SKB 内存，配合跨缓存攻击或 page 级喷射替换成可控对象，进而改写函数指针或核心结构完成 LPE。研究者的分析标题就写明目标是 privilege escalation。  
  
利用门槛评估：本地、低权限、复杂度低（AC:L）。难点在于 kTLS 接收路径需要目标进程真的在用 kTLS——这缩小了实战面，但在负载均衡、加密代理类服务里并不罕见。  
  
## 05  检测与排查  
  
版本排查（第一步先看内核版本是否在受影响区间）：  
  
uname -r  
  
确认 kTLS 是否在用——看进程有没有设置   
TCP_ULP tls  
，服务端场景直接查模块和 socket 状态：  
  
ss -tinm | grep tls  
  
lsmod | grep tls  
  
日志排查：内核日志出现过 KASAN 的 slab-use-after-free，位置在 kfree_skb_list_reason 或调用栈带 tls_sw_release_resources_rx，说明漏洞已被触发。在野利用场景下，攻击者得手后还会尝试提权，需结合 auditd 的 setuid/execve 异常记录一起看。  
  
## 06  修复建议  
  
1. 升级内核到包含补丁的版本：6.1.149+ / 6.6.103+ / 6.12.44+ / 6.16.4+ / 6.17-rc3+（或发行版 backport 版本）。  
  
2. 暂时无法升级的：确认业务没有启用 kTLS 接收路径可显著降低风险——漏洞入口在 tls_sw_recvmsg，不用 kTLS 就打不到。  
  
3. EoL/EoS 系统（KEV 明确点名）：没有补丁可打，尽快迁移到受支持版本。  
  
4. 多用户服务器和容器宿主机：限制本地不可信用户，是所有内核 LPE 的通用缓解。  
  
## 07  红队视角  
  
这个洞的实战价值在于：在野确认 + 本地低门槛。KEV 收录说明已有攻击者把它塞进利用链，很可能作为容器逃逸或多阶段入侵里的提权环节——拿到 Web shell 后从低权限服务账号提到 root，一步到位。  
  
对防守方的提示：  
  
- 面向公网的服务就算本身无此漏洞，落入的账号一旦能触发本地内核漏洞，边界就没了。7.1 分的本地提权在多租户环境里实际影响远超分数。  
  
- 排查优先级：容器宿主机 > 多用户跳板机 > 单用途加密服务节点。  
  
- 类似历史案底：net/tls 这几年不是第一次出事，tls_setsockopt 系列和 tls_sw_recvmsg 早前的处理缺陷都报过。这条接收路径建议整体纳入重点审计范围。  
  
后续如果出现可用的完整 LPE exploit，会跟进分析。  
  
## 08  POC 链接  
  
STAR Labs 的完整分析（触发序列 + 崩溃 PoC 源码 + TLS 记录生成脚本）：  
  
https://starlabs.sg/advisories/25/25-39682/  
  
CISA KEV 条目：  
  
https://www.cisa.gov/known-exploited-vulnerabilities-catalog#CVE-2025-39682  
  
  
如果文章对您有收获，欢迎**关注**  
、点赞、推荐、转发。  
  
— END —  
  
  


---

> 来源：gelusus/wxvl（微信公众号漏洞文章自动归档，原始披露 URL 尚未确认，现有链接按来源追溯区分别标注）


# Linux kTLS：原作者完整崩溃验证来源补充

> 证据预览；未写回主库，未发布

STAR Labs 的原始披露提供了完整 C 触发程序、三条 TLS 1.2 AES-CCM-128 记录、生成记录的 Python 程序，以及 Linux 6.12.41 上的 KASAN 输出，可作为现有六步摘要的完整技术来源。

输入顺序为 Application Data（0x17，Hello world）、空 Handshake（0x16）、第二条 Application Data（0x17）；程序建立本机回环连接，配置 TCP_ULP=tls 与 TLS_RX，随后 read、recvmsg、close。来源记录的结果是 kfree_skb_list_reason 中的 slab-use-after-free，调用栈经过 tls_sw_release_resources_rx。

该材料支持“可触发内核 UAF”的结论，不能直接当成完整 root 提权或容器逃逸结果。程序触发内核内存错误，存在崩溃和业务中断风险。记录生成脚本本身也不是漏洞验证结果。本库只做静态来源核对，未执行这些代码。

现有技术稿保留为主入口；两篇 Linux 多漏洞新闻保留为事件材料，不合并成同一漏洞实体。

## 来源与审阅范围

- 主来源：https://starlabs.sg/advisories/25/25-39682/
- 核对日期：2026-10-03
- 已阅读：所引原始技术正文；图片像素未查看，不使用图像推断成功
- 主库关系：`系统安全/Linux/(7.1分) CVE-2025-39682：Linux内核TLS UAF本地提权.md`, `系统安全/Linux/CISA：三个Linux 内核漏洞已遭活跃利用.md`, `系统安全/Linux/【热点安全风险】9月21日 Linux 内核三漏洞确认已遭在野利用，攻击者可借其本地提权并横向渗透内网服务器.md`
- 来源快照：`web/open01.json` SHA-256 `789dde5f9d4db76edfc090290a810ac7d1a791a0b8687b088e635ed58a60ed77`
- 哈希范围：保存的网页工具文本快照，不是原站 HTTP 字节哈希

## 独立复核补注

本文门槛限定为本地内核 UAF 触发及 KASAN 可观察结果，不是 root 利用链。原披露明确测试 Linux 6.12.41，要求系统提供 kTLS 接收及 TLS 1.2 AES-CCM-128；PoC 自己在回环地址 127.0.0.1 的 4444 端口建立连接并配置 `TCP_ULP` / `TLS_RX`，无需假定已有业务服务正在使用 kTLS。C 代码内三条记录已经给出，Python `Crypto.Cipher.AES` 只用于生成同类记录，不是执行 C 触发程序的运行依赖。未安装该 Python 依赖、编译或运行任一程序。源码和输出为原作者记录；分支范围仍按原披露与具体发行版回补核对，不能仅凭版本号推断所有配置可触发。
