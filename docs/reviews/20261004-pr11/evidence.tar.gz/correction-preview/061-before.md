---
verification_source: "https://www.sonarsource.com/blog/government-emails-at-risk-critical-cross-site-scripting-vulnerability-in-roundcube-webmail/"
source_url: "https://www.sonarsource.com/blog/government-emails-at-risk-critical-cross-site-scripting-vulnerability-in-roundcube-webmail/"
source: "gelusus/wxvl 公众号漏洞文库"
cve: "CVE-2024-42009;CVE-2024-42008;CVE-2024-42010"
identifier_role: "primary"
primary_identifiers: "CVE-2024-42009;CVE-2024-42008;CVE-2024-42010"
referenced_identifiers: "CVE-2024-36401;CVE-2024-36837"
identifier_status: "unknown"
title: "CVE-2024-42009"
product: "Roundcube Webmail"
record_type: "vulnerability"
document_type: "Roundcube三漏洞补丁摘要"
review_status: "text-reviewed"
verification_status: "not-reproduced"
content_status: "needs-review"
prerequisites: "1.6分支<1.6.8、1.5分支<1.5.8；42009查看恶意HTML邮件，42008另需附件相关交互，42010 CSS信息泄露"
side_effects: "42009在收件人查看HTML邮件后执行浏览器脚本，影响邮箱会话；42008/42010及service worker后续操作各有独立条件"
archive_url: "https://github.com/Ares-X/VulWiki/blob/41940cb0038d09ca5aaddbe5bffb923e423d210f/Web%E5%AE%89%E5%85%A8/%E5%85%B6%E4%BB%96%E8%BD%AF%E4%BB%B6/%E6%9D%82%E9%A1%B9/CVE-2024-42009.md"
archive_commit: "41940cb0038d09ca5aaddbe5bffb923e423d210f"
source_status: "recorded"
source_note: "原始出处待补；仓库归档不等同原始披露"
id: "vw-266ec62b0a87c7b0d7bfbecd"
entity_id: "ve-266ec62b0a87c7b0d7bfbecd"
schema_version: "1"
---

# CVE-2024-42009

<!-- vulwiki-editorial-rebuild:system-misc -->
## 条目范围与校订

- 本文对象：Roundcube Webmail
- 文献类型：Roundcube三漏洞补丁摘要
- 版本、权限及部署边界：1.6分支<1.6.8、1.5分支<1.5.8；42009查看恶意HTML邮件，42008另需附件相关交互，42010 CSS信息泄露
- 核验状态：仅重建文本校订；未执行文中代码、PoC 或扫描，未把截图或转载声明记为本站复现

### 具体结论与待核项

以下为原归档的逐项勘误与证据缺口；可由文本确定的问题已在下文订正，仍缺来源的事实保持待核。

1. 标题单42009但正文三个实质漏洞，应拆主实体并保留不同触发/影响
2. 42009描述完全重复两次、详情空栏，实为补丁摘要不是PoC
3. 受影响范围需分支限定，裸<1.6.8会把已修复1.5.8误纳
4. XSS窃取密码须额外机制/用户动作，不能默认读取已存邮箱密码；邮件/联系人访问与会话权限区分
5. 有Roundcube官方安全更新及Sonar原研究，适合主来源；37383同产品不同修复点不得混并

### 操作风险

原文技术操作的实际副作用未复现核验；按其请求/代码评估状态变更、凭据暴露和业务影响

技术请求、代码与实验方法按原文保留；其中的破坏性动作仅限授权、可恢复的隔离环境。缺失代码、参数或版本事实不猜补。

### 来源追溯

- 原文参考链接（未重新核验）：<https://roundcube.net/news/2024/08/04/security-updates-1.6.8-and-1.5.8>
- 原文参考链接（未重新核验）：<https://www.sonarsource.com/blog/government-emails-at-risk-critical-cross-site-scripting-vulnerability-in-roundcube-webmail/>
- 原文参考链接（未重新核验）：<https://github.com/roundcube/roundcubemail/releases>
- 原文参考链接（未重新核验）：<http://mp.weixin.qq.com/s?__biz=Mzg2ODcxMjYzMA==&mid=2247485474&idx=2&sn=c87807bbe8f26ab6c0e05336ace5d5f4&chksm=cea961fbf9dee8edd252018b4b32f3446653c24c74a2a2b33c5a3bafe8295266ca3cfab5d998&scene=21#wechat_redirect>
- 原文参考链接（未重新核验）：<http://mp.weixin.qq.com/s?__biz=Mzg2ODcxMjYzMA==&mid=2247485474&idx=1&sn=bae852b450ca3cdab72155ef5dd0f4ce&chksm=cea961fbf9dee8ed55aa4cda7c5d342d62f019da01dfa3ebb9f01bed1193a5a6f21d70a79166&scene=21#wechat_redirect>
- 原文参考链接（未重新核验）：<http://mp.weixin.qq.com/s?__biz=Mzg2ODcxMjYzMA==&mid=2247485458&idx=2&sn=c25113b4a0ead82773652cae79323bf6&chksm=cea961cbf9dee8dd45d8bd03613b0b02eeaa2b8422bd32a239576618107f022479901cdd1b50&scene=21#wechat_redirect>
- 原始披露 URL 未确认；既有归档来源标签保留，不能替代原始公告

### 归档技术正文

alicy  信安百科   2024-08-10 11:40  
  
**0x00 前言**  
  
  
Roundcube Webmail是一个开源的基于web的电子邮件客户端，旨在提供用户友好的界面和强大的功能，使用户能够通过web浏览器方便地访问和管理他们的电子邮件。  
  
  
Roundcube支持标准的邮件协议（如IMAP和SMTP），并提供了许多常见的邮件功能，如收发邮件、管理联系人、创建日历事件等。其界面简洁直观，易于使用，同时还支持插件扩展，用户可以根据自己的需求定制功能。  
  
  
Roundcube Webmail被广泛应用于个人用户、企业和组织，为他们提供了一个方便、安全的电子邮件管理解决方案。  
  
  
  
**0x01 漏洞描述**  
  
  
Roundcube Webmail 1.6.8之前和1.5.8之前版本在HTML内容处理中存在跨站脚本漏洞，远程威胁者可向目标用户发送恶意设计的电子邮件，当受害者在Roundcube中查看恶意电子邮件时，可能导致利用该漏洞窃取电子邮件和联系人、受害者的电子邮件密码以及从受害者的帐户发送电子邮件等。  
  
  
  
**0x02 CVE编号**  
  
  
CVE-2024-42009：Roundcube Webmail跨站脚本漏洞  
  
Roundcube Webmail 1.6.8之前和1.5.8之前版本在HTML内容处理中存在跨站脚本漏洞，远程威胁者可向目标用户发送恶意设计的电子邮件，当受害者在Roundcube中查看恶意电子邮件时，可能导致利用该漏洞窃取电子邮件和联系人、受害者的电子邮件密码以及从受害者的帐户发送电子邮件等。  
  
  
CVE-2024-42008：Roundcube Webmail跨站脚本漏洞  
  
Roundcube Webmail 1.6.8之前和1.5.8之前版本在附件处理中存在跨站脚本漏洞，远程威胁者可通过向目标用户发送带有危险Content-Type标头的恶意电子邮件附件，当受害者在Roundcube中查看和点击恶意电子邮件时，可能导致利用该漏洞窃取电子邮件和联系人、受害者的电子邮件密码以及从受害者的帐户发送电子邮件等。  
  
  
CVE-2024-42010：Roundcube Webmail信息泄露漏洞  
  
Roundcube Webmail 1.6.8之前和1.5.8之前版本中的 mod_css_styles 对渲染的电子邮件消息中的层叠样式表（CSS）令牌序列的过滤不充分，可能导致远程威胁者获取敏感信息。  
  
  
  
**0x03 影响版本**  
  
  
Roundcube Webmail < 1.6.8  
  
Roundcube Webmail < 1.5.8  
  
  
  
**0x04 漏洞详情**  
  
  
  
  
  
**0x05 参考链接**  
  
  
https://roundcube.net/news/2024/08/04/security-updates-1.6.8-and-1.5.8  
  
  
https://www.sonarsource.com/blog/government-emails-at-risk-critical-cross-site-scripting-vulnerability-in-roundcube-webmail/  
  
  
https://github.com/roundcube/roundcubemail/releases  
  
  
  
  
推荐阅读：  
  
  
[N/A｜Roundcube Webmail存在远程代码执行漏洞（POC）](http://mp.weixin.qq.com/s?__biz=Mzg2ODcxMjYzMA==&mid=2247485474&idx=2&sn=c87807bbe8f26ab6c0e05336ace5d5f4&chksm=cea961fbf9dee8edd252018b4b32f3446653c24c74a2a2b33c5a3bafe8295266ca3cfab5d998&scene=21#wechat_redirect)  
  
  
  
[CVE-2024-36401｜GeoServer 未授权远程代码执行漏洞（POC）](http://mp.weixin.qq.com/s?__biz=Mzg2ODcxMjYzMA==&mid=2247485474&idx=1&sn=bae852b450ca3cdab72155ef5dd0f4ce&chksm=cea961fbf9dee8ed55aa4cda7c5d342d62f019da01dfa3ebb9f01bed1193a5a6f21d70a79166&scene=21#wechat_redirect)  
  
  
  
[CVE-2024-36837｜CRMEB电商管理系统存在SQL 注入漏洞（POC）](http://mp.weixin.qq.com/s?__biz=Mzg2ODcxMjYzMA==&mid=2247485458&idx=2&sn=c25113b4a0ead82773652cae79323bf6&chksm=cea961cbf9dee8dd45d8bd03613b0b02eeaa2b8422bd32a239576618107f022479901cdd1b50&scene=21#wechat_redirect)  
  
  
  
  
  
Ps：国内外安全热点分享，欢迎大家分享、转载，请保证文章的完整性。文章中出现敏感信息和侵权内容，请联系作者删除信息。信息安全任重道远，感谢您的支持![](https://mmbiz.qpic.cn/mmbiz_png/Whm7t4Je6urTIficI8UhQibwpYWx4ic7Bk40AJlXrgx3icofWCbd5cbJFheld132R8exvlHnicn0AUjHLmVok4wV9qA/640?wx_fmt=png&wxfrom=5&wx_lazy=1&wx_co=1 "")  
  
！！！  
  
  
**本公众号的文章及工具仅提供学习参考，由于传播、利用此文档提供的信息而造成任何直接或间接的后果及损害，均由使用者本人负责,本公众号及文章作者不为此承担任何责任。**  
  
![](https://mmbiz.qpic.cn/mmbiz_png/Whm7t4Je6uqQ24S6worK6npevNP8p1uPc9jQeMAib2iaibBnibOzFaIbD0KlvsEtUAmL3xdbJJnWk74Y1KfBcIazzw/640?wx_fmt=png "")  
  
  


---

> 来源：gelusus/wxvl（微信公众号漏洞文章自动归档，原始披露 URL 尚未确认，现有链接按来源追溯区分别标注）


## 2026-10-03 公开验证资料补充

[Sonar原研究](https://www.sonarsource.com/blog/government-emails-at-risk-critical-cross-site-scripting-vulnerability-in-roundcube-webmail/#technical-details) 的 Desanitization 小节提供完整HTML邮件体，核心是已清洗内容再次经html4inline修改：处理bgcolor的正则可移除不成对引号，使原先位于属性值中的style及onanimationstart成为真实属性。body被转为div后，样例借用Bootstrap动画触发事件；不是仅列补丁或泛指任意img标签。

攻击者发送邮件，收件人在受影响Roundcube里查看HTML后触发。1.5分支修复1.5.8，1.6分支修复1.6.8。42008附件点击和42010 CSS泄露属于另外两个问题；持久化service worker还涉及额外步骤，不能将本篇全部影响当单个邮件体已证明。此次阅读了技术文字与显示代码，未播放演示视频或查看截图，未发送邮件。

本新增小节的材料结论仅限CVE-2024-42009。42008、42010和service worker后续能力不计作42009直接结果；演示视频未观看，不能作为本轮观察到成功的证据。未在页面追加或运行活动HTML。
