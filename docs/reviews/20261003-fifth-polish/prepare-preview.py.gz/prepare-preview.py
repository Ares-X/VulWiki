import pathlib, json, hashlib, collections, re, subprocess

ROOT = pathlib.Path('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki')
OUT = pathlib.Path('/tmp/vulwiki-fifth-polish-20261003')
loadl = lambda p: [json.loads(x) for x in p.read_text().splitlines()]
sha = lambda b: hashlib.sha256(b).hexdigest()
inventory = loadl(OUT / 'before/inventory.jsonl')
candidates = loadl(OUT / 'before/candidates.jsonl')
sources = {}
for row in inventory:
    data = (ROOT / row['path']).read_bytes()
    if sha(data) != row['file_sha256']:
        data = subprocess.check_output(['git', 'show', '956c8b26de5accbc1af8faecacdd34c34384a759:' + row['path']], cwd=ROOT)
    assert sha(data) == row['file_sha256'], row['path']
    sources[row['path']] = data.decode('utf-8')
operations = []

def add(path, before, after, kind, ids, reason):
    source = sources[path]
    assert before != after and source.count(before) == 1, (path, kind)
    start = source.index(before)
    operations.append(dict(path=path, before=before, after=after, kind=kind,
        candidate_ids=ids, reason=reason, file_sha256=sha(source.encode()),
        character_start=start, utf8_byte_start=len(source[:start].encode()),
        utf8_byte_end_exclusive=len(source[:start + len(before)].encode()),
        source_line=source[:start].count('\n') + 1))

for row in candidates:
    if row['rule'] != 'unknown_html_literal':
        continue
    raw = row['raw']
    if raw.startswith('<meta'):
        first, rest = raw.split('\n', 1)
        # Escaped archive attributions stay literal; no unescaping or URL rewrite.
        if rest.startswith('> 本文由 '):
            add(row['path'], raw, first + '\n\n' + rest, 'meta_attribution_boundary',
                [row['id']], 'Separate the void meta tag from its unescaped Markdown attribution; preserve all original bytes and values.')
    elif re.match(r'^<font[^>]*>  \n</font>\*\*', raw):
        after = raw.replace('</font>**', '</font>\n\n**', 1)
        add(row['path'], raw, after, 'font_markdown_boundary', [row['id']],
            'Separate empty font block from the original Markdown strong text; all HTML tags, attributes and text stay unchanged.')

# Accept only byte-preserving HTTP wrappers. Requests with existing inline-code
# delimiters are recorded for separate review, never blindly wrapped.
http = json.loads((OUT / 'http-review.json').read_text())
for row in http['proposals']:
    if '`' in row['before']:
        continue
    assert row['after'] == '```http\n' + row['before'] + '```\n'
    add(row['path'], row['before'], '\n' + row['after'] + '\n', 'complete_http_fence',
        row['candidate_ids'], row['reason'])

# The archived SQL operators on standalone '=' lines become Setext headings and
# absorb earlier prose, including the new HTTP fence. Bound the complete shown
# SQL examples as well; preserve the capture's line breaks and all values.
for path, start_line, end_line in [
    ('Web安全/数据库/PostgreSQL/CVE-2025-30936 SQL注入.md', 238, 257),
    ('Web安全/数据库/PostgreSQL/CVE-2025-48281 SQL注入.md', 1327, 1357),
    ('Web安全/数据库/PostgreSQL/CVE-2025-48281 SQL注入.md', 1372, 1397),
]:
    before = ''.join(sources[path].splitlines(keepends=True)[start_line-1:end_line])
    assert before.startswith('SELECT') and re.search(r'^=  $', before, re.M)
    add(path, before, '\n```sql\n' + before + '```\n\n', 'complete_sql_fence', [],
        'Keep the complete archived SQL example in a code block so its literal equals sign cannot absorb prior explanations as a Setext heading.')

# A literal HTML explanation is being interpreted as markup. Keep the original
# lines, leading spaces, event names and punctuation; delimit only the tag.
exchange = next(row for row in candidates if row['rule'] == 'unknown_html_literal'
    and row['raw'].startswith('<details>'))
add(exchange['path'], exchange['raw'], exchange['raw'].replace('<details>', '`<details>`', 1),
    'html_literal_codespan', [exchange['id']],
    'Show the original literal details tag as inline code instead of active HTML; no prose reflow or indentation change.')
add(exchange['path'], '<img src=”x”onerror=”恶意代码”>  \n', '`<img src=”x”onerror=”恶意代码”>`  \n',
    'html_literal_codespan', [],
    'Adjacent HTML tag is explicitly an explanation example, not an article image; preserve the original tag and curly quote values as inline code.')

grouped = collections.defaultdict(list)
for row in operations:
    grouped[row['path']].append(row)
preview = OUT / 'preview'
preview.mkdir(exist_ok=True)
ledger = []
for path, rows in sorted(grouped.items()):
    original = sources[path]
    result = original
    ordered = sorted(rows, key=lambda r: r['character_start'], reverse=True)
    end = len(original)
    for row in ordered:
        start = row['character_start']
        assert start + len(row['before']) <= end, ('overlap', path)
        result = result[:start] + row['after'] + result[start + len(row['before']):]
        end = start
    dest = preview / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(result.encode('utf-8'))
    # Reverse in source order while carrying the inserted-length displacement.
    restored = result
    displacement = 0
    for row in sorted(rows, key=lambda r: r['character_start']):
        at = row['character_start'] + displacement
        assert restored[at:at + len(row['after'])] == row['after']
        restored = restored[:at] + row['before'] + restored[at + len(row['after']):]
        # Previous edits were already inverted, so source offsets remain valid.
    assert restored == original, path
    ledger.append(dict(path=path, before_sha256=sha(original.encode()),
        after_sha256=sha(result.encode()), operations=len(rows), exact_inverse=True))
(OUT / 'operations.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in operations))
(OUT / 'preview-ledger.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in ledger))
summary = dict(articles=len(inventory), changed_articles=len(ledger), operations=len(operations),
    kinds=dict(collections.Counter(x['kind'] for x in operations)), all_exact_inverse=True,
    repository_modified=False, candidates_bound_to_snapshot=True)
(OUT / 'preview-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary))
