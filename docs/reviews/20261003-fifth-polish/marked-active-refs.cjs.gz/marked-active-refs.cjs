const fs=require('fs'),crypto=require('crypto');
const {marked}=require('/Users/aresx/Ares-X.github.io/node_modules/marked');
const {readFrontmatter}=require('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki/scripts/render-audit.cjs');
const dir='/tmp/vulwiki-fifth-polish-20261003',repo='/Users/aresx/Ares-X.github.io/source/wiki/VulWiki';
const rows=fs.readFileSync(dir+'/articles-final.jsonl','utf8').trim().split('\n').map(JSON.parse),result=[];
for(const row of rows){const bytes=fs.readFileSync(repo+'/'+row.path),source=bytes.toString('utf8');if(crypto.createHash('sha256').update(bytes).digest('hex')!==row.after_sha256)throw Error('source SHA '+row.path);const tokens=marked.lexer(readFrontmatter(source).body,{...marked.defaults,mangle:false});marked.parser(tokens,{...marked.defaults,mangle:false});const occurrences=new Map();
 marked.walkTokens(tokens,t=>{if(t.type==='image'||t.type==='link'){const n=occurrences.get(t.raw)||0;let at=-1,pos=0;for(let i=0;i<=n;i++){at=source.indexOf(t.raw,pos);if(at<0)break;pos=at+t.raw.length;}occurrences.set(t.raw,n+1);result.push({article:row.path,file_sha256:row.after_sha256,kind:t.type,href:t.href,raw:t.raw,text:t.text,line:at<0?null:source.slice(0,at).split('\n').length,line_precision:at<0?'transformed raw cannot be located':'raw occurrence match; nested identical markup may require context review'});}});
}
fs.writeFileSync(dir+'/marked-active-refs.jsonl',result.map(r=>JSON.stringify(r)).join('\n')+'\n');console.log(JSON.stringify({articles:rows.length,actual_markdown_link_image_tokens:result.length,execution:'Marked lexer/parser on strings only'}));
