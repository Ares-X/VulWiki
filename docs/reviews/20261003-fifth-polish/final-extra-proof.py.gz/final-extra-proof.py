import pathlib,json,hashlib,sys,collections
repo=pathlib.Path('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki');out=pathlib.Path('/tmp/vulwiki-fifth-polish-20261003');location=json.loads((out/'build-check-location.json').read_text());assert location['exit_code']==0;build=pathlib.Path(location['build']);public=build/'public/wiki/VulWiki'
sys.path.insert(0,str(repo/'scripts'));import wiki
sha=lambda b:hashlib.sha256(b).hexdigest();jl=lambda p:[json.loads(l) for l in p.read_text().splitlines() if l]
sources={r['id']:r for r in jl(repo/'docs/generated/sources.jsonl')};entries=jl(repo/'docs/generated/records.jsonl');catalog=json.loads((build/'public/wiki/catalog.json').read_text());fulltext=json.loads((build/'public/wiki/search-body.json').read_text());assert len(entries)==len(catalog['documents'])==len(fulltext['bodies'])==len(fulltext['bodyIdentifiers'])==5570
assert catalog['sourceCount']==5664 and catalog['excludedCount']==2 and catalog['version']==fulltext['version']
for r in sources.values():assert sha((repo/r['path']).read_bytes())==r['sha256'],r['path']
expected_canonical={};role_count=collections.Counter();assigned=set()
for e,d in zip(entries,catalog['documents']):
 path,primary,version,fingerprints,meta=d;owner=sources[e['id']];assert path==e['path'][:-3] and primary==' '.join(e['primary_identifiers']);assert version==(owner.get('affected_version_claim') or '');assert fingerprints==' '.join(x['query'] for x in owner['fingerprints'].values())
 expected=[];seen=set()
 for sid in e['source_record_ids']:
  assert sid not in assigned;assigned.add(sid);s=sources[sid];own=sid==e['id']
  if not own:expected_canonical[s['path'][:-3]]=path
  for role,ids in [('primary' if own else 'related-primary',e['primary_identifiers'] if own else s['primary_identifiers']),('candidate',s['identifier_candidates']),('reference',s['referenced_identifiers'])]:
   for identifier in ids:
    key=(sid,role,identifier)
    if key not in seen:seen.add(key);expected.append({'identifier':identifier,'role':role,'sourceId':sid});role_count[role]+=1
 assert meta['identifiers']==expected,e['path']
assert assigned==set(sources) and catalog['canonicalPaths']==expected_canonical
files=list((repo/'docs/generated').glob('*'))+[repo/'docs/REVIEW-QUEUE.md']+[p for p in repo.glob('INDEX*') if p.is_file()]+[p for d in repo.glob('INDEX*') if d.is_dir() for p in d.rglob('*.md')];generated=[]
for p in sorted(set(files)):
 if p.is_file():assert p.read_bytes()==(public/p.relative_to(repo)).read_bytes(),str(p);generated.append({'path':p.relative_to(repo).as_posix(),'sha256':sha(p.read_bytes())})
ui=[]
for name in ['wiki.js','wiki-catalog.js','wiki-search-worker.js','wiki.css']:
 p=repo.parents[2]/'source/wiki'/name;assert p.read_bytes()==(build/'public/wiki'/name).read_bytes();ui.append({'path':name,'sha256':sha(p.read_bytes())})
aliases=[]
for r in jl(out/'articles-final.jsonl'):
 if r['path'].endswith('.md.md'):assert (public/r['path'][:-3]).read_bytes()==(repo/r['path']).read_bytes();aliases.append(r['path'][:-3])
# Independently resolve real Marked image/link tokens, without loading HTML or fetching URLs.
refs=[];missing=[];invalid=[];unique=set();count=0
for r in jl(out/'marked-active-refs.jsonl'):
 try: local=wiki.local_target(r['article'],r['href'])
 except ValueError as exc:
  invalid.append(r|{'parse_exception':str(exc),'disposition':'source URL syntax candidate; not fetched or rewritten'});continue
 if local is None or local in {'!site','!outside'}:continue
 source=repo/local;target=public/local;raw=source.read_bytes() if source.is_file() else None;output=target.read_bytes() if target.is_file() else None
 item=r|{'resolved':local,'source_sha256':sha(raw) if raw is not None else None,'public_sha256':sha(output) if output is not None else None,'result':'byte-identical' if raw is not None and raw==output else 'source-missing' if raw is None else 'public-missing-or-different'}
 if item['result']=='byte-identical':count+=1;unique.add(local)
 else:missing.append(item)
 refs.append(item)
assert not any(r['result']=='public-missing-or-different' for r in missing)
(out/'marked-resource-byte-ledger.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in refs))
resources=jl(out/'resource-byte-ledger.jsonl');present=[r for r in resources if r['status']=='byte_identical'];unexpected=[r for r in resources if r['status'] in {'public_missing','byte_mismatch','escapes_repo'}];assert not unexpected,unexpected

summary={'catalog_documents':len(entries),'source_records':len(sources),'catalog_versions_match':True,'catalog_identifier_roles':dict(role_count),'canonical_fold_mappings':len(expected_canonical),'source_sha_matches':len(sources),'generated_files_byte_matches':len(generated),'generated_files':generated,'public_ui_files_unchanged':ui,'legacy_aliases':aliases,'python_local_references_byte_matches':len(present),'python_local_unique_targets_byte_matches':len({r['resolved_target'] for r in present}),'python_source_missing_candidates':sum(r['status']=='source_missing' for r in resources),'python_unexpected_output_mismatches':len(unexpected),'marked_local_references_byte_matches':count,'marked_local_unique_targets_byte_matches':len(unique),'marked_source_missing_candidates':missing,'marked_invalid_url_candidates':invalid,'not_exercised':['HTML DOM or browser clipboard','Image pixels','Article code/PoCs/attachments/scanners/loads','Example targets','Deployment']}
(out/'final-extra-proof.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['generated_files','public_ui_files_unchanged','marked_source_missing_candidates']},ensure_ascii=False))
