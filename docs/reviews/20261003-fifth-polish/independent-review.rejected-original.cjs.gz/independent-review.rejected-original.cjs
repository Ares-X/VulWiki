const fs = require('fs'), path = require('path'), crypto = require('crypto');
const { marked } = require('/Users/aresx/Ares-X.github.io/node_modules/marked');
const root='/Users/aresx/Ares-X.github.io/source/wiki/VulWiki';
const out='/tmp/vulwiki-fifth-polish-20261003';
marked.setOptions({mangle:false});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const readj=p=>fs.readFileSync(p,'utf8').trimEnd().split('\n').filter(Boolean).map(JSON.parse);
const ops=readj(path.join(out,'operations.jsonl')), ledger=readj(path.join(out,'preview-ledger.jsonl'));
const inventory=readj(path.join(out,'before/inventory.jsonl'));
const kinds={}, errors=[], details=[];
for(const o of ops) kinds[o.kind]=(kinds[o.kind]||0)+1;
const inv=new Map(inventory.map(x=>[x.path,x]));
const groups=new Map(); for(const o of ops){if(!groups.has(o.path))groups.set(o.path,[]);groups.get(o.path).push(o)}
function fail(code,info){errors.push({code,...info})}
function tokens(src){return marked.lexer(src)}
function collect(ts, out=[]){for(const t of ts||[]){if(t.type==='code')out.push(t.text); if(t.tokens)collect(t.tokens,out); if(t.items)for(const i of t.items)collect(i.tokens,out); if(t.rows)for(const r of t.rows)for(const c of r)collect(c.tokens,out);}return out}
function flat(ts,out=[]){for(const t of ts||[]){out.push(t); if(t.tokens)flat(t.tokens,out); if(t.items)for(const i of t.items)flat(i.tokens,out); if(t.rows)for(const r of t.rows)for(const c of r)flat(c.tokens,out);}return out}
let coveredCandidateIds=new Set();
for(const [p,rows] of groups){
  const iv=inv.get(p); if(!iv){fail('path_not_in_inventory',{path:p});continue}
  const before=fs.readFileSync(path.join(root,p));
  if(sha(before)!==iv.file_sha256)fail('source_sha_mismatch',{path:p,expected:iv.file_sha256,actual:sha(before)});
  let src=before.toString('utf8'); if(!Buffer.from(src,'utf8').equals(before))fail('invalid_utf8_roundtrip',{path:p});
  rows.sort((a,b)=>a.character_start-b.character_start);
  for(const o of rows){
    if(o.file_sha256!==sha(before))fail('operation_sha_mismatch',{path:p,kind:o.kind});
    const matches=[]; let pos=0; while((pos=src.indexOf(o.before,pos))!==-1){matches.push(pos);pos+=Math.max(1,o.before.length)}
    if(matches.length!==1)fail('before_not_unique',{path:p,kind:o.kind,count:matches.length});
    if(matches[0]!==o.character_start)fail('source_offset_or_exact_match',{path:p,kind:o.kind,offset:o.character_start,actual:matches[0]});
    if(Buffer.byteLength(src.slice(0,matches[0]))!==o.utf8_byte_start || Buffer.byteLength(src.slice(0,matches[0]+o.before.length))!==o.utf8_byte_end_exclusive)fail('byte_offset_mismatch',{path:p,kind:o.kind});
    if(src.slice(0,matches[0]).split('\n').length!==o.source_line)fail('line_mismatch',{path:p,kind:o.kind});
    for(const id of o.candidate_ids||[])coveredCandidateIds.add(id);
  }
  let built=src; let disp=0; for(const o of [...rows].sort((a,b)=>a.character_start-b.character_start)){const start=o.character_start+disp; built=built.slice(0,start)+o.after+built.slice(start+o.before.length); disp+=o.after.length-o.before.length;}
  const preview=fs.readFileSync(path.join(out,'preview',p));
  if(!preview.equals(Buffer.from(built,'utf8')))fail('preview_not_independently_reconstructed',{path:p});
  const lr=ledger.find(x=>x.path===p); if(!lr)fail('ledger_missing',{path:p}); else {if(sha(before)!==lr.before_sha256)fail('ledger_before_sha',{path:p});if(sha(preview)!==lr.after_sha256)fail('ledger_after_sha',{path:p});if(lr.operations!==rows.length)fail('ledger_operation_count',{path:p});if(!lr.exact_inverse)fail('ledger_inverse_false',{path:p});}
  let restored=preview.toString('utf8'); for(const o of [...rows].sort((a,b)=>b.character_start-a.character_start)){const at=o.character_start;
    if(restored.slice(at,at+o.after.length)!==o.after)fail('inverse_after_mismatch',{path:p,kind:o.kind});
    restored=restored.slice(0,at)+o.before+restored.slice(at+o.after.length);
  }
  if(!Buffer.from(restored,'utf8').equals(before))fail('inverse_not_exact',{path:p});
}
if(ledger.length!==groups.size)fail('ledger_coverage',{ledger:ledger.length,changed:groups.size});
if(ops.length!==516||groups.size!==506)fail('expected_coverage',{ops:ops.length,changed:groups.size});
for(const k of ['meta_attribution_boundary','font_markdown_boundary','complete_http_fence','html_literal_codespan']) if(kinds[k]!==({meta_attribution_boundary:489,font_markdown_boundary:8,complete_http_fence:18,html_literal_codespan:1})[k])fail('kind_count',{kind:k,actual:kinds[k]});
// Classification-specific invariants
const checks={meta:0,font:0,http:0,exchange:0};
for(const o of ops){
 if(o.kind==='meta_attribution_boundary'){
   checks.meta++; if(o.after!==o.before.replace(/\n(?=> 本文由 )/,'\n\n'))fail('meta_diff_shape',{path:o.path});
   const b=tokens(o.before),a=tokens(o.after); const qa=b.find(t=>t.type==='blockquote'),qb=a.find(t=>t.type==='blockquote');
   const all=flat(a); if(!qb||!qb.tokens||!all.some(t=>t.type==='link'&&String(t.href||'').includes('mp.weixin.qq.com/s/')))fail('meta_quote_or_link_not_lexed',{path:o.path});
 }
 if(o.kind==='font_markdown_boundary'){
   checks.font++; if(o.after!==o.before.replace('</font>**','</font>\n\n**'))fail('font_diff_shape',{path:o.path});
   const ts=tokens(o.after); if(!ts.some(t=>t.type==='paragraph'&&t.tokens&&flat(t.tokens).some(x=>x.type==='strong')))fail('font_strong_not_lexed',{path:o.path});
 }
 if(o.kind==='complete_http_fence'){
   checks.http++; if(o.after!=='```http\n'+o.before+'```\n')fail('http_wrapper_changed',{path:o.path});
   const fs1=tokens(o.after).filter(t=>t.type==='code'); if(fs1.length!==1)fail('http_code_token_count',{path:o.path,count:fs1.length});
   else if(fs1[0].text!==o.before.replace(/\n$/,''))fail('http_code_token_text_mismatch',{path:o.path,expectedLastNewlineRemoved:true});
   // all explanatory/image prose surrounding the request remains byte-exact
   if(o.before.includes('![',0) && o.after.includes('```http\n!['))fail('http_image_inside_fence',{path:o.path});
 }
 if(o.kind==='html_literal_codespan'){
   checks.exchange++; const a=tokens(o.after),all=flat(a),codes=all.filter(t=>t.type==='codespan');
   if(!codes.some(t=>t.text==='<details>'))fail('exchange_details_not_inline_code',{path:o.path});
   if(o.after!==o.before.replace('<details>','`<details>`'))fail('exchange_changed_other_bytes',{path:o.path});
 }
}
// Full document preservation outside exact operations via inverse, plus parsed data checks.
// Compare all untouched original code text, metadata scalar lines, image hrefs, and raw HTML table/tag literals.
function images(ts,out=[]){for(const t of flat(ts))if(t.type==='image')out.push(t.href);return out}
function frontmatter(s){const m=s.match(/^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/);return m?m[1]:''}
function htmlLiterals(s){return (s.match(/<\/?(?:table|thead|tbody|tr|td|th|font|details|summary|meta)\b[^>]*>/gi)||[])}
for(const p of groups.keys()){
 const b=fs.readFileSync(path.join(root,p),'utf8'),a=fs.readFileSync(path.join(out,'preview',p),'utf8');
 const bt=tokens(b),at=tokens(a);
 const oldCodes=collect(bt),newCodes=collect(at);
 // Remove the intentionally newly created HTTP code tokens before comparing old code tokens.
 const addedHttp=groups.get(p).filter(o=>o.kind==='complete_http_fence').map(o=>o.before.replace(/\n$/,''));
 for(const x of addedHttp){const ix=newCodes.indexOf(x);if(ix<0)fail('new_http_token_missing_for_compare',{path:p});else newCodes.splice(ix,1)}
 if(JSON.stringify(oldCodes)!==JSON.stringify(newCodes))fail('existing_code_token_text_changed',{path:p,old:oldCodes.length,new:newCodes.length});
 if(frontmatter(b)!==frontmatter(a))fail('frontmatter_changed',{path:p});
 if(JSON.stringify(images(bt))!==JSON.stringify(images(at)))fail('image_href_changed',{path:p});
 // Literal raw table/tag inventory can shift lexical type for intended released markup. Check byte-string multiset.
 const hb=htmlLiterals(b),ha=htmlLiterals(a); for(const s of hb)if(!ha.includes(s))fail('html_tag_literal_lost',{path:p,tag:s});
}
// Single intentional HTML block release: exchange literal details opens as inline code; report HTML lexical shift if present.
const ex=ops.find(o=>o.kind==='html_literal_codespan');
if(ex){const before=fs.readFileSync(path.join(root,ex.path),'utf8'),after=fs.readFileSync(path.join(out,'preview',ex.path),'utf8'); details.push({path:ex.path,changedLine:ex.source_line,detailsVisibleAsCodespan:flat(tokens(after)).some(t=>t.type==='codespan'&&t.text==='<details>'),sourceStillLiteral:before.includes('<details>'),previewExactOnlyIntendedReplacement:after===before.replace(ex.before,ex.after)});}
const result={review:'independent-static-preview-review',fixed_head:'956c8b26de5accbc1af8faecacdd34c34384a759',marked_version:require('/Users/aresx/Ares-X.github.io/node_modules/marked/package.json').version,marked_defaults_expanded:true,mangle:false,source_inventory_articles:inventory.length,preview_files:fs.readdirSync(path.join(out,'preview')).length,changed_articles:groups.size,operations:ops.length,operation_kinds:kinds,per_kind_render_checks:checks,candidate_id_count:coveredCandidateIds.size,ledger_rows:ledger.length,checks:{source_hashes:true,op_hash_offsets_lines_unique_matches:true,preview_sha_reconstruction:true,exact_inverse:true,old_code_token_text:true,frontmatter:true,image_hrefs:true,html_tag_literals:true,html_rendering_executed:false,article_code_executed:false,external_targets_visited:false},intentional_html_release:details,errors};
result.checks.all_errors_clear=errors.length===0;
fs.writeFileSync(path.join(out,'preview-independent-review.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({output:path.join(out,'preview-independent-review.json'),errors:errors.length,checks:result.checks,per_kind_render_checks:checks,kinds},null,2));
