import pathlib, json, hashlib, subprocess

ROOT = pathlib.Path('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki')
OUT = pathlib.Path('/tmp/vulwiki-fifth-polish-20261003')
PYTHON = '/Users/aresx/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
prior = json.loads(pathlib.Path('/tmp/vulwiki-fourth-polish-20261003/build-check-location.json').read_text())
build = pathlib.Path(prior['build'])
assert prior['exit_code'] == 0 and build.parent.name.startswith('vulwiki-fourth-check-20261003-')
before = [json.loads(l) for l in (OUT/'before/inventory.jsonl').read_text().splitlines()]
for row in before:
    assert hashlib.sha256((build/'source/wiki/VulWiki'/row['path']).read_bytes()).hexdigest() == row['file_sha256'], row['path']
changed = subprocess.check_output(['git', 'diff', '--name-only', '-z', 'HEAD'], cwd=ROOT).decode().split('\0')
overlay = []
for relative in sorted(x for x in changed if x):
    source = ROOT/relative
    assert source.is_file(), relative
    data = source.read_bytes()
    target = build/'source/wiki/VulWiki'/relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    overlay.append(dict(path=relative, sha256=hashlib.sha256(data).hexdigest()))
for row in before:
    assert (ROOT/row['path']).read_bytes() == (build/'source/wiki/VulWiki'/row['path']).read_bytes()
location = dict(build=str(build), reused_owned_isolated_build=True, previous_archive_input=prior,
    content_base='956c8b26de5accbc1af8faecacdd34c34384a759', overlay_paths=len(overlay),
    articles=len(before), article_sha_checked_before_overlay=True,
    publication='local build only; no push or deployment', exit_code=None)
(OUT/'build-overlay.json').write_text(json.dumps(overlay, ensure_ascii=False, indent=2)+'\n')
(OUT/'build-check-location.json').write_text(json.dumps(location, ensure_ascii=False, indent=2)+'\n')
with (OUT/'isolated-index-build.log').open('wb') as log:
    subprocess.run([PYTHON, 'scripts/wiki.py', 'build'], cwd=build/'source/wiki/VulWiki', stdout=log, stderr=subprocess.STDOUT, check=True)
with (OUT/'build-check.log').open('wb') as log:
    result = subprocess.run(['npm', 'run', 'build'], cwd=build, stdout=log, stderr=subprocess.STDOUT)
location['exit_code'] = result.returncode
(OUT/'build-check-location.json').write_text(json.dumps(location, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(dict(exit_code=result.returncode, articles=len(before), overlay_paths=len(overlay))))
raise SystemExit(result.returncode)
