'use strict';
const fs = require('node:fs');
const { execFileSync } = require('node:child_process');
const path = require('node:path');
const crypto = require('node:crypto');
const ROOT = '/Users/aresx/Ares-X.github.io/source/wiki/VulWiki';
const OUT = '/tmp/vulwiki-fifth-polish-20261003';
const marked = require('/Users/aresx/Ares-X.github.io/node_modules/marked/lib/marked.cjs');
const audit = require(path.join(ROOT, 'scripts/render-audit.cjs'));
const opts = { ...marked.defaults, mangle: false };
const hash = x => crypto.createHash('sha256').update(x).digest('hex');
const load = p => fs.readFileSync(path.join(OUT, p), 'utf8').trim().split('\n').map(JSON.parse);
const inv = load('before/inventory.jsonl');
const ops = load('operations.jsonl');
const ledgers = new Map(load('preview-ledger.jsonl').map(x => [x.path, x]));
const byPath = new Map();
for (const op of ops) {
  if (!byPath.has(op.path)) byPath.set(op.path, []);
  byPath.get(op.path).push(op);
}
function flatten(tokens, dest = []) {
  for (const token of tokens || []) {
    dest.push(token);
    if (token.tokens) flatten(token.tokens, dest);
    if (token.items) for (const item of token.items) flatten(item.tokens, dest);
    if (token.header) for (const cell of token.header) flatten(cell.tokens, dest);
    if (token.rows) for (const row of token.rows) for (const cell of row) flatten(cell.tokens, dest);
  }
  return dest;
}
function sequenceIn(needle, haystack) {
  let i = 0;
  for (const item of haystack) if (i < needle.length && JSON.stringify(needle[i]) === JSON.stringify(item)) i++;
  return i === needle.length;
}
const checks = [], failures = [], articles = [], candidates = [], inventories = [];
function check(ok, details) { checks.push({ ...details, pass: Boolean(ok) }); if (!ok) failures.push(details); }
for (const record of inv) {
  const originalBytes = byPath.has(record.path) ? execFileSync('git', ['show', '956c8b26de5accbc1af8faecacdd34c34384a759:' + record.path], {cwd: ROOT}) : fs.readFileSync(path.join(ROOT, record.path));
  check(hash(originalBytes) === record.file_sha256, { path: record.path, check: 'frozen_source_sha' });
  const before = originalBytes.toString('utf8');
  const articleOps = byPath.get(record.path) || [];
  const finalBytes = articleOps.length ? fs.readFileSync(path.join(OUT, 'preview', record.path)) : originalBytes;
  const after = finalBytes.toString('utf8');
  const result = audit.auditArticle({ path: record.path, source: after, sourceBytes: finalBytes, marked });
  inventories.push(result.inventory); candidates.push(...result.candidates);
  if (!articleOps.length) continue;
  check(hash(finalBytes) === ledgers.get(record.path).after_sha256, { path: record.path, check: 'preview_sha' });
  const priorBody = audit.readFrontmatter(before).body;
  const finalBody = audit.readFrontmatter(after).body;
  check(before.slice(0, before.length - priorBody.length) === after.slice(0, after.length - finalBody.length), { path: record.path, check: 'metadata_identical' });
  const prior = flatten(marked.lexer(priorBody, opts));
  const final = flatten(marked.lexer(finalBody, opts));
  const oldCodes = prior.filter(x => x.type === 'code').map(x => ({ lang: x.lang || '', text: x.text }));
  const newCodes = final.filter(x => x.type === 'code').map(x => ({ lang: x.lang || '', text: x.text }));
  const wrappedFragments = articleOps.filter(x => ['complete_http_fence', 'complete_sql_fence'].includes(x.kind)).flatMap(x => flatten(marked.lexer(x.before, opts)).filter(t => t.type === 'code').map(t => ({lang: t.lang || '', text: t.text})));
  const unchangedCodes = oldCodes.filter(x => !wrappedFragments.some(f => JSON.stringify(f) === JSON.stringify(x)));
  check(sequenceIn(unchangedCodes, newCodes), { path: record.path, check: 'existing_code_copy_text_order_preserved_except_explicitly_rebounded_fragments', prior: oldCodes, final: newCodes, intentionally_rebounded_fragments: wrappedFragments });
  const imageValues = ts => ts.filter(x => x.type === 'image').map(x => ({ href: x.href, text: x.text, title: x.title }));
  check(sequenceIn(imageValues(prior), imageValues(final)), { path: record.path, check: 'existing_image_values_order_preserved', prior: imageValues(prior), final: imageValues(final) });
  check(JSON.stringify(before.match(/<\/?[A-Za-z][^>]*>/g) || []) === JSON.stringify(after.match(/<\/?[A-Za-z][^>]*>/g) || []), { path: record.path, check: 'literal_html_tags_identical' });
  let restored = after;
  for (const op of [...articleOps].sort((a, b) => a.character_start - b.character_start)) {
    const at = originalBytes.subarray(0, op.utf8_byte_start).toString('utf8').length;
    check(restored.slice(at, at + op.after.length) === op.after, { path: record.path, check: 'inverse_span', kind: op.kind, candidate_ids: op.candidate_ids });
    restored = restored.slice(0, at) + op.before + restored.slice(at + op.after.length);
    if (['complete_http_fence', 'complete_sql_fence'].includes(op.kind)) {
      const lang = op.kind === 'complete_http_fence' ? 'http' : 'sql';
      const token = final.find(t => t.type === 'code' && t.lang === lang && t.text === op.before.replace(/\n$/, ''));
      check(Boolean(token), { path: record.path, check: 'complete_' + lang + '_copy_text', candidate_ids: op.candidate_ids, expected: op.before.replace(/\n$/, ''), actual: token && token.text });
    } else if (op.kind === 'meta_attribution_boundary') {
      const attribution = op.before.slice(op.before.indexOf('\n') + 1).trimEnd();
      const quote = final.find(t => t.type === 'blockquote' && t.raw.trimEnd() === attribution);
      const linkCount = quote ? flatten(quote.tokens).filter(t => t.type === 'link').length : 0;
      check(Boolean(quote) && linkCount >= 2, { path: record.path, check: 'attribution_markdown_recovered', candidate_ids: op.candidate_ids, attribution, links: linkCount });
    } else if (op.kind === 'font_markdown_boundary') {
      const strongRaw = op.before.slice(op.before.indexOf('**'));
      check(final.some(t => t.type === 'strong' && strongRaw.startsWith(t.raw)), { path: record.path, check: 'strong_markdown_recovered', candidate_ids: op.candidate_ids });
    } else if (op.kind === 'html_literal_codespan') {
      const literal = op.before.match(/^<[^>]*>/)[0];
      check(final.some(t => t.type === 'codespan' && t.raw === '`' + literal + '`'), { path: record.path, check: 'html_literal_visible', candidate_ids: op.candidate_ids });
    }
  }
  check(restored === before, { path: record.path, check: 'exact_full_file_inverse' });
  articles.push({ path: record.path, before_sha256: hash(originalBytes), after_sha256: hash(finalBytes), operations: articleOps.length });
}
fs.mkdirSync(path.join(OUT, 'preview-scan'), { recursive: true });
for (const [name, values] of [['inventory', inventories], ['candidates', candidates]]) fs.writeFileSync(path.join(OUT, 'preview-scan', name + '.jsonl'), values.map(x => JSON.stringify(x)).join('\n') + '\n');
const summary = { files: inventories.length, candidates: candidates.length, by_rule: Object.fromEntries([...new Set(candidates.map(x => x.rule))].sort().map(r => [r, candidates.filter(x => x.rule === r).length])), structural_failures: candidates.filter(x => ['empty_code', 'parse_error', 'fence_in_heading'].includes(x.rule)).length, checks: checks.length, failures: failures.length, changed_articles: articles.length, operations: ops.length, parser: 'Marked 4.3.0', static_only: true };
fs.writeFileSync(path.join(OUT, 'preview-scan/summary.json'), JSON.stringify(summary, null, 2) + '\n');
fs.writeFileSync(path.join(OUT, 'preview-checks.jsonl'), checks.map(x => JSON.stringify(x)).join('\n') + '\n');
fs.writeFileSync(path.join(OUT, 'preview-failures.json'), JSON.stringify(failures, null, 2) + '\n');
console.log(JSON.stringify(summary));
if (failures.length || summary.structural_failures) process.exitCode = 1;
