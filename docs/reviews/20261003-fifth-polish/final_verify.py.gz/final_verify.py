import sys,json,hashlib,pathlib,collections,re,subprocess,os
from urllib.parse import urlsplit
repo=pathlib.Path('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki')
aud=pathlib.Path('/tmp/vulwiki-fifth-polish-20261003')
loc=json.loads((aud/'build-check-location.json').read_text())
build=pathlib.Path(loc['build']); public=build/'public/wiki/VulWiki'; preview=aud/'preview'
sys.path.insert(0,str(repo/'scripts')); import wiki
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
inputs=[json.loads(line) for line in (aud/'articles-selected.jsonl').read_text().splitlines() if line]
assert len(inputs)==5666 and len({x['path'] for x in inputs})==5666
chosen={}; article_ledger=[]; article_mismatches=[]; before_hash_mismatch=[]; preview_count=repo_count=0
for item in inputs:
 p=item['path']; pp=preview/p; rp=repo/p
 src=pp if pp.is_file() else rp
 if pp.is_file(): preview_count+=1
 else: repo_count+=1
 if not src.is_file():
  article_mismatches.append({'path':p,'error':'selected source missing'}); continue
 raw=src.read_bytes(); out=public/p; out_raw=out.read_bytes() if out.is_file() else None
 if sha(raw)!=item.get('sha256'): before_hash_mismatch.append({'path':p,'before_sha256':item.get('sha256'),'selected_sha256':sha(raw),'selected_from':'preview' if pp.is_file() else 'repo'})
 ok=out_raw==raw
 if not ok: article_mismatches.append({'path':p,'reason':'public file missing' if out_raw is None else 'bytes differ','source_sha256':sha(raw),'public_sha256':sha(out_raw) if out_raw is not None else None})
 text=raw.decode('utf8'); meta,body,parse_errors=wiki.parse_frontmatter(text)
 chosen[p]={'raw':raw,'meta':meta,'body':body,'source':src}
 article_ledger.append({'kind':'article','path':p,'selected_from':'preview' if pp.is_file() else 'repo','selected_sha256':sha(raw),'public_sha256':sha(out_raw) if out_raw is not None else None,'selected_matches_articles_before':sha(raw)==item.get('sha256'),'result':'byte-identical' if ok else 'mismatch','parse_errors':parse_errors})
# Public isolation projection files.
def jl(path): return [json.loads(x) for x in path.read_text(encoding='utf8').splitlines() if x]
sources=jl(public/'docs/generated/sources.jsonl'); records=jl(public/'docs/generated/records.jsonl'); excluded=jl(public/'docs/generated/excluded.jsonl')
source_by_id={x['id']:x for x in sources}; source_by_path={x['path']:x for x in sources}; record_by_path={x['path']:x for x in records}
meta_mismatches=[]; source_ledger=[]
def expected_ids(meta):
 primary=[]; candidates=[]; refs=[]
 for value in wiki.split_ids(meta.get('primary_identifiers','')):
  norm=wiki.normalize_identifier(value); kind=wiki.identifier_kind(norm)
  if kind in {'known','unrecognized'}: primary.append(norm)
 for key,bucket in [('referenced_identifiers',refs),('identifier_candidates',candidates)]:
  for value in wiki.split_ids(meta.get(key,'')):
   norm=wiki.normalize_identifier(value); kind=wiki.identifier_kind(norm)
   if kind in {'known','unrecognized'}: bucket.append(norm)
 for key in ('cve','cnvd','cnnvd','ghsa','qvd','xve'):
  for value in wiki.split_ids(meta.get(key,'')):
   norm=wiki.normalize_identifier(value)
   if not wiki.IDENTIFIERS[key.upper()].fullmatch(norm): continue
   if norm not in primary and norm not in refs and norm not in candidates:
    if not meta.get('primary_identifiers') and meta.get('identifier_role')=='primary': primary.append(norm)
    elif meta.get('identifier_role')=='reference': refs.append(norm)
    else: candidates.append(norm)
 if meta.get('identifier_status') in {'rejected','disputed'}: primary=[]
 return sorted(set(primary)),sorted(set(candidates)),sorted(set(refs))
identifier_role_counts=collections.Counter(); source_link_total=0; archive_counts=collections.Counter()
for r in sources:
 p=r['path']; art=chosen.get(p)
 if art is None:
  meta_mismatches.append({'path':p,'check':'source article unavailable'}); continue
 m,b=art['meta'],art['body']; expected_links=wiki.source_candidates(m,b); source_link_total+=len(expected_links)
 ep,ec,er=expected_ids(m)
 checks={'source_url':r['source'].get('url','')==(m.get('source_url','') if m.get('source_url') and not any(wiki.urlsplit(m['source_url']).scheme not in {'http','https'} or not wiki.urlsplit(m['source_url']).netloc for _ in [0]) else ''),
         'archive_url':r.get('archive_url','')==m.get('archive_url',''), 'archive_commit':r.get('archive_commit','')==m.get('archive_commit',''),'archive_title':r.get('archive_title','')==m.get('archive_title',''),
         'source_links':r['source'].get('links',[])==expected_links,'primary_identifiers':r.get('primary_identifiers',[])==ep,'identifier_candidates':r.get('identifier_candidates',[])==ec,'referenced_identifiers':r.get('referenced_identifiers',[])==er,
         'entity_id':r.get('entity_id','')==m.get('entity_id',''),'canonical':r.get('canonical','')==m.get('canonical',''),'relation_type':r.get('relation_type','')==m.get('relation_type',''),'index_category':r.get('index_category','')==m.get('index_category','')}
 for role,val in [('primary',ep),('candidate',ec),('reference',er)]: identifier_role_counts[role]+=len(val)
 for fld in ['archive_url','archive_commit','archive_title']:
  if m.get(fld): archive_counts[fld]+=1
 bad=[k for k,v in checks.items() if not v]
 if bad: meta_mismatches.append({'path':p,'id':r['id'],'failed_fields':bad})
 source_ledger.append({'kind':'source','id':r['id'],'path':p,'source_url_raw':m.get('source_url',''),'archive_url_raw':m.get('archive_url',''),'archive_commit_raw':m.get('archive_commit',''),'archive_title_raw':m.get('archive_title',''),'ref_raw':m.get('ref',''),'verification_source_raw':m.get('verification_source',''),'source_links_expected':expected_links,'source_links_projected':r['source'].get('links',[]),'identifier_role_raw':m.get('identifier_role',''),'primary_expected':ep,'candidate_expected':ec,'reference_expected':er,'primary_projected':r.get('primary_identifiers',[]),'candidate_projected':r.get('identifier_candidates',[]),'reference_projected':r.get('referenced_identifiers',[]),'metadata_relationship':{k:m.get(k,'') for k in ('entity_id','canonical','relation_type','index_category')},'projection_sha256':r['sha256'],'input_sha256':sha(art['raw'])})
# Full catalogue/source assignment, body-derived identifiers, and navigation mappings.
assigned=[]; body_json=json.loads((build/'public/wiki/search-body.json').read_text()); catalog=json.loads((build/'public/wiki/catalog.json').read_text())
body_mismatches=[]; expected_nav={}; nav_override_paths=[]; entry_doc_mismatches=[]; body_identifier_count=0; raw_body_ids=0
rx=re.compile(r'\bCVE-\d{4}-\d+(?!\d)',re.I|re.ASCII)
for i,e in enumerate(records):
 p=e['path']; doc=catalog['documents'][i]; route=p[:-3]
 if doc[0]!=route or doc[1]!=' '.join(e.get('primary_identifiers',[])): entry_doc_mismatches.append(p)
 owner=source_by_id.get(e['id'])
 if owner is None: entry_doc_mismatches.append(p+':primary-source-id-missing'); continue
 exp_body=[]; seen=set()
 for sid in e['source_record_ids']:
  assigned.append(sid); src=source_by_id.get(sid)
  if src is None: body_mismatches.append({'path':p,'missing_source_id':sid}); continue
  ca=chosen.get(src['path'])
  if ca is None: body_mismatches.append({'path':p,'source_body_missing':src['path']}); continue
  for m in rx.finditer(ca['body']):
   k=(sid,m.group(0))
   if k not in seen: seen.add(k); exp_body.append({'identifier':m.group(0),'sourceId':sid})
 actual=body_json['bodyIdentifiers'][i] if i<len(body_json.get('bodyIdentifiers',[])) else None
 if exp_body!=actual: body_mismatches.append({'path':p,'expected_count':len(exp_body),'actual_count':len(actual) if actual is not None else None})
 body_identifier_count+=len(actual or []); raw_body_ids+=len(exp_body)
 if owner.get('index_category'):
  expected_nav[route]=owner['index_category'].split('/')+[e['product'],route.rsplit('/',1)[-1]]
  if chosen[owner['path']]['meta'].get('index_category'): nav_override_paths.append(owner['path'])
# Missing/unreferenced sources, relation and count integrity.
assignment_mismatch=sorted((collections.Counter(assigned)-collections.Counter(source_by_id.keys())).elements())+sorted((collections.Counter(source_by_id.keys())-collections.Counter(assigned)).elements())
nav_actual=catalog.get('navigationPaths',{})
nav_mismatch={'missing':sorted(set(expected_nav)-set(nav_actual)),'extra':sorted(set(nav_actual)-set(expected_nav)),'wrong':sorted(k for k in set(expected_nav)&set(nav_actual) if expected_nav[k]!=nav_actual[k])}
# Resolve all effective article links/images using the designated project parser. Verify every existing local target is byte-identical in public output.
resource_rows=[]; ref_issues=[]; ref_counts=collections.Counter(); markd_refs=[]
for p,art in chosen.items():
 prose,fence_issues=wiki.prose_and_fences(art['body'])
 full_text=art['raw'].decode('utf8'); body_offset=full_text[:len(full_text)-len(art['body'])].count('\n')
 for code,detail,line in fence_issues: ref_issues.append({'article':p,'kind':'fence','code':code,'line':line,'detail':detail})
 for target,is_image,line in wiki.markdown_links(prose,with_lines=True):
  target_type='image' if is_image else 'link'; local=wiki.local_target(p,target)
  if local is None:
   ref_counts[target_type+':external_or_fragment']+=1
   resource_rows.append({'article':p,'body_line':line,'full_source_line':body_offset+line,'line_precision':'wiki parser line plus frontmatter offset; inline-code stripping may shift multiline cases','type':target_type,'original_target':target,'local':False,'status':'external_or_fragment_not_fetched'}); continue
  if local in {'!site','!outside'}:
   ref_counts[target_type+':'+local]+=1
   resource_rows.append({'article':p,'body_line':line,'full_source_line':body_offset+line,'line_precision':'wiki parser line plus frontmatter offset; inline-code stripping may shift multiline cases','type':target_type,'original_target':target,'resolved_target':local,'local':False,'status':'site_relative_unverified' if local=='!site' else 'escapes_repo'})
   continue
  ref_counts[target_type+':local']+=1
  pp=preview/local; rp=repo/local; src=pp if pp.is_file() else rp; out=public/local
  src_raw=src.read_bytes() if src.is_file() else None; out_raw=out.read_bytes() if out.is_file() else None
  if src_raw is None:
   # Existing wiki diagnostics may intentionally classify these as non-content/site candidates.
   status='source_missing'; ref_issues.append({'article':p,'line':line,'kind':target_type,'original_target':target,'resolved_target':local,'status':status})
  elif out_raw is None:
   status='public_missing';ref_issues.append({'article':p,'line':line,'kind':target_type,'original_target':target,'resolved_target':local,'status':status,'source_sha256':sha(src_raw)})
  elif src_raw!=out_raw:
   status='byte_mismatch';ref_issues.append({'article':p,'line':line,'kind':target_type,'original_target':target,'resolved_target':local,'status':status,'source_sha256':sha(src_raw),'public_sha256':sha(out_raw)})
  else: status='byte_identical'
  resource_rows.append({'article':p,'body_line':line,'full_source_line':body_offset+line,'line_precision':'wiki parser line plus frontmatter offset; inline-code stripping may shift multiline cases','type':target_type,'original_target':target,'resolved_target':local,'source_from':'preview' if pp.is_file() else 'repo','source_sha256':sha(src_raw) if src_raw is not None else None,'public_sha256':sha(out_raw) if out_raw is not None else None,'status':status})
# Output ledgers preserve every full reference value, not a clipped sample.
for fn,rows in [('article-byte-ledger.jsonl',article_ledger),('source-projection-ledger.jsonl',source_ledger),('resource-byte-ledger.jsonl',resource_rows)]:
 with (aud/fn).open('w',encoding='utf8') as f:
  for row in rows:f.write(json.dumps(row,ensure_ascii=False,sort_keys=True)+'\n')
# Marked AST optional cross-check omitted: the project parser was applied to full prose/fences and is authoritative here.
summary={
 'build_location':loc,'selected_inputs':{'from_articles_before':len(inputs),'preview_files_used':preview_count,'repo_fallbacks':repo_count,'selected_hashes_differ_from_articles_before':len(before_hash_mismatch),'selected_hash_difference_paths':[x['path'] for x in before_hash_mismatch]},
 'public_root':str(public),
 'article_bytes':{'checked':len(article_ledger),'matches':sum(x['result']=='byte-identical' for x in article_ledger),'mismatches':len(article_mismatches),'mismatch_paths':article_mismatches},
 'local_references':{'all_resolved':sum(x.get('resolved_target') not in ('!site','!outside') and 'resolved_target' in x for x in resource_rows),'by_status_and_type':dict(sorted(ref_counts.items())),'issues':ref_issues,'issue_count':len(ref_issues)},
 'projection':{'sources':len(sources),'records':len(records),'excluded':len(excluded),'source_metadata_role_mismatches':meta_mismatches,'source_metadata_role_mismatch_count':len(meta_mismatches),'source_links_exact_values_checked':source_link_total,'archive_field_nonempty_counts':dict(archive_counts),'identifier_role_value_counts':dict(identifier_role_counts),'source_id_assignments_complete':len(assigned)==len(sources) and not assignment_mismatch,'source_assignment_mismatch_ids':assignment_mismatch,'bodyIdentifiers_expected_count':raw_body_ids,'bodyIdentifiers_projected_count':body_identifier_count,'bodyIdentifiers_mismatches':body_mismatches,'entry_to_catalog_mismatches':entry_doc_mismatches,'catalog_navigationPaths_count':len(nav_actual),'expected_navigationPaths_count':len(expected_nav),'navigation_mismatch':nav_mismatch,'explicit_navigation_overrides':len(nav_override_paths),'explicit_override_paths':sorted(nav_override_paths),'all_override_mappings_match':len(nav_override_paths)==15 and not any(nav_mismatch.values())},
 'artifacts':{'article_ledger':'/tmp/vulwiki-fifth-polish-20261003/article-byte-ledger.jsonl','source_projection_ledger':'/tmp/vulwiki-fifth-polish-20261003/source-projection-ledger.jsonl','resource_ledger':'/tmp/vulwiki-fifth-polish-20261003/resource-byte-ledger.jsonl'},
 'limitations':['No article PoC/code/HTML/attachments were executed, opened, or fetched.','No external URL or example target was accessed.','Site-root links remain unverified in the site deployment context.','Links classified as likely source-code/non-content and absent locally remain unknown pending content classification.','No claim is made about browser-rendered output, pixels, clipboard behavior, or deployment.']
}
(aud/'final-projection-proof.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'articles':summary['article_bytes'],'refs':summary['local_references']['by_status_and_type'],'ref_issue_count':summary['local_references']['issue_count'],'projection':{k:v for k,v in summary['projection'].items() if k not in ('source_metadata_role_mismatches','source_id_assignment_mismatch_ids','bodyIdentifiers_mismatches','entry_to_catalog_mismatches','explicit_override_paths')},'mismatch_counts':{'source_metadata':len(meta_mismatches),'assignments':len(assignment_mismatch),'body_ids':len(body_mismatches),'entry_catalog':len(entry_doc_mismatches)},'before_hash_difference_count':len(before_hash_mismatch)},ensure_ascii=False,indent=2))
