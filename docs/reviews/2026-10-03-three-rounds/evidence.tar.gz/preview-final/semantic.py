from pathlib import Path
import json,re,subprocess,hashlib
ROOT=Path('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki'); BASE='dbf87349c84e537c233b4231a1164e60fa52eca3'; ARCHIVE='41940cb0038d09ca5aaddbe5bffb923e423d210f'; TASK=Path('/tmp/vulwiki-goal-three-rounds-20261003'); OUT=TASK/'preview-final'
manifest=[json.loads(x) for x in (TASK/'preview-manifest.jsonl').read_text().splitlines()]
ops=[json.loads(x) for x in (TASK/'preview-operations.jsonl').read_text().splitlines()]
errors=[]; checks={}
# Original archive script is compared directly with the preview fence, excluding archive boundary only.
sonic='Web安全/网络设备/SonicWall/SonicWall SSL-VPN 未授权RCE漏洞.md'
arch=subprocess.check_output(['git','-C',str(ROOT),'show',f'{ARCHIVE}:{sonic}']).decode()
orig=arch[arch.index('#!/usr/bin/python'):]; orig=orig[:orig.index('\n\n---')]
prev=Path(next(m['preview'] for m in manifest if m['path']==sonic)).read_text()
code=prev[prev.index('```python\n#!/usr/bin/python')+len('```python\n'):]; code=code[:code.index('\n```')]
checks['sonicwall_archive_script_exact']=orig==code
checks['sonicwall_historical_title_preserved_as_previous_title']='title: "SonicWall SSL-VPN 未授权RCE漏洞"\nprevious_title: "coding: utf-8"' in prev and 'archive_title:' not in prev
if not checks['sonicwall_archive_script_exact']: errors.append('SonicWall fenced code differs from full original archive script')
# Verify every original raw HTTP(S) URL exact occurrence persists in its preview.
url_re=re.compile(r'https?://[^\s<>"\']+')
for m in manifest:
 base=subprocess.check_output(['git','-C',str(ROOT),'show',f"{BASE}:{m['path']}"]).decode()
 pv=Path(m['preview']).read_text()
 burls=url_re.findall(base); purls=url_re.findall(pv)
 remain=purls.copy(); lost=[]
 for u in burls:
  if u in remain: remain.remove(u)
  else: lost.append(u)
 if lost: errors.append(f'original raw URLs missing/changed in {m["path"]}: {lost[:3]}')
# These exact payload semantics are among the full-code-token checks; record explicit literal assertions.
autopath='Web安全/其他软件/杂项/某 json--1-2-68 Autotype bypass - 先知社区.md'
auto=Path(next(m['preview'] for m in manifest if m['path']==autopath)).read_text()
checks['autotype_duplicate_keys_and_mixed_quotes_literal']='\'@type\':"java.lang.AutoCloseable"' in auto and "'@type':'sun.rmi.server.MarshalOutputStream'" in auto
hyper=Path(next(m['preview'] for m in manifest if 'HyperBook' in m['path'])).read_text()
checks['hyperbook_literal_entities_retained']='&#34;' in hyper and '```python\n' in hyper
if not checks['autotype_duplicate_keys_and_mixed_quotes_literal']: errors.append('Autotype duplicate-key or mixed-quote payload literals missing')
if not checks['hyperbook_literal_entities_retained']: errors.append('HyperBook entities or Python fence missing')
# All prose-only explanatory mutations land outside fenced code: exact explanatory insertions checked in the diff.
for o in ops:
 if o.get('expected_code') is None and any(s in o['after'] for s in ('排版说明：','资源说明：','导航归入现有的','原归档为裸 Python2')):
  pv=Path(next(m['preview'] for m in manifest if m['path']==o['path'])).read_text()
  if o['after'] not in pv: errors.append(f'explanation missing verbatim at {o["path"]}@{o["offset"]}')
checks['editorial_explanations_preserved_verbatim']=not any(e.startswith('explanation missing') for e in errors)
# Marked parser image href comparison and exact original URL occurrence verification.
rows=[]
for m in manifest:
 base=subprocess.check_output(['git','-C',str(ROOT),'show',f"{BASE}:{m['path']}"]).decode()
 rows.append({'path':m['path'],'base':base,'preview':Path(m['preview']).read_text()})
(OUT/'semantic-input.json').write_text(json.dumps(rows,ensure_ascii=False),encoding='utf8')
js=r'''const fs=require('fs'),path=require('path'),mp='/Users/aresx/Ares-X.github.io/node_modules/marked',m=require(mp),rows=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));function images(ts,a=[]){for(const t of ts||[]){if(t.type==='image')a.push(t.href);if(t.tokens)images(t.tokens,a);if(t.items)for(const i of t.items)images(i.tokens,a);}return a;}let errors=[],files=[];for(const r of rows){let a=images(m.lexer(r.base,{mangle:false})).filter(Boolean),b=images(m.lexer(r.preview,{mangle:false})).filter(Boolean),left=b.slice(),lost=[];for(const u of a){let i=left.indexOf(u);if(i<0)lost.push(u);else left.splice(i,1)}if(lost.length)errors.push(`${r.path}: existing image href missing ${JSON.stringify(lost)}`);files.push({path:r.path,base_nonempty_image_hrefs:a.length,preview_nonempty_image_hrefs:b.length,lost});}console.log(JSON.stringify({version:require(path.join(mp,'package.json')).version,files,errors},null,2));process.exitCode=errors.length?1:0;'''
(OUT/'images.cjs').write_text(js,encoding='utf8')
p=subprocess.run(['node',str(OUT/'images.cjs'),str(OUT/'semantic-input.json')],capture_output=True,text=True)
image=json.loads(p.stdout)
if p.returncode: errors+=image.get('errors',[])
checks['all_existing_nonempty_image_targets_preserved']=not image.get('errors')
checks['all_original_raw_url_occurrences_preserved']=not any('original raw URLs' in e for e in errors)
r=json.loads((OUT/'report.json').read_text()); r['semantic_checks']=checks;r['image_preservation']=image;r['archive_script_comparison']={'archive_commit':ARCHIVE,'unicode_characters':len(orig),'utf8_bytes':len(orig.encode()),'exact_code_text_match':checks['sonicwall_archive_script_exact'],'boundary_rule':'compared original script bytes/text from shebang through main entrypoint, excluding only the archive separator blank lines'};r['errors']+=errors;r['status']='PASS' if not r['errors'] and all(r['checks'].values()) and all(checks.values()) else 'FAIL';(OUT/'report.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':r['status'],'semantic_checks':checks,'image_error_count':len(image.get('errors',[])),'errors':errors,'report':str(OUT/'report.json')},ensure_ascii=False,indent=2))
