from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki'); BASE='dbf87349c84e537c233b4231a1164e60fa52eca3'; TASK=Path('/tmp/vulwiki-goal-three-rounds-20261003'); OUT=TASK/'preview-final'
manifest=[json.loads(x) for x in (TASK/'preview-manifest.jsonl').read_text().splitlines() if x.strip()]
ops=[json.loads(x) for x in (TASK/'preview-operations.jsonl').read_text().splitlines() if x.strip()]
errors=[]; files=[]
head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
if head!=BASE: errors.append(f'HEAD expected frozen base {BASE}, got {head}')
if len(manifest)!=12 or len({m['path'] for m in manifest})!=12: errors.append('manifest does not contain 12 unique articles')
if len(ops)!=35: errors.append(f'expected 35 operations, found {len(ops)}')
by={m['path']:m for m in manifest}
for path,m in by.items():
 b=subprocess.check_output(['git','-C',str(ROOT),'show',f'{BASE}:{path}'])
 src=b.decode('utf-8'); sha=hashlib.sha256(b).hexdigest()
 # source may include prior two applied operations; validate against exact Git base unconditionally.
 if sha!=m['source_sha256']: errors.append(f'base SHA mismatch {path}')
 if path not in {o['path'] for o in ops}: errors.append(f'no operation for {path}')
 opsp=sorted((o for o in ops if o['path']==path),key=lambda x:x['offset'])
 prev=-1
 for o in opsp:
  off=o['offset']; before=o['before']
  if off<prev: errors.append(f'overlap/ordering {path}@{off}')
  if src[off:off+len(before)]!=before: errors.append(f'Unicode code-point source span mismatch {path}@{off}')
  prev=off+len(before)
 result=src
 for o in reversed(opsp):
  off=o['offset']; result=result[:off]+o['after']+result[off+len(o['before']):]
 preview=Path(m['preview']).read_bytes()
 psha=hashlib.sha256(preview).hexdigest()
 if psha!=m['preview_sha256']: errors.append(f'preview SHA mismatch {path}')
 if preview!=result.encode(): errors.append(f'preview not exact Python offset replay {path}')
 restored=result
 for o in reversed(opsp):
  off=o['offset']+sum(len(q['after'])-len(q['before']) for q in opsp if q['offset']<o['offset'])
  if restored[off:off+len(o['after'])]!=o['after']: errors.append(f'inverse span mismatch {path}@{off}'); continue
  restored=restored[:off]+o['before']+restored[off+len(o['after']):]
 if restored!=src: errors.append(f'inverse restore mismatch {path}')
 files.append({'path':path,'source_sha256':sha,'preview_sha256':psha,'operation_count':len(opsp),'base_and_preview_replay_exact':preview==result.encode(),'inverse_exact':restored==src})
# Count targeted scopes
sudo=[o for o in ops if o['path'].endswith('CVE-2025-32462&CVE-2025-32463.md') and o.get('expected_code') is not None]
btr=[o for o in ops if 'btrbk' in o['path'] and o.get('expected_code') is not None]
sonic=[o for o in ops if 'SonicWall' in o['path']]
if len(sudo)!=11: errors.append(f'sudo expected 11 code groups, got {len(sudo)}')
if len(btr)!=2: errors.append(f'btrbk expected 2 code groups, got {len(btr)}')
if len(sonic)!=4: errors.append(f'SonicWall expected 4 operations, got {len(sonic)}')
# Save complete JS parser input
input_rows=[]
for path,m in by.items():
 input_rows.append({'path':path,'source':Path(m['preview']).read_text(encoding='utf-8'),'expected_code':[e for o in ops if o['path']==path and o.get('expected_code') is not None for e in (o['expected_code'] if isinstance(o['expected_code'],list) else [o['expected_code']])]})
(OUT/'parser-input.json').write_text(json.dumps(input_rows,ensure_ascii=False),encoding='utf8')
node=r'''const fs=require('fs'),path=require('path'); const rows=JSON.parse(fs.readFileSync(process.argv[2],'utf8')); const mp='/Users/aresx/Ares-X.github.io/node_modules/marked'; const marked=require(mp),version=require(path.join(mp,'package.json')).version;
function codes(tokens,out=[]){for(const t of tokens||[]){if(t.type==='code')out.push(t.text);if(t.tokens)codes(t.tokens,out);if(t.items)for(const it of t.items)codes(it.tokens,out);}return out;}
let errors=[],files=[];for(const r of rows){const tokens=marked.lexer(r.source,{mangle:false});const all=codes(tokens);const checks=r.expected_code.map((e,i)=>{const n=all.filter(x=>x===e).length;if(n!==1)errors.push(`${r.path}: expected_code[${i}] whole code.text count ${n}`);return {index:i,count:n,expected:e};});files.push({path:r.path,top_level_tokens:tokens.length,all_code_tokens:all.length,expected_checks:checks});}
console.log(JSON.stringify({marked_version:version,options:{mangle:false},files,errors},null,2));process.exitCode=errors.length?1:0;'''
(OUT/'parse.cjs').write_text(node,encoding='utf8')
p=subprocess.run(['node',str(OUT/'parse.cjs'),str(OUT/'parser-input.json')],capture_output=True,text=True)
if p.returncode:
 try: parser=json.loads(p.stdout); errors+=parser.get('errors',[])
 except Exception: errors.append('Marked parser failed: '+p.stderr[-1000:]); parser={}
else: parser=json.loads(p.stdout)
if parser.get('marked_version')!='4.3.0': errors.append(f"expected marked 4.3.0 got {parser.get('marked_version')}")
# focused exact invariants
checks={
 'manifest_12_operations_35':len(manifest)==12 and len(ops)==35,
 'frozen_git_hashes_replay_inverse':not any('SHA mismatch' in e or 'replay' in e or 'inverse' in e or 'span mismatch' in e for e in errors),
 'marked_4_3_0_nested_whole_code_tokens':parser.get('marked_version')=='4.3.0' and not parser.get('errors'),
 'sudo_11_and_btrbk_2_groups':len(sudo)==11 and len(btr)==2,
 'sonicwall_4_ops':len(sonic)==4,
}
report={'base_commit_expected':BASE,'base_commit_actual':head,'counts':{'articles':len(manifest),'operations':len(ops),'sudo_groups':len(sudo),'btrbk_groups':len(btr),'sonicwall_operations':len(sonic)},'checks':checks,'files':files,'parser':parser,'errors':errors,'limits':['Semantic review is based on complete frozen base and preview Markdown plus operation diffs; no rendered DOM or example URL access.','No article payload or PoC was run.']}
report['status']='PASS' if not errors and all(checks.values()) else 'FAIL'
(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':report['status'],'checks':checks,'errors':errors,'report':str(OUT/'report.json')},ensure_ascii=False,indent=2))
