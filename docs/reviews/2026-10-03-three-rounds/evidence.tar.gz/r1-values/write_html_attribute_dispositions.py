import json,hashlib,pathlib,subprocess,re,collections
R=pathlib.Path('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki'); OUT=pathlib.Path('/tmp/vulwiki-goal-three-rounds-20261003/r1-values')
ARCH_SHORT='41940cb'; ARCH_FULL='41940cb0038d09ca5aaddbe5bffb923e423d210f'; HEAD='dbf87349c84e537c233b4231a1164e60fa52eca3'
source_rows=json.load(open('/tmp/vulwiki-goal-three-rounds-20261003/html-attribute-unmatched.json',encoding='utf8'))
visible=json.load(open(OUT/'html-visible-check.json',encoding='utf8'))['items']
extracted=json.load(open(OUT/'html-attribute-extracted.json',encoding='utf8'))['items']
assert len(source_rows)==len(visible)==len(extracted)==533
paths=sorted(set(x['path'] for x in source_rows))
def blobs(rev):
 tree=subprocess.run(['git','ls-tree','-r','-z','--full-tree',rev],cwd=R,stdout=subprocess.PIPE,check=True).stdout;oids={}
 for e in tree.split(b'\0'):
  if e:
   meta,path=e.split(b'\t',1);oids[path.decode('utf8')]=meta.split()[2].decode()
 p=subprocess.run(['git','cat-file','--batch'],input=''.join(oids.get(x,'missing')+'\n' for x in paths).encode(),cwd=R,stdout=subprocess.PIPE,check=True).stdout;pos=0;out={}
 for path in paths:
  end=p.index(b'\n',pos);hdr=p[pos:end].decode('utf8');pos=end+1;parts=hdr.split()
  if len(parts)<3 or parts[1]=='missing':out[path]=None;continue
  n=int(parts[2]);out[path]=p[pos:pos+n].decode('utf8');pos+=n+1
 return out
old=blobs(ARCH_SHORT);cur=blobs(HEAD)
def tagspans(line):
 out=[];i=0
 while True:
  a=line.find('<',i)
  if a<0:break
  q=None;j=a+1
  while j<len(line):
   c=line[j]
   if q:
    if c==q:q=None
   elif c in ('"',"'"):q=c
   elif c=='>':out.append((a,j+1,line[a:j+1]));i=j+1;break
   j+=1
  else:break
 return out
def font_end(spans,oi,line_len):
 stack=1
 for a,b,t in spans[oi+1:]:
  if re.match(r'<font\b',t,re.I) and not t.rstrip().endswith('/>'):stack+=1
  elif re.match(r'</font\s*>',t,re.I):
   stack-=1
   if stack==0:return b
 return spans[oi][1]
def compact(s,limit=360):
 s=s.replace('\x00','\\0')
 if len(s)<=limit:return s
 return s[:limit//2]+' …[excerpt clipped; full tag/inner text retained separately]… '+s[-limit//2:]
def norm(s):return ''.join(s.split())
def current_excerpt(text,anchor):
 if anchor:
  i=text.find(anchor)
  if i>=0:
   left=text.rfind('\n',0,i)+1;right=text.find('\n',i+len(anchor));right=len(text) if right<0 else right
   return {'kind':'literal_body_text_anchor','line_excerpt':compact(text[max(left,i-180):min(right,i+len(anchor)+180)],500),'body_anchor_exact':True}
 return {'kind':'line-diff/context','line_excerpt':''}
by_occ=collections.Counter();items=[];errors=[];preserved_inner=0;changed_inner=[]
for n,(x,v,e) in enumerate(zip(source_rows,visible,extracted),1):
 path=x['path'];a_text=old[path];h_text=cur[path]
 if a_text is None or h_text is None:errors.append({'item':n,'path':path,'error':'missing Git blob'});continue
 cur_sha=hashlib.sha256(h_text.encode('utf8')).hexdigest();archive_sha=hashlib.sha256(a_text.encode('utf8')).hexdigest()
 if cur_sha!=x['source_sha256']:errors.append({'item':n,'path':path,'error':'current file SHA mismatch','expected':x['source_sha256'],'actual':cur_sha});continue
 oldlines=a_text.splitlines();line_no=x['line'];line=oldlines[line_no-1];attr=x['attribute'];key=(path,line_no,attr);ordn=by_occ[key];by_occ[key]+=1
 poss=[];q=0
 while True:
  q=line.find(attr,q)
  if q<0:break
  poss.append(q);q+=len(attr)
 if ordn>=len(poss):errors.append({'item':n,'path':path,'line':line_no,'attribute':attr,'error':'attribute occurrence not located'});continue
 spans=tagspans(line);ap=poss[ordn];found=[i for i,(a,b,t) in enumerate(spans) if a<=ap<b]
 if len(found)!=1:errors.append({'item':n,'path':path,'line':line_no,'attribute':attr,'error':'tag boundary not unique'});continue
 oi=found[0];a,b,tag=spans[oi];name=re.match(r'<([A-Za-z0-9]+)',tag);tagname=name.group(1).lower() if name else 'unknown'
 if tagname=='font':
  endpos=font_end(spans,oi,len(line));raw_inner=line[b:endpos]
  inner=re.sub(r'<[^>]*>','',raw_inner)
  inner=inner.replace('&nbsp;',' ').replace('&amp;','&').replace('&lt;','<').replace('&gt;','>').replace('&quot;','"').replace('&#39;',"'")
  is_empty=not inner.strip()
  preserved=bool(is_empty or norm(inner) in norm(h_text))
  if preserved:preserved_inner+=1
  else:changed_inner.append({'path':path,'line':line_no,'inner':inner})
  category='formatting_wrapper_removal'
  attribution='Original tag is a font wrapper with only presentation CSS; this occurrence is outside fenced code. Its complete visible text remains in the fixed HEAD source.' if preserved else 'Original tag is still a font presentation wrapper, outside fenced code. The enclosed plain paragraph changed separately; current article adds an explicit correction explaining that the copied del_file RCE text mismatches the rewrite upload endpoint.'
  recommendation='Do not restore the style attribute or wrapper; preserve the current source text.'
  body_anchor=inner.strip() if not is_empty and preserved else ('本文请求指向 rewrite 文件上传入口' if not preserved else '')
 else:
  endpos=b;raw_inner='';inner='';is_empty=True;preserved=None
  category='collection_meta_removal'
  attribution='The exact tag is <meta name="referrer" content="no-referrer"/> at the article top, immediately before the archived source attribution. It is collection/rendering metadata, not an HTML/HTTP/PoC payload.'
  recommendation='No payload restoration is needed; leave the removed metadata tag out of the article body.'
  body_anchor='本文由'
 before=compact(line[max(0,a-240):a],300);after=compact(line[endpos:endpos+240],300)
 prior=compact(oldlines[line_no-2] if line_no>1 else '',300);nextline=compact(oldlines[line_no] if line_no<len(oldlines) else '',300)
 # Current context at exact preserved text or matching source citation; handle empty wrappers by adjacent nonempty prose.
 anchor=body_anchor
 curctx=current_excerpt(h_text,anchor)
 if not curctx['line_excerpt']:
  # Fall back to context around the article's current lead or source citation, without decoding errors.
  for needle in ('## 条目说明','## 技术校订与证据边界','> 原文:','> 本文由'):
   got=current_excerpt(h_text,needle)
   if got['line_excerpt']:
    curctx=got;break
 if tagname=='meta':
  disposition='removed ancillary referrer-policy meta tag; no source evidence/payload loss'
 elif preserved:
  disposition='removed visual font wrapper; all enclosed text is retained'
 else:
  disposition='removed visual font wrapper; enclosed prose received an explicit, attributable correction unrelated to HTML attributes'
 item_id=hashlib.sha256((path+'\0'+str(line_no)+'\0'+attr+'\0'+str(ordn)).encode()).hexdigest()[:20]
 items.append({'item_id':item_id,'path':path,'archive_commit':ARCH_FULL,'archive_file_sha256':archive_sha,'fixed_head':HEAD,'head_file_sha256':cur_sha,'archive_line':line_no,'attribute':attr,'tag_name':tagname,'original_full_tag':tag,'original_tag_sha256_utf8':hashlib.sha256(tag.encode('utf8')).hexdigest(),'occurrence_on_line':ordn+1,'source_context':{'before_tag_excerpt':before,'full_tag':tag,'enclosed_visible_text':inner,'after_tag_excerpt':after,'previous_line_excerpt':prior,'next_line_excerpt':nextline},'head_context':curctx,'fenced_code_at_archive_line':False,'classification':category,'disposition':disposition,'attribution':attribution,'exact_minimum_recommendation':recommendation})
summary={'fixed_head':HEAD,'archive_commit':ARCH_FULL,'unmatched_items':len(source_rows),'processed_items':len(items),'unique_files':len(paths),'errors':errors,'by_classification':dict(collections.Counter(x['classification'] for x in items)),'by_attribute':dict(collections.Counter(x['attribute'].split('=')[0] for x in items)),'tag_name_counts':dict(collections.Counter(x['tag_name'] for x in items)),'style_wrapper_text_exactly_retained_or_empty':preserved_inner,'style_wrapper_text_explicitly_revised':len(changed_inner),'style_wrapper_files_with_changed_text':changed_inner,'meta_all_full_tag':all(x['original_full_tag']=='<meta name="referrer" content="no-referrer"/>' for x in items if x['tag_name']=='meta'),'style_tags_all_font':all(x['tag_name']=='font' for x in items if x['classification']=='formatting_wrapper_removal'),'style_tags_in_fenced_code':sum(x['fenced_code_at_archive_line'] for x in items),'validation':'All archive/current Git blobs decoded strict UTF-8; current SHA matched each supplied source_sha256; full tag SHA-256 recorded per candidate.'}
(OUT/'html-attribute-dispositions.json').write_text(json.dumps({'summary':summary,'items':items},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('errors','style_wrapper_files_with_changed_text')},ensure_ascii=False,indent=2))
print('output',OUT/'html-attribute-dispositions.json')
