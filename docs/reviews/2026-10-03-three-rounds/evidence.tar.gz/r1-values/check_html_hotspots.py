import json,pathlib,re,subprocess,html.parser
R=pathlib.Path('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki'); OUT=pathlib.Path('/tmp/vulwiki-goal-three-rounds-20261003/r1-values'); REV='41940cb0038d09ca5aaddbe5b5ffb923e423d210f'
xs=[]; paths=set()
for l in open(OUT/'candidates.jsonl'):
 x=json.loads(l)
 if x['comparison']=='restore_commit_to_head' and 'html' in x['signals'] and x['path'] not in paths: paths.add(x['path']); xs.append(x['path'])
tree=subprocess.run(['git','ls-tree','-r','-z','--full-tree',REV],cwd=R,stdout=subprocess.PIPE,check=True).stdout
oids={}
for e in tree.split(b'\0'):
 if e:
  m,p=e.split(b'\t',1); oids[p.decode('utf8','replace')]=m.split()[2].decode()
p=subprocess.run(['git','cat-file','--batch'],input=''.join(oids.get(x,'missing')+'\n' for x in xs).encode(),cwd=R,stdout=subprocess.PIPE,check=True)
data=p.stdout; pos=0; risks={'src','href','action','srcdoc','onclick','onerror','onload','formaction','poster','data','value'}; findings=[]; total=0
class P(html.parser.HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=False);self.out=[]
 def handle_starttag(self,tag,attrs):
  for k,v in attrs:
   if k and k.lower() in risks and v is not None and len(v)>=3:self.out.append((tag,k,v))
 def handle_startendtag(self,tag,attrs):self.handle_starttag(tag,attrs)
for path in xs:
 end=data.index(b'\n',pos);hdr=data[pos:end].decode('utf8','replace');pos=end+1
 if len(hdr.split())<3 or hdr.split()[1]=='missing':continue
 size=int(hdr.split()[2]);old=data[pos:pos+size].decode('utf8','replace');pos+=size+1;cur=(R/path).read_text('utf8',errors='replace');parser=P()
 try:parser.feed(old)
 except Exception:continue
 missing=[]
 for tag,k,v in parser.out:
  total+=1
  if v not in cur:missing.append({'tag':tag,'attribute':k,'value':v[:600]})
 if missing:findings.append({'path':path,'missing':missing[:20]})
result={'scope':'archive HTML risk attributes in restore-history HTML candidate documents','candidate_documents':len(xs),'attribute_values_checked':total,'documents_with_missing_values':len(findings),'findings':findings}
(OUT/'html-hotspots.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='findings'},ensure_ascii=False,indent=2));print('details:',OUT/'html-hotspots.json')
