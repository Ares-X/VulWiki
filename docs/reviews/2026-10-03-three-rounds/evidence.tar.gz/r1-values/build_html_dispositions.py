import json,hashlib,pathlib,subprocess,re,collections,difflib,html
R=pathlib.Path('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki'); OUT=pathlib.Path('/tmp/vulwiki-goal-three-rounds-20261003/r1-values')
ARCH='41940cb'; HEAD='dbf87349c84e537c233b4231a1164e60fa52eca3'
rows=json.load(open('/tmp/vulwiki-goal-three-rounds-20261003/html-attribute-unmatched.json',encoding='utf8'))
paths=sorted(set(x['path'] for x in rows))
def blobs(rev):
 tree=subprocess.run(['git','ls-tree','-r','-z','--full-tree',rev],cwd=R,stdout=subprocess.PIPE,check=True).stdout
 oid={}
 for e in tree.split(b'\0'):
  if e:
   meta,p=e.split(b'\t',1);oid[p.decode('utf8')]=meta.split()[2].decode()
 p=subprocess.run(['git','cat-file','--batch'],input=''.join(oid.get(x,'missing')+'\n' for x in paths).encode(),cwd=R,stdout=subprocess.PIPE,check=True)
 data=p.stdout;pos=0;out={}
 for path in paths:
  end=data.index(b'\n',pos);hdr=data[pos:end].decode('utf8');pos=end+1;parts=hdr.split()
  if len(parts)<3 or parts[1]=='missing':out[path]=None;continue
  n=int(parts[2]);out[path]=data[pos:pos+n].decode('utf8');pos+=n+1
 return out
oldblobs=blobs(ARCH); newblobs=blobs(HEAD)
# lexical tag ranges on one line; quoted > characters are handled

def tags(line):
 out=[];i=0
 while True:
  a=line.find('<',i)
  if a<0:break
  q=None;j=a+1
  while j<len(line):
   c=line[j]
   if q:
    if c==q:q=None
   elif c in ('"',"'"):q=c
   elif c=='>':out.append((a,j+1,line[a:j+1]));i=j+1;break
   j+=1
  else:break
 return out
# index exact HTML tag occurrence for each candidate. Duplicate entries are retained as separate findings.
occ=collections.Counter();records=[];verification_errors=[]
for x in rows:
 path=x['path'];old=oldblobs.get(path);cur=newblobs.get(path)
 if old is None or cur is None:verification_errors.append({'path':path,'error':'missing Git blob'});continue
 cursha=hashlib.sha256(cur.encode('utf8')).hexdigest()
 if cursha!=x['source_sha256']:verification_errors.append({'path':path,'error':'current SHA differs','expected':x['source_sha256'],'actual':cursha});continue
 oldlines=old.splitlines();cur_lines=cur.splitlines();ln=x['line']
 if not (1<=ln<=len(oldlines)):verification_errors.append({'path':path,'line':ln,'error':'archive line outside file'});continue
 rawline=oldlines[ln-1];attr=x['attribute']; positions=[];at=0
 while True:
  at=rawline.find(attr,at)
  if at<0:break
  positions.append(at);at+=len(attr)
 # candidate ordinal maps repeated identical attribute rows on same source line
 key=(path,ln,attr);idx=occ[key];occ[key]+=1
 if idx>=len(positions):verification_errors.append({'path':path,'line':ln,'attribute':attr,'error':'candidate occurrence unavailable'});continue
 at=positions[idx];found=[t for t in tags(rawline) if t[0]<=at<t[1]]
 if len(found)!=1:verification_errors.append({'path':path,'line':ln,'attribute':attr,'error':'tag boundary ambiguous','count':len(found)});continue
 a,b,tag=found[0]
 fence=sum(1 for s in oldlines[:ln-1] if re.match(r'^\s*(```+|~~~+)',s))%2==1
 context='\n'.join(oldlines[max(0,ln-3):min(len(oldlines),ln+2)])
 # map archive line to current using exact/near diff blocks; fall back to distinctive adjacent literal text search.
 sm=difflib.SequenceMatcher(a=oldlines,b=cur_lines,autojunk=True)
 mapped=[]
 for tagop,ai,aj,bi,bj in sm.get_opcodes():
  if ai<=ln-1<aj:
   mapped=list(range(bi,min(bj,bi+3))) if tagop!='equal' else [bi+(ln-1-ai)]
   break
 current_context='\n'.join(cur_lines[i] for i in mapped) if mapped else ''
 # visible text in source tag gives an independent, literal context anchor.
 visible=re.sub(r'<[^>]*>',' ',tag);visible=html.unescape(visible);visible=re.sub(r'\s+',' ',visible).strip()
 anchor=visible[:80] if len(visible)>=10 else ''
 text_anchor_present=bool(anchor and anchor in re.sub(r'\s+',' ',cur))
 records.append({'path':path,'source_sha256':x['source_sha256'],'archive_commit':ARCH,'head_commit':HEAD,'archive_line':ln,'attribute':attr,'tag':tag,'tag_sha256':hashlib.sha256(tag.encode('utf8')).hexdigest(),'archive_context':context,'in_fenced_code_at_archive':fence,'current_context_by_line_diff':current_context,'visible_text_anchor':anchor,'visible_text_anchor_present_current':text_anchor_present,'preliminary_class':None,'attribution':None,'recommendation':None})
# dedupe manual review units by exact path and tag hash but keep original rows in final.
review_units={}
for rec in records:review_units[(rec['path'],rec['tag_sha256'])]=rec
summary={'input_unmatched_items':len(rows),'candidate_paths':len(paths),'unique_path_tag_units':len(review_units),'style_items':sum(x['attribute'].startswith('style=') for x in rows),'referrer_items':sum(x['attribute'].startswith('name=') for x in rows),'strict_utf8':True,'verification_errors':verification_errors,'archive_fenced_code_items':sum(x['in_fenced_code_at_archive'] for x in records),'archive_fenced_code_unique_tags':sum(x['in_fenced_code_at_archive'] for x in review_units.values()),'missing_visible_text_anchor_items':sum(not x['visible_text_anchor_present_current'] for x in records)}
(OUT/'html-attribute-extracted.json').write_text(json.dumps({'summary':summary,'items':records},ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'html-attribute-review-units.jsonl').write_text(''.join(json.dumps(v,ensure_ascii=False)+'\n' for v in review_units.values()),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
