import json, pathlib, subprocess, hashlib, re, collections
R=pathlib.Path('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki')
OUT=pathlib.Path('/tmp/vulwiki-goal-three-rounds-20261003/r1-values/html-attribute-dispositions.json')
source='/tmp/vulwiki-goal-three-rounds-20261003/html-attribute-unmatched.json'
items=json.load(open(source,encoding='utf-8'))
ARCH='41940cb0038d09ca5aaddbe5bffb923e423d210f'; BASE='dbf87349c84e537c233b4231a1164e60fa52eca3'
paths=sorted({x['path'] for x in items})
def blobs(rev):
 tree=subprocess.run(['git','ls-tree','-r','-z','--full-tree',rev],cwd=R,stdout=subprocess.PIPE,check=True).stdout
 oids={}
 for e in tree.split(b'\0'):
  if e:
   meta,p=e.split(b'\t',1);oids[p.decode('utf-8')]=meta.split()[2].decode()
 req=''.join(oids.get(p,'missing')+'\n' for p in paths).encode()
 data=subprocess.run(['git','cat-file','--batch'],input=req,cwd=R,stdout=subprocess.PIPE,check=True).stdout
 i=0;out={}
 for p in paths:
  end=data.index(b'\n',i);header=data[i:end].decode('utf-8');i=end+1;h=header.split()
  if len(h)<3 or h[1]=='missing':out[p]=None;continue
  n=int(h[2]);out[p]=data[i:i+n].decode('utf-8');i+=n+1
 return out
old=blobs(ARCH);base=blobs(BASE)
def find_tags(line):
 out=[];i=0
 while True:
  a=line.find('<',i)
  if a<0:break
  q=None;j=a+1
  while j<len(line):
   c=line[j]
   if q:
    if c==q:q=None
   elif c in ('"',"'"):q=c
   elif c=='>':out.append((a,j+1,line[a:j+1]));i=j+1;break
   j+=1
  else:break
 return out
occ=collections.Counter();findings=[];errors=[]
for x in items:
 p=x['path'];a=old.get(p);b=base.get(p)
 if a is None or b is None:errors.append({'path':p,'error':'missing archive/base blob'});continue
 if hashlib.sha256(b.encode()).hexdigest()!=x['source_sha256']:errors.append({'path':p,'line':x['line'],'error':'base SHA mismatch'});continue
 lines=a.splitlines();blines=b.splitlines();ln=x['line']
 if not (1<=ln<=len(lines)):errors.append({'path':p,'line':ln,'error':'line out of range'});continue
 line=lines[ln-1];attr=x['attribute'];poss=[];at=0
 while (at:=line.find(attr,at))>=0:poss.append(at);at+=len(attr)
 key=(p,ln,attr);idx=occ[key];occ[key]+=1
 if idx>=len(poss):errors.append({'path':p,'line':ln,'attribute':attr,'error':'attribute occurrence unavailable'});continue
 at=poss[idx];ts=[t for t in find_tags(line) if t[0]<=at<t[1]]
 if len(ts)!=1:errors.append({'path':p,'line':ln,'attribute':attr,'error':'tag boundary ambiguous','matches':len(ts)});continue
 start,end,tag=ts[0]
 if attr.startswith('name='):
  category='capture_wrapper_referrer_metadata'
  disposition='Ancillary <meta name="referrer" content="no-referrer"/> inserted by Simpleread capture; browser referrer policy metadata, not article claim, request, endpoint, exploit behavior, or a code sample.'
  severity='no_technical_semantic_loss_in_attribute'
  raw_value=attr
 else:
  m=re.search(r'\bstyle\s*=\s*(["\'])(.*?)\1',tag)
  raw_value=m.group(2) if m else attr
  category='inline_font_presentation_style'
  disposition='CSS color/background/box sizing/alignment on a <font> wrapper; visual presentation metadata. The technical/document text is adjacent or inside element content, not encoded by this style value.'
  severity='no_technical_semantic_loss_in_attribute'
 # Direct snapshot comparison of the complete original source line against base.
 line_in_base=line in b
 exact_value_in_base=attr in b
 # Bound local context; preserve exact complete source line in each finding.
 before=line[max(0,start-180):start];after=line[end:end+180]
 findings.append({'path':p,'archive_commit':ARCH,'comparison_base_commit':BASE,'archive_sha256':x['source_sha256'],'line':ln,'attribute_name': 'name' if attr.startswith('name=') else 'style','exact_attribute_source':attr,'raw_attribute_value':raw_value,'complete_tag':tag,'complete_archive_line':line,'line_sha256':hashlib.sha256(line.encode()).hexdigest(),'tag_prefix_context':before,'tag_suffix_context':after,'exact_attribute_substring_present_in_base':exact_value_in_base,'complete_archive_line_present_in_base':line_in_base,'classification':category,'disposition':disposition,'impact_assessment':severity})
counts=collections.Counter(f['classification'] for f in findings)
# bounded concrete evidence samples, kept verbatim in findings; no code/HTML was executed or rendered.
summary={'archive_commit':ARCH,'comparison_base_commit':BASE,'input_unmatched_count':len(items),'classified_count':len(findings),'distinct_paths':len({f['path'] for f in findings}),'class_counts':dict(counts),'strict_utf8':True,'verification_errors':errors,'interpretation':'All unmatched values are attributes on a meta capture wrapper or inline font presentation wrapper. None is a technical HTML behavior attribute, request byte, endpoint, identifier, or payload. This classification is limited to the unmatched attribute itself; adjacent article text may independently have changed and must be assessed by its own content-diff evidence.','regex_limitations':'The upstream inventory is line-oriented and uses a regular expression for quoted key=value forms with values length >=3. It can miss multiline attributes, unquoted values, values shorter than 3, some malformed/nested quoting, and tags spanning lines; it measures exact substring absence, not semantic loss. This report classifies all 533 supplied candidates and does not claim complete HTML coverage or article-content fidelity.'}
result={'summary':summary,'findings':findings}
OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2));print('report',OUT)
