import json,re,pathlib,subprocess
R=pathlib.Path('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki'); OUT=pathlib.Path('/tmp/vulwiki-goal-three-rounds-20261003/r1-values')
rows=[json.loads(l) for l in open('/tmp/vulwiki-goal-three-rounds-20261003/frozen-inventory.jsonl')]
rev='41940cb0038d09ca5aaddbe5bffb923e423d210f'
tree=subprocess.run(['git','ls-tree','-r','-z','--full-tree',rev],cwd=R,stdout=subprocess.PIPE,check=True).stdout
oids={}
for e in tree.split(b'\0'):
 if e:
  meta,p=e.split(b'\t',1); oids[p.decode('utf8','replace')]=meta.split()[2].decode()
p=subprocess.run(['git','cat-file','--batch'],input=''.join(oids.get(r['path'],'missing')+'\n' for r in rows).encode(),cwd=R,stdout=subprocess.PIPE,check=True)
data=p.stdout; pos=0
pat=re.compile(r'(?i)\b(?:cookie|set-cookie|authorization|x-auth-token|x-csrf-token|sessionid|token|password|passwd|secret|api[_-]?key)\s*[:=]\s*([^`\r\n]{3,})')
miss=[]; count=0; paths=0; source_paths=0
for r in rows:
 end=data.index(b'\n',pos); hdr=data[pos:end].decode('utf8','replace'); pos=end+1
 if len(hdr.split())<3 or hdr.split()[1]=='missing': continue
 size=int(hdr.split()[2]); old=data[pos:pos+size].decode('utf8','replace'); pos+=size+1; source_paths+=1
 cur=(R/r['path']).read_text('utf8',errors='replace'); missing=[]
 for ln,line in enumerate(old.splitlines(),1):
  if not re.search(r'(?i)\b(?:cookie|set-cookie|authorization|x-auth-token|x-csrf-token|sessionid|token|password|passwd|secret|api[_-]?key)\s*[:=]',line): continue
  for m in pat.finditer(line):
   val=m.group(1).rstrip(' \t;,.)}')
   if len(val)>=3:
    count+=1
    if val not in cur: missing.append({'line':ln,'field':m.group(0).split('=')[0].split(':')[0],'value':val,'old_line':line})
 if missing: paths+=1; miss.append({'path':r['path'],'missing_values':missing[:20]})
result={'archive_commit':rev,'inventory_paths':len(rows),'paths_with_archive_blobs':source_paths,'archive_value_occurrences':count,'files_with_unmatched_values':paths,'unmatched':miss}
(OUT/'archive-values.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='unmatched'},ensure_ascii=False,indent=2))
print('unmatched JSON:',str(OUT/'archive-values.json'))
