import hashlib, json, pathlib, re, subprocess, difflib
ROOT = pathlib.Path('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki')
BASE = '41940cb0038d09ca5aaddbe5bffb923e423d210f'
RESTORE = '0eb1ca97'
HEAD = 'dbf87349c84e537c233b4231a1164e60fa52eca3'
INV = pathlib.Path('/tmp/vulwiki-goal-three-rounds-20261003/frozen-inventory.jsonl')
OUT = pathlib.Path('/tmp/vulwiki-goal-three-rounds-20261003/r1-values')
rows = [json.loads(x) for x in INV.read_text().splitlines()]
# Confirm frozen snapshot coverage against the fixed checkout.
coverage=[]
for r in rows:
    p=ROOT/r['path']
    if not p.is_file(): coverage.append({'path':r['path'],'status':'missing'}); continue
    b=p.read_bytes(); h=hashlib.sha256(b).hexdigest()
    if h != r['sha256'] or len(b)!=r['bytes']:
        coverage.append({'path':r['path'],'status':'sha_mismatch','inventory_sha':r['sha256'],'current_sha':h,'inventory_bytes':r['bytes'],'current_bytes':len(b)})
# Collect suspicious changed lines at original archive -> HEAD and restoration commit -> HEAD.
patterns = {
 'url': re.compile(r'https?://|www\.'),
 'ipv4': re.compile(r'(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?![\w.])'),
 'email': re.compile(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}'),
 'http_header': re.compile(r'(?i)\b(?:cookie|authorization|set-cookie|host|referer|user-agent|content-length)\s*:'),
 'placeholder': re.compile(r'(?i)(?:\b(?:to be added|todo|placeholder|redacted|removed|xxx|example\.com|127\.0\.0\.1)\b|\[\w*\])'),
 'code_value': re.compile(r'(?:(?:\b(?:const|static|int|char|var|let|def|class|function)\b).{0,100}(?:=|\(|\{)|\b(?:token|password|passwd|username|user|key|secret|payload|command)\b\s*[:=])', re.I),
 'html': re.compile(r'<\/?(?:meta|table|tr|td|th|img|a|script|iframe|input|form|div|span|pre|code)\b', re.I),
 'literal_quote': re.compile(r'["\'][^"\']{2,}["\']'),
}
def blob(rev,path):
    q=subprocess.run(['git','show',f'{rev}:{path}'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    return q.stdout.decode('utf-8','replace') if q.returncode==0 else None
# Resolve historic article blobs in two batch calls instead of one subprocess per document.
def batch_blobs(rev):
    tree=subprocess.run(['git','ls-tree','-r','-z','--full-tree',rev],cwd=ROOT,stdout=subprocess.PIPE,check=True).stdout
    oids={}
    for entry in tree.split(b'\0'):
        if not entry: continue
        meta,path=entry.split(b'\t',1); fields=meta.split()
        oids[path.decode('utf-8','replace')]=fields[2].decode()
    specs=''.join((oids.get(r['path'],'missing')+'\n') for r in rows)
    p=subprocess.run(['git','cat-file','--batch'],input=specs.encode(),cwd=ROOT,stdout=subprocess.PIPE,check=True)
    data=p.stdout; pos=0; out={}
    for r in rows:
        end=data.index(b'\n',pos); hdr=data[pos:end].decode('utf-8','replace'); pos=end+1
        parts=hdr.split()
        if len(parts)<3 or parts[1]=='missing': out[r['path']]=None; continue
        size=int(parts[2]); raw=data[pos:pos+size]; pos+=size+1
        out[r['path']]=raw.decode('utf-8','replace')
    return out
archive_blobs=batch_blobs(BASE)
restore_blobs=batch_blobs(RESTORE)
sus=[]; changed=[]; no_base=[]
for r in rows:
    path=r['path']; cur=(ROOT/path).read_text(encoding='utf-8',errors='replace')
    old=archive_blobs[path]
    prev=restore_blobs[path]
    if old is None: no_base.append(path)
    if old is not None:
        a=old.splitlines(); b=cur.splitlines(); sm=difflib.SequenceMatcher(a=a,b=b,autojunk=False)
        ops=[(i,j,k,l) for op,i,j,k,l in sm.get_opcodes() if op!='equal']
        if ops: changed.append({'path':path,'archive_to_head_ops':len(ops),'archive_lines':len(a),'current_lines':len(b)})
        for op,i,j,k,l in sm.get_opcodes():
            if op not in ('delete','replace'): continue
            dels=a[i:j]
            for n,oldline in enumerate(dels):
                hits=[name for name,rx in patterns.items() if rx.search(oldline)]
                if hits:
                    news=b[k:l]
                    sus.append({'comparison':'archive_to_head','path':path,'old_line':i+n+1,'old':oldline,'new_lines':news,'signals':hits})
    if prev is not None:
        a=prev.splitlines(); b=cur.splitlines(); sm=difflib.SequenceMatcher(a=a,b=b,autojunk=False)
        for op,i,j,k,l in sm.get_opcodes():
            if op not in ('delete','replace'): continue
            for n,oldline in enumerate(a[i:j]):
                hits=[name for name,rx in patterns.items() if rx.search(oldline)]
                if hits:
                    sus.append({'comparison':'restore_commit_to_head','path':path,'old_line':i+n+1,'old':oldline,'new_lines':b[k:l],'signals':hits})
summary={'head':subprocess.check_output(['git','rev-parse',HEAD],cwd=ROOT,text=True).strip(),'inventory_documents':len(rows),'inventory_sha_mismatches':len(coverage),'archive_changed_documents':len(changed),'paths_without_archive_blob':len(no_base),'flagged_removed_lines':len(sus),'notes':'regex candidates are triage leads only; matching does not establish semantic loss or redaction.'}
(OUT/'coverage.json').write_text(json.dumps({'summary':summary,'mismatches':coverage,'missing_archive':no_base},ensure_ascii=False,indent=2))
(OUT/'candidates.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in sus))
(OUT/'changed-files.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in changed))
print(json.dumps(summary,ensure_ascii=False,indent=2))
