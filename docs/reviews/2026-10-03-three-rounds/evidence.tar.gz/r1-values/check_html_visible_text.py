import json,pathlib,subprocess,re,collections,hashlib,html
R=pathlib.Path('/Users/aresx/Ares-X.github.io/source/wiki/VulWiki');OUT=pathlib.Path('/tmp/vulwiki-goal-three-rounds-20261003/r1-values')
rows=json.load(open('/tmp/vulwiki-goal-three-rounds-20261003/html-attribute-unmatched.json',encoding='utf8')); paths=sorted(set(x['path'] for x in rows))
def blobs(rev):
 tree=subprocess.run(['git','ls-tree','-r','-z','--full-tree',rev],cwd=R,stdout=subprocess.PIPE,check=True).stdout;oids={}
 for e in tree.split(b'\0'):
  if e:
   m,p=e.split(b'\t',1);oids[p.decode('utf8')]=m.split()[2].decode()
 p=subprocess.run(['git','cat-file','--batch'],input=''.join(oids.get(x,'missing')+'\n' for x in paths).encode(),cwd=R,stdout=subprocess.PIPE,check=True).stdout;pos=0;out={}
 for path in paths:
  end=p.index(b'\n',pos);h=p[pos:end].decode('utf8');pos=end+1;parts=h.split()
  if len(parts)<3 or parts[1]=='missing':out[path]=None;continue
  n=int(parts[2]);out[path]=p[pos:pos+n].decode('utf8');pos+=n+1
 return out
old=blobs('41940cb');cur=blobs('dbf87349c84e537c233b4231a1164e60fa52eca3')
def tags(line):
 out=[];i=0
 while (a:=line.find('<',i))>=0:
  q=None;j=a+1
  while j<len(line):
   c=line[j]
   if q:
    if c==q:q=None
   elif c in ('"',"'"):q=c
   elif c=='>':out.append((a,j+1,line[a:j+1]));i=j+1;break
   j+=1
  else:break
 return out
def visible_font(line,tagpos,tagspans):
 opening=next((i for i,t in enumerate(tagspans) if t[0]==tagpos),None)
 if opening is None:return ''
 stack=1; end=None
 for _,_,t in tagspans[opening+1:]:
  if re.match(r'<font\b',t,re.I) and not t.rstrip().endswith('/>'):stack+=1
  elif re.match(r'</font\s*>',t,re.I):
   stack-=1
   if stack==0:end=_[0] if False else None;break
 # instead boundaries tracked by tag indexes; return inner from source via located end token
 if stack!=0:return ''
 opening_end=tagspans[opening][1]
 # determine closing tag position by rescanning matching font tags
 stack=1; inner_end=len(line)
 for a,b,t in tagspans[opening+1:]:
  if re.match(r'<font\b',t,re.I) and not t.rstrip().endswith('/>'):stack+=1
  elif re.match(r'</font\s*>',t,re.I):
   stack-=1
   if stack==0:inner_end=a;break
 raw=line[opening_end:inner_end]
 plain=html.unescape(re.sub(r'<[^>]*>','',raw))
 return re.sub(r'\s+',' ',plain).strip()
def norm(s):return ''.join(s.split())
occ=collections.Counter();out=[];errors=[]
for x in rows:
 path=x['path'];lines=old[path].splitlines();line=lines[x['line']-1];attr=x['attribute'];key=(path,x['line'],attr);idx=occ[key];occ[key]+=1
 poss=[];j=0
 while True:
  j=line.find(attr,j)
  if j<0:break
  poss.append(j);j+=len(attr)
 if idx>=len(poss):errors.append(x);continue
 spans=tags(line);atag=next((t for t in spans if t[0]<=poss[idx]<t[1]),None)
 if not atag:errors.append(x);continue
 tagpos=atag[0];tag=atag[2]; elem=re.match(r'<([A-Za-z0-9]+)',tag);name=elem.group(1).lower() if elem else ''
 text=visible_font(line,tagpos,spans) if name=='font' else ''
 current=cur[path]; current_plain=html.unescape(re.sub(r'<[^>]*>',' ',current)); present=bool(text and norm(text) in norm(current_plain))
 out.append({'path':path,'line':x['line'],'attribute':attr,'tag':tag,'tag_sha256':hashlib.sha256(tag.encode('utf8')).hexdigest(),'tag_name':name,'inner_visible_text':text,'visible_text_exact_in_current_ignoring_whitespace_and_markup':present})
print(json.dumps({'candidates':len(rows),'processed':len(out),'errors':len(errors),'unique_style_inner_texts':sum(bool(x['inner_visible_text']) for x in out),'style_inner_text_missing_current':sum(x['tag_name']=='font' and not x['visible_text_exact_in_current_ignoring_whitespace_and_markup'] for x in out),'tag_names':dict(collections.Counter(x['tag_name'] for x in out))},ensure_ascii=False,indent=2))
(OUT/'html-visible-check.json').write_text(json.dumps({'items':out,'errors':errors},ensure_ascii=False,indent=2),encoding='utf8')
