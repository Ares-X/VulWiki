#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const marked = require('/Users/aresx/Ares-X.github.io/node_modules/marked');
const root = process.argv[2] || process.cwd();
const inventoryPath = process.argv[3] || '/tmp/vulwiki-goal-three-rounds-20261003/frozen-inventory.jsonl';
const outPath = process.argv[4] || '/tmp/vulwiki-goal-three-rounds-20261003/r1-commands/candidates.jsonl';
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const defaults = { ...marked.defaults, mangle: false };
const command = /^(?:\s*(?:\$\s*)?(?:sudo(?:\s|$)|mkdir(?:\s|$)|echo(?:\s|$)|gcc(?:\s|$)|curl(?:\s|$)|wget(?:\s|$)|git\s+clone(?:\s|$)|chmod(?:\s|$)|cat\s+\/proc\/(?:version|cpuinfo|uptime)(?:\s|$)|uname(?:\s|$)|\S+@[^\s:]+:[^$#]*[$#]\s*|[>#]\s*|\w+@[^\s:]+:[^$#]*[$#]\s*))/i;
function walk(ts, cb){ for(const t of ts||[]){cb(t); if(t.tokens)walk(t.tokens,cb); if(t.items)for(const i of t.items)walk(i.tokens,cb); if(t.type==='table'){for(const c of t.header||[])walk(c.tokens,cb);for(const row of t.rows||[])for(const c of row)walk(c.tokens,cb);}}}
const inv=fs.readFileSync(inventoryPath,'utf8').trim().split('\n').map(JSON.parse);
const results=[]; let paragraphCount=0, tokenCount=0, files=0;
for(const row of inv){
 const file=path.join(root,row.path), bytes=fs.readFileSync(file), actualSha=sha(bytes);
 if(actualSha!==row.sha256) throw new Error(`snapshot mismatch: ${row.path}`);
 const source=bytes.toString('utf8');
 const fm=source.match(/^---\r?\n[\s\S]*?^---[ \t]*(?:\r?\n|$)/m); const body=fm?source.slice(fm[0].length):source;
 const tokens=marked.lexer(body,defaults); files++;
 let cursor=0;
 // Top-level ordinary paragraphs only. Excludes nested list/table/blockquote paragraph tokens by design; those remain an explicit coverage limitation.
 for(const t of tokens){ tokenCount++; if(t.type!=='paragraph')continue; paragraphCount++;
   const start=body.indexOf(t.raw,cursor); if(start>=0)cursor=start+t.raw.length;
   if(start<0)continue;
   const raw=t.raw; const lines=raw.split(/(?<=\n)/); let rel=0;
   for(let n=0;n<lines.length;n++){
    const line=lines[n].replace(/\r?\n$/,'');
    if(!command.test(line)){rel+=lines[n].length;continue;}
    // Match only a literal command/prompt line in the paragraph source. Suppress if its matched bytes overlap Marked inline code/link/image tokens.
    const lineStart=start+rel, lineEnd=lineStart+line.length;
    const inline=[]; walk(t.tokens, x=>{if(['codespan','link','image'].includes(x.type)&&x.raw){let p=raw.indexOf(x.raw);if(p>=0)inline.push([start+p,start+p+x.raw.length]);}});
    const overlaps=inline.some(([a,b])=>a<lineEnd&&lineStart<b);
    if(!overlaps){
      results.push({path:row.path,file_sha256:actualSha,paragraph_raw:raw,paragraph_start_utf16:start,paragraph_line:source.slice(0,fm?fm[0].length:0).split('\n').length-1+body.slice(0,start).split('\n').length,matched_line:line,matched_line_offset_utf16:lineStart,matched_line_index:n,marked_token:'paragraph',inline_overlap_suppressed:false});
    }
    rel+=lines[n].length;
   }
 }
}
fs.writeFileSync(outPath,results.map(x=>JSON.stringify(x)).join('\n')+(results.length?'\n':''));
console.log(JSON.stringify({files,top_level_tokens:tokenCount,top_level_paragraphs:paragraphCount,candidates:results.length,marked:'4.3.0',defaults:true,mangle:false,output:outPath,criterion:'case-insensitive command/prompt line starts; only top-level paragraph tokens; suppress lines intersecting inline codespan/link/image token raw; whole paragraph raw and snapshot SHA retained'}));
